# Lesson 12: AI Service Integration (Part 2)

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Implementing Streaming Responses](#implementing-streaming-responses)
4. [Handling Rate Limiting and API Quotas](#handling-rate-limiting-and-api-quotas)
5. [Optimizing Token Usage and Managing Conversation Context](#optimizing-token-usage-and-managing-conversation-context)
6. [Implementing Retry Mechanisms and Error Handling](#implementing-retry-mechanisms-and-error-handling)
7. [Creating a Caching Layer for AI Responses](#creating-a-caching-layer-for-ai-responses)
8. [Conclusion](#conclusion)
9. [Exercises](#exercises)

## Introduction

In this lesson, we'll build upon our AI service integration from the previous lesson, focusing on advanced features and optimizations. We'll implement streaming responses, handle rate limiting, optimize token usage, implement retry mechanisms, and create a caching layer for AI responses. These enhancements will make our VSCode extension more efficient, responsive, and resilient.

## Project Structure

Before we dive into the implementation, let's review the updated project structure:

```
- src/
    - ClaudeDev.ts
    - extension.ts
    - api/
        - anthropic.ts
        - bedrock.ts
        - gemini.ts
        - index.ts
        - ollama.ts
        - openai-native.ts
        - openai.ts
        - openrouter.ts
        - vertex.ts
        - streaming-handler.ts      (new)
        - rate-limiting-handler.ts  (new)
        - retry-handler.ts          (new)
        - caching-handler.ts        (new)
    - shared/
        - api.ts
        - ClaudeRequestResult.ts
        - ExtensionMessage.ts
        - Tool.ts
        - WebviewMessage.ts
    - utils/
        - token-counter.ts          (new)
        - context-management.ts     (new)
        - validate.ts
- webview-ui/
    - src/
        - components/
            - ApiOptions.tsx
            - StreamingOutput.tsx   (new)
        - context/
            - ExtensionStateContext.tsx
        - utils/
            - vscode.ts
- package.json
- tsconfig.json
```

We'll be adding several new files to implement the advanced features discussed in this lesson.

## Implementing Streaming Responses

Streaming responses provide a more interactive experience for users, allowing them to see the AI's output as it's generated. Let's implement a streaming handler that works with our existing API structure.

Create a new file `src/api/streaming-handler.ts`:

```typescript
import { ApiHandler, ApiHandlerMessageResponse } from "./index"
import { Anthropic } from "@anthropic-ai/sdk"
import { EventEmitter } from "events"

export interface StreamingApiHandler extends ApiHandler, EventEmitter {
    on(event: 'data', listener: (chunk: string) => void): this
    on(event: 'end', listener: () => void): this
}

export class StreamingHandler extends EventEmitter implements StreamingApiHandler {
    private baseHandler: ApiHandler

    constructor(baseHandler: ApiHandler) {
        super()
        this.baseHandler = baseHandler
    }

    async createMessage(
        systemPrompt: string,
        messages: Anthropic.Messages.MessageParam[],
        tools: Anthropic.Messages.Tool[]
    ): Promise<ApiHandlerMessageResponse> {
        const response = await this.baseHandler.createMessage(systemPrompt, messages, tools)

        // Simulate streaming for non-streaming APIs
        const chunks = response.message.content.split(' ')
        for (const chunk of chunks) {
            this.emit('data', chunk + ' ')
            await new Promise(resolve => setTimeout(resolve, 50)) // Simulate delay
        }
        this.emit('end')

        return response
    }

    getModel() {
        return this.baseHandler.getModel()
    }
}
```

This `StreamingHandler` wraps our existing API handlers and simulates streaming for non-streaming APIs. For APIs that natively support streaming (like OpenAI), you would implement the actual streaming logic here.

To use this in your `ClaudeDev` class:

```typescript
import { StreamingHandler } from './api/streaming-handler'

export class ClaudeDev {
    private api: StreamingHandler

    constructor(apiConfiguration: ApiConfiguration) {
        const baseHandler = buildApiHandler(apiConfiguration)
        this.api = new StreamingHandler(baseHandler)

        this.api.on('data', (chunk) => {
            // Send chunk to UI
            console.log(chunk)
        })

        this.api.on('end', () => {
            // Handle end of stream
            console.log('Stream ended')
        })
    }

    // ... rest of the class
}
```

## Handling Rate Limiting and API Quotas

To prevent exceeding API rate limits, let's implement a rate limiting handler. Create a new file `src/api/rate-limiting-handler.ts`:

```typescript
import { ApiHandler, ApiHandlerMessageResponse } from "./index"
import { Anthropic } from "@anthropic-ai/sdk"

export class RateLimitingHandler implements ApiHandler {
    private baseHandler: ApiHandler
    private requestsPerMinute: number
    private requestTimestamps: number[] = []

    constructor(baseHandler: ApiHandler, requestsPerMinute: number) {
        this.baseHandler = baseHandler
        this.requestsPerMinute = requestsPerMinute
    }

    private async waitForRateLimit(): Promise<void> {
        const now = Date.now()
        this.requestTimestamps = this.requestTimestamps.filter(t => now - t < 60000)

        if (this.requestTimestamps.length >= this.requestsPerMinute) {
            const oldestTimestamp = this.requestTimestamps[0]
            const waitTime = 60000 - (now - oldestTimestamp)
            await new Promise(resolve => setTimeout(resolve, waitTime))
        }

        this.requestTimestamps.push(now)
    }

    async createMessage(
        systemPrompt: string,
        messages: Anthropic.Messages.MessageParam[],
        tools: Anthropic.Messages.Tool[]
    ): Promise<ApiHandlerMessageResponse> {
        await this.waitForRateLimit()
        return this.baseHandler.createMessage(systemPrompt, messages, tools)
    }

    getModel() {
        return this.baseHandler.getModel()
    }
}
```

To use this handler:

```typescript
const baseHandler = buildApiHandler(apiConfiguration)
const rateLimitedHandler = new RateLimitingHandler(baseHandler, 60) // 60 requests per minute
```

## Optimizing Token Usage and Managing Conversation Context

To optimize token usage and manage conversation context, we'll implement a context management utility. Create a new file `src/utils/context-management.ts`:

```typescript
import { Anthropic } from "@anthropic-ai/sdk"
import { countTokens } from "./token-counter"

export function truncateConversationHistory(
    messages: Anthropic.Messages.MessageParam[],
    maxTokens: number
): Anthropic.Messages.MessageParam[] {
    let totalTokens = 0
    const truncatedMessages: Anthropic.Messages.MessageParam[] = []

    for (let i = messages.length - 1; i >= 0; i--) {
        const message = messages[i]
        const messageTokens = countTokens(JSON.stringify(message))

        if (totalTokens + messageTokens > maxTokens) {
            break
        }

        truncatedMessages.unshift(message)
        totalTokens += messageTokens
    }

    return truncatedMessages
}
```

This utility function truncates the conversation history to fit within a specified token limit. You'll need to implement the `countTokens` function in `src/utils/token-counter.ts` based on the tokenization method used by your AI provider.

Use this in your `ClaudeDev` class:

```typescript
import { truncateConversationHistory } from './utils/context-management'

export class ClaudeDev {
    // ... other code

    async handleUserInput(userInput: string) {
        const maxTokens = 4000 // Adjust based on your model's limits
        const truncatedHistory = truncateConversationHistory(this.conversationHistory, maxTokens)

        // Use truncatedHistory in your API call
        const response = await this.api.createMessage(this.systemPrompt, truncatedHistory, this.tools)

        // ... handle response
    }
}
```

## Implementing Retry Mechanisms and Error Handling

To make our extension more resilient, let's implement a retry mechanism. Create a new file `src/api/retry-handler.ts`:

```typescript
import { ApiHandler, ApiHandlerMessageResponse } from "./index"
import { Anthropic } from "@anthropic-ai/sdk"

export class RetryHandler implements ApiHandler {
    private baseHandler: ApiHandler
    private maxRetries: number
    private retryDelay: number

    constructor(baseHandler: ApiHandler, maxRetries: number = 3, retryDelay: number = 1000) {
        this.baseHandler = baseHandler
        this.maxRetries = maxRetries
        this.retryDelay = retryDelay
    }

    private async retry<T>(fn: () => Promise<T>): Promise<T> {
        let lastError: Error | undefined

        for (let i = 0; i < this.maxRetries; i++) {
            try {
                return await fn()
            } catch (error) {
                lastError = error as Error
                console.error(`Attempt ${i + 1} failed: ${error.message}`)
                await new Promise(resolve => setTimeout(resolve, this.retryDelay))
            }
        }

        throw lastError
    }

    async createMessage(
        systemPrompt: string,
        messages: Anthropic.Messages.MessageParam[],
        tools: Anthropic.Messages.Tool[]
    ): Promise<ApiHandlerMessageResponse> {
        return this.retry(() => this.baseHandler.createMessage(systemPrompt, messages, tools))
    }

    getModel() {
        return this.baseHandler.getModel()
    }
}
```

To use this handler:

```typescript
const baseHandler = buildApiHandler(apiConfiguration)
const retryHandler = new RetryHandler(baseHandler, 3, 1000) // 3 retries, 1 second delay
```

## Creating a Caching Layer for AI Responses

To reduce API usage and improve response times for repeated queries, let's implement a caching layer. Create a new file `src/api/caching-handler.ts`:

```typescript
import { ApiHandler, ApiHandlerMessageResponse } from "./index"
import { Anthropic } from "@anthropic-ai/sdk"

interface CacheEntry {
    response: ApiHandlerMessageResponse
    timestamp: number
}

export class CachingHandler implements ApiHandler {
    private baseHandler: ApiHandler
    private cache: Map<string, CacheEntry> = new Map()
    private cacheDuration: number

    constructor(baseHandler: ApiHandler, cacheDuration: number = 3600000) { // Default 1 hour
        this.baseHandler = baseHandler
        this.cacheDuration = cacheDuration
    }

    private getCacheKey(systemPrompt: string, messages: Anthropic.Messages.MessageParam[], tools: Anthropic.Messages.Tool[]): string {
        return JSON.stringify({ systemPrompt, messages, tools })
    }

    async createMessage(
        systemPrompt: string,
        messages: Anthropic.Messages.MessageParam[],
        tools: Anthropic.Messages.Tool[]
    ): Promise<ApiHandlerMessageResponse> {
        const cacheKey = this.getCacheKey(systemPrompt, messages, tools)
        const cachedEntry = this.cache.get(cacheKey)

        if (cachedEntry && (Date.now() - cachedEntry.timestamp) < this.cacheDuration) {
            console.log("Cache hit")
            return cachedEntry.response
        }

        console.log("Cache miss")
        const response = await this.baseHandler.createMessage(systemPrompt, messages, tools)
        this.cache.set(cacheKey, { response, timestamp: Date.now() })
        return response
    }

    getModel() {
        return this.baseHandler.getModel()
    }
}
```

To use this handler:

```typescript
const baseHandler = buildApiHandler(apiConfiguration)
const cachingHandler = new CachingHandler(baseHandler, 3600000) // 1 hour cache duration
```

## Conclusion

In this lesson, we've implemented several advanced features to enhance our AI service integration:

1. Streaming responses for a more interactive user experience
2. Rate limiting to prevent exceeding API quotas
3. Token usage optimization and conversation context management
4. Retry mechanisms for improved resilience
5. Caching to reduce API usage and improve response times

These features will make your VSCode extension more efficient, responsive, and resilient when interacting with AI services.

## Exercises

1. Implement a proper streaming response for the OpenAI API, which natively supports streaming.

2. Create a more sophisticated rate limiting system that handles different rate limits for different API providers.

3. Implement a token-based pricing system that estimates the cost of each API call based on token usage.

4. Create a system for persisting the cache between VSCode sessions, possibly using VSCode's extension storage API.

5. Implement a way to clear the cache and conversation history on demand, both programmatically and through a user command.

6. Create a debug mode that logs detailed information about API calls, including token usage, cache hits/misses, and streaming progress.

7. Implement a way to switch between different AI providers dynamically, possibly based on the type of task or user preferences.

8. Create a system for handling and recovering from specific types of API errors (e.g., authentication errors, network errors) in different ways.

By completing these exercises, you'll gain hands-on experience with advanced AI integration techniques and further improve the robustness and efficiency of your VSCode extension.

