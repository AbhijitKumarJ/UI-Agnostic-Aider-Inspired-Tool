# Lesson 7: Source Control Integration in VSCode Extensions

## Introduction

In this lesson, we'll explore how to integrate source control functionality into VSCode extensions. While the Claude Dev project doesn't directly implement source control features, we'll use its structure as a reference and create examples of how such features could be implemented. We'll cover basic Git operations, creating custom source control views, implementing diff views, and extending source control functionality with AI assistance.

## Project Structure

Before we dive into the details, let's look at the relevant parts of the Claude Dev project structure:

```
claude-dev/
├── src/
│   ├── ClaudeDev.ts
│   ├── extension.ts
│   ├── providers/
│   │   └── ClaudeDevProvider.ts
│   └── utils/
│       └── ripgrep.ts
├── webview-ui/
│   └── src/
│       └── components/
│           └── CodeAccordian.tsx
├── package.json
└── tsconfig.json
```

While Claude Dev doesn't have specific source control integration, we'll use this structure to show where such functionality could be added.

## 1. Overview of VSCode's Source Control API

VSCode provides a comprehensive API for integrating with source control systems. The main entry point for this API is the `vscode.scm` namespace. Here's a basic example of how to create a source control manager:

```typescript
// In a new file, e.g., src/GitExtension.ts
import * as vscode from 'vscode';

export class GitExtension {
    private readonly sourceControl: vscode.SourceControl;
    private readonly sourceControlResourceGroup: vscode.SourceControlResourceGroup;

    constructor(context: vscode.ExtensionContext) {
        this.sourceControl = vscode.scm.createSourceControl('git', 'Git');
        this.sourceControlResourceGroup = this.sourceControl.createResourceGroup('workingTree', 'Changes');
        
        // Initialize the source control view
        this.refresh();
    }

    private async refresh(): Promise<void> {
        // We'll implement this method later
    }
}

// In extension.ts
import { GitExtension } from './GitExtension';

export function activate(context: vscode.ExtensionContext) {
    // ... other activation code ...
    new GitExtension(context);
}
```

This code creates a new source control provider for Git and a resource group for changes.

## 2. Implementing Basic Git Operations

Let's implement some basic Git operations like status, commit, and push/pull. We'll add these to our `GitExtension` class:

```typescript
import * as vscode from 'vscode';
import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);

export class GitExtension {
    // ... previous code ...

    private async getStatus(): Promise<string> {
        const { stdout } = await execAsync('git status --porcelain');
        return stdout;
    }

    private async commit(message: string): Promise<void> {
        await execAsync(`git commit -m "${message}"`);
        await this.refresh();
    }

    private async push(): Promise<void> {
        await execAsync('git push');
    }

    private async pull(): Promise<void> {
        await execAsync('git pull');
        await this.refresh();
    }

    private async refresh(): Promise<void> {
        const status = await this.getStatus();
        const resources: vscode.SourceControlResourceState[] = status.split('\n')
            .filter(line => line.trim() !== '')
            .map(line => {
                const [state, path] = line.trim().split(' ');
                return {
                    resourceUri: vscode.Uri.file(path),
                    decorations: {
                        strikeThrough: state.includes('D'),
                        dark: {
                            iconPath: state.includes('M') ? 
                                new vscode.ThemeIcon('edit') : new vscode.ThemeIcon('add')
                        }
                    }
                };
            });

        this.sourceControlResourceGroup.resourceStates = resources;
    }
}
```

This implementation uses the `child_process` module to execute Git commands. In a production extension, you might want to use a more robust Git library like `simple-git`.

## 3. Creating Custom Source Control Views

VSCode allows you to create custom views for your source control provider. Let's add a custom view to show commit history:

```typescript
// In GitExtension.ts
import * as vscode from 'vscode';

export class CommitHistoryProvider implements vscode.TreeDataProvider<CommitItem> {
    private _onDidChangeTreeData: vscode.EventEmitter<CommitItem | undefined | null | void> = new vscode.EventEmitter<CommitItem | undefined | null | void>();
    readonly onDidChangeTreeData: vscode.Event<CommitItem | undefined | null | void> = this._onDidChangeTreeData.event;

    refresh(): void {
        this._onDidChangeTreeData.fire();
    }

    getTreeItem(element: CommitItem): vscode.TreeItem {
        return element;
    }

    async getChildren(element?: CommitItem): Promise<CommitItem[]> {
        if (element) {
            return [];
        } else {
            const { stdout } = await execAsync('git log --pretty=format:"%h|%s|%an|%ad" -n 10');
            return stdout.split('\n').map(line => {
                const [hash, subject, author, date] = line.split('|');
                return new CommitItem(hash, subject, author, date);
            });
        }
    }
}

class CommitItem extends vscode.TreeItem {
    constructor(
        public readonly hash: string,
        public readonly subject: string,
        public readonly author: string,
        public readonly date: string
    ) {
        super(subject, vscode.TreeItemCollapsibleState.None);
        this.tooltip = `${author} on ${date}`;
        this.description = hash;
    }
}

// In extension.ts
export function activate(context: vscode.ExtensionContext) {
    // ... other activation code ...
    const commitHistoryProvider = new CommitHistoryProvider();
    vscode.window.registerTreeDataProvider('commitHistory', commitHistoryProvider);
}

// In package.json
{
    "contributes": {
        "views": {
            "scm": [
                {
                    "id": "commitHistory",
                    "name": "Commit History"
                }
            ]
        }
    }
}
```

This code creates a custom view showing the last 10 commits in the repository.

## 4. Implementing Diff Views

VSCode provides APIs for creating diff views. Let's add a method to our `GitExtension` class to show diffs:

```typescript
// In GitExtension.ts
import * as vscode from 'vscode';

export class GitExtension {
    // ... previous code ...

    async showDiff(uri: vscode.Uri): Promise<void> {
        const { stdout: diff } = await execAsync(`git diff ${uri.fsPath}`);
        const diffDocument = await vscode.workspace.openTextDocument({
            content: diff,
            language: 'diff'
        });
        await vscode.window.showTextDocument(diffDocument, { preview: false, viewColumn: vscode.ViewColumn.Beside });
    }
}
```

You can call this method when a user clicks on a modified file in your source control view.

## 5. Extending Source Control Functionality with AI Assistance

Now, let's add some AI-powered features to our source control integration. We'll create a method that generates commit messages using an AI model:

```typescript
// In GitExtension.ts
import * as vscode from 'vscode';
import { ClaudeDev } from '../ClaudeDev';

export class GitExtension {
    private claudeDev: ClaudeDev;

    constructor(context: vscode.ExtensionContext, claudeDev: ClaudeDev) {
        // ... previous initialization ...
        this.claudeDev = claudeDev;
    }

    // ... previous methods ...

    async generateCommitMessage(): Promise<string> {
        const { stdout: diff } = await execAsync('git diff --staged');
        const prompt = `Based on the following Git diff, generate a concise and informative commit message:\n\n${diff}`;
        
        const response = await this.claudeDev.getAIResponse(prompt);
        return response.trim();
    }

    async commitWithAI(): Promise<void> {
        const message = await this.generateCommitMessage();
        const userMessage = await vscode.window.showInputBox({
            prompt: 'AI-generated commit message (you can edit):',
            value: message
        });
        if (userMessage) {
            await this.commit(userMessage);
        }
    }
}
```

This implementation uses the `ClaudeDev` class to generate commit messages based on the staged changes. You would need to implement the `getAIResponse` method in the `ClaudeDev` class to interact with your chosen AI model.

## Conclusion

In this lesson, we've explored how to integrate source control functionality into VSCode extensions. We've covered creating a basic source control manager, implementing Git operations, creating custom views, showing diffs, and even adding AI-assisted features.

While the Claude Dev project doesn't directly implement these features, we've shown how they could be integrated into a similar project structure. By understanding these concepts, you can create powerful extensions that enhance the source control experience in VSCode.

## Exercises

1. Implement a "Git blame" feature that shows the last commit that modified each line of a file.
2. Create a custom view that shows the git log for a specific file.
3. Implement a feature that suggests code reviewers based on git history.
4. Create an AI-powered feature that explains complex git diffs in natural language.

By completing these exercises, you'll gain hands-on experience with source control integration in VSCode extensions and explore ways to enhance these features with AI assistance.

