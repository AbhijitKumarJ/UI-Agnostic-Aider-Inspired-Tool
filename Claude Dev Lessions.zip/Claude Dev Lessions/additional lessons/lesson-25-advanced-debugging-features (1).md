# Lesson 25: Advanced Debugging Features for VSCode Extensions

## Table of Contents
1. [Introduction](#introduction)
2. [Custom Debug Adapter](#custom-debug-adapter)
3. [Debug Configuration Provider](#debug-configuration-provider)
4. [Custom Debug Console](#custom-debug-console)
5. [Breakpoint Handling](#breakpoint-handling)
6. [Custom Debug UI](#custom-debug-ui)
7. [AI-Assisted Debugging](#ai-assisted-debugging)
8. [Conclusion](#conclusion)
9. [Exercises](#exercises)

## Introduction

This lesson focuses on advanced debugging features that can be implemented in VSCode extensions. These features can provide powerful debugging capabilities, especially for custom runtimes or AI-assisted debugging scenarios.

## Custom Debug Adapter

A debug adapter acts as a bridge between VSCode and a debugger. Here's a basic implementation:

```typescript
import {
    Logger, logger,
    LoggingDebugSession,
    InitializedEvent, TerminatedEvent, StoppedEvent, BreakpointEvent, OutputEvent,
    Thread, StackFrame, Scope, Source, Handles, Breakpoint
} from '@vscode/debugadapter';
import { DebugProtocol } from '@vscode/debugprotocol';
import { basename } from 'path';

export class CustomDebugSession extends LoggingDebugSession {
    private static THREAD_ID = 1;

    public constructor() {
        super("custom-debug.txt");
        this.setDebuggerLinesStartAt1(false);
        this.setDebuggerColumnsStartAt1(false);
    }

    protected initializeRequest(response: DebugProtocol.InitializeResponse, args: DebugProtocol.InitializeRequestArguments): void {
        response.body = response.body || {};
        response.body.supportsConfigurationDoneRequest = true;
        response.body.supportsEvaluateForHovers = true;
        response.body.supportsStepBack = true;
        this.sendResponse(response);
        this.sendEvent(new InitializedEvent());
    }

    protected launchRequest(response: DebugProtocol.LaunchResponse, args: DebugProtocol.LaunchRequestArguments): void {
        // Implement your launch logic here
        this.sendResponse(response);
        this.sendEvent(new StoppedEvent('entry', CustomDebugSession.THREAD_ID));
    }

    protected threadsRequest(response: DebugProtocol.ThreadsResponse): void {
        response.body = {
            threads: [
                new Thread(CustomDebugSession.THREAD_ID, "Thread 1")
            ]
        };
        this.sendResponse(response);
    }

    // Implement other debug adapter methods as needed
}
```

To use this debug adapter in your extension:

```typescript
// src/extension.ts
import * as vscode from 'vscode';
import { CustomDebugSession } from './customDebugSession';

export function activate(context: vscode.ExtensionContext) {
    context.subscriptions.push(
        vscode.debug.registerDebugAdapterDescriptorFactory('customDebug', {
            createDebugAdapterDescriptor: (session: vscode.DebugSession) => {
                return new vscode.DebugAdapterInlineImplementation(new CustomDebugSession());
            }
        })
    );
}
```

## Debug Configuration Provider

A debug configuration provider can dynamically create debug configurations based on the workspace or user input:

```typescript
import * as vscode from 'vscode';

export class CustomDebugConfigProvider implements vscode.DebugConfigurationProvider {
    resolveDebugConfiguration(folder: vscode.WorkspaceFolder | undefined, config: vscode.DebugConfiguration, token?: vscode.CancellationToken): vscode.ProviderResult<vscode.DebugConfiguration> {
        if (!config.type && !config.request && !config.name) {
            const editor = vscode.window.activeTextEditor;
            if (editor && editor.document.languageId === 'yourLanguage') {
                config.type = 'customDebug';
                config.name = 'Launch';
                config.request = 'launch';
                config.program = '${file}';
            }
        }

        if (!config.program) {
            return vscode.window.showInformationMessage("Cannot find a program to debug").then(_ => {
                return undefined;  // abort launch
            });
        }

        return config;
    }
}

// In extension.ts
context.subscriptions.push(
    vscode.debug.registerDebugConfigurationProvider('customDebug', new CustomDebugConfigProvider())
);
```

## Custom Debug Console

You can customize the debug console to provide additional functionality:

```typescript
import * as vscode from 'vscode';

export class CustomDebugConsole implements vscode.DebugConsole {
    append(value: string): void {
        // Implement custom append logic
    }

    appendLine(value: string): void {
        // Implement custom appendLine logic
    }
}

// In your debug adapter
protected evaluateRequest(response: DebugProtocol.EvaluateResponse, args: DebugProtocol.EvaluateArguments): void {
    if (args.context === 'repl') {
        // Handle REPL input
        const result = this.evaluateExpression(args.expression);
        response.body = {
            result: result,
            variablesReference: 0
        };
    }
    this.sendResponse(response);
}

private evaluateExpression(expression: string): string {
    // Implement your expression evaluation logic here
    return `Result of ${expression}`;
}
```

## Breakpoint Handling

Implementing custom breakpoint handling allows for more control over when and how execution stops:

```typescript
protected setBreakPointsRequest(response: DebugProtocol.SetBreakpointsResponse, args: DebugProtocol.SetBreakpointsArguments): void {
    const path = args.source.path as string;
    const clientLines = args.lines || [];

    const breakpoints = clientLines.map(l => {
        const bp = new Breakpoint(true, l) as DebugProtocol.Breakpoint;
        bp.verified = true;
        return bp;
    });

    this.breakpoints.set(path, breakpoints);

    response.body = {
        breakpoints: breakpoints
    };
    this.sendResponse(response);
}

protected breakpointLocationsRequest(response: DebugProtocol.BreakpointLocationsResponse, args: DebugProtocol.BreakpointLocationsArguments, request?: DebugProtocol.Request): void {
    if (args.source.path) {
        const bps = this.breakpoints.get(args.source.path) || [];
        response.body = {
            breakpoints: bps.map(bp => {
                return {
                    line: bp.line
                };
            })
        };
    } else {
        response.body = {
            breakpoints: []
        };
    }
    this.sendResponse(response);
}
```

## Custom Debug UI

You can create custom UI elements for your debugger using the `vscode.WebviewView` API:

```typescript
import * as vscode from 'vscode';

export class CustomDebugView implements vscode.WebviewViewProvider {
    public static readonly viewType = 'customDebugView';

    private _view?: vscode.WebviewView;

    constructor(private readonly _extensionUri: vscode.Uri) {}

    resolveWebviewView(webviewView: vscode.WebviewView): void {
        this._view = webviewView;

        webviewView.webview.options = {
            enableScripts: true,
            localResourceRoots: [this._extensionUri]
        };

        webviewView.webview.html = this._getHtmlForWebview(webviewView.webview);

        webviewView.webview.onDidReceiveMessage(data => {
            switch (data.type) {
                case 'stepOver':
                    vscode.debug.activeDebugSession?.stepOver();
                    break;
            }
        });
    }

    private _getHtmlForWebview(webview: vscode.Webview): string {
        const scriptUri = webview.asWebviewUri(vscode.Uri.joinPath(this._extensionUri, 'media', 'main.js'));

        return `<!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Custom Debug View</title>
            </head>
            <body>
                <button id="stepOver">Step Over</button>
                <script src="${scriptUri}"></script>
            </body>
            </html>`;
    }
}

// In extension.ts
context.subscriptions.push(
    vscode.window.registerWebviewViewProvider(CustomDebugView.viewType, new CustomDebugView(context.extensionUri))
);
```

## AI-Assisted Debugging

You can integrate AI capabilities into your debugger to provide intelligent suggestions or automate certain debugging tasks:

```typescript
import * as vscode from 'vscode';
import { OpenAIApi, Configuration } from 'openai';

export class AIDebugAssistant {
    private openai: OpenAIApi;

    constructor(apiKey: string) {
        const configuration = new Configuration({ apiKey });
        this.openai = new OpenAIApi(configuration);
    }

    async analyzeException(error: Error): Promise<string> {
        const prompt = `Analyze this error and suggest possible fixes:\n${error.stack}`;
        const response = await this.openai.createCompletion({
            model: "text-davinci-002",
            prompt: prompt,
            max_tokens: 150
        });

        return response.data.choices[0].text || "Unable to analyze the error.";
    }
}

// In your debug adapter
protected exceptionInfoRequest(response: DebugProtocol.ExceptionInfoResponse, args: DebugProtocol.ExceptionInfoArguments): void {
    const aiAssistant = new AIDebugAssistant('your-api-key');
    aiAssistant.analyzeException(this.lastException).then(analysis => {
        response.body = {
            exceptionId: this.lastException.name,
            description: this.lastException.message,
            breakMode: 'always',
            details: {
                message: this.lastException.message,
                typeName: this.lastException.name,
                stackTrace: this.lastException.stack,
                aiAnalysis: analysis
            }
        };
        this.sendResponse(response);
    });
}
```

## Conclusion

These advanced debugging features can greatly enhance the debugging experience for users of your VSCode extension. By implementing custom debug adapters, configuration providers, and AI-assisted debugging, you can offer sophisticated debugging capabilities tailored to your specific use case or language.

## Exercises

1. Implement a basic debug adapter for a simple custom language.
2. Create a debug configuration provider that dynamically generates configurations based on the current file type.
3. Implement custom breakpoint handling that supports conditional breakpoints.
4. Create a custom debug console that provides syntax highlighting for your language.
5. Implement an AI-assisted debugging feature that suggests fixes for common errors in your language.

By completing these exercises, you'll gain hands-on experience with these advanced debugging features and be well-equipped to implement them in your own VSCode extensions.

