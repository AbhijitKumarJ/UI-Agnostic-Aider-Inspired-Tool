# Lesson 26: Advanced UI and UX Features for VSCode Extensions

## Table of Contents
1. [Introduction](#introduction)
2. [Custom Editor Provider](#custom-editor-provider)
3. [Tree View Data Provider with Drag and Drop](#tree-view-data-provider-with-drag-and-drop)
4. [Custom Webview Panel with State Management](#custom-webview-panel-with-state-management)
5. [Custom Welcome View](#custom-welcome-view)
6. [Status Bar Integration](#status-bar-integration)
7. [Custom Keybindings and Menus](#custom-keybindings-and-menus)
8. [Theming and Icon Customization](#theming-and-icon-customization)
9. [Conclusion](#conclusion)
10. [Exercises](#exercises)

## Introduction

This lesson focuses on advanced UI and UX features that can be implemented in VSCode extensions. These features can significantly enhance the user experience and provide rich, interactive interfaces for your extension.

## Custom Editor Provider

Custom editors allow you to create specialized editors for specific file types. Here's an example of a simple custom editor for a JSON-based file format:

```typescript
import * as vscode from 'vscode';

class CustomDocument implements vscode.CustomDocument {
    constructor(public uri: vscode.Uri, public content: any) {}

    dispose() {}
}

export class CustomEditorProvider implements vscode.CustomEditorProvider {
    private static readonly viewType = 'customEditor.json';

    constructor(private context: vscode.ExtensionContext) {}

    async openCustomDocument(uri: vscode.Uri): Promise<CustomDocument> {
        const content = await vscode.workspace.fs.readFile(uri);
        return new CustomDocument(uri, JSON.parse(content.toString()));
    }

    async resolveCustomEditor(document: CustomDocument, webviewPanel: vscode.WebviewPanel): Promise<void> {
        webviewPanel.webview.options = {
            enableScripts: true
        };

        webviewPanel.webview.html = this.getHtmlForWebview(webviewPanel.webview, document.content);

        webviewPanel.webview.onDidReceiveMessage(e => {
            switch (e.type) {
                case 'update':
                    this.updateTextDocument(document.uri, e.content);
                    return;
            }
        });
    }

    private getHtmlForWebview(webview: vscode.Webview, content: any): string {
        const nonce = this.getNonce();

        return `
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src ${webview.cspSource}; script-src 'nonce-${nonce}';">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Custom Editor</title>
            </head>
            <body>
                <div id="app">${JSON.stringify(content)}</div>
                <script nonce="${nonce}">
                    const vscode = acquireVsCodeApi();
                    const content = ${JSON.stringify(content)};
                    // Implement your custom editor UI here
                </script>
            </body>
            </html>
        `;
    }

    private async updateTextDocument(uri: vscode.Uri, content: any) {
        const edit = new vscode.WorkspaceEdit();
        edit.replace(
            uri,
            new vscode.Range(0, 0, Number.MAX_VALUE, Number.MAX_VALUE),
            JSON.stringify(content, null, 2)
        );
        await vscode.workspace.applyEdit(edit);
    }

    private getNonce() {
        let text = '';
        const possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        for (let i = 0; i < 32; i++) {
            text += possible.charAt(Math.floor(Math.random() * possible.length));
        }
        return text;
    }
}

// In extension.ts
context.subscriptions.push(
    vscode.window.registerCustomEditorProvider(
        CustomEditorProvider.viewType,
        new CustomEditorProvider(context)
    )
);
```

## Tree View Data Provider with Drag and Drop

Tree views are great for displaying hierarchical data. Adding drag and drop functionality can enhance user interaction:

```typescript
import * as vscode from 'vscode';

class TreeItem extends vscode.TreeItem {
    constructor(
        public readonly label: string,
        public readonly collapsibleState: vscode.TreeItemCollapsibleState,
        public children: TreeItem[] = []
    ) {
        super(label, collapsibleState);
    }
}

export class CustomTreeDataProvider implements vscode.TreeDataProvider<TreeItem>, vscode.TreeDragAndDropController<TreeItem> {
    private _onDidChangeTreeData: vscode.EventEmitter<TreeItem | undefined | null | void> = new vscode.EventEmitter<TreeItem | undefined | null | void>();
    readonly onDidChangeTreeData: vscode.Event<TreeItem | undefined | null | void> = this._onDidChangeTreeData.event;

    dropMimeTypes = ['application/vnd.code.tree.customtree'];
    dragMimeTypes = ['text/plain'];

    private data: TreeItem[];

    constructor() {
        this.data = [
            new TreeItem('Fruits', vscode.TreeItemCollapsibleState.Collapsed, [
                new TreeItem('Apple', vscode.TreeItemCollapsibleState.None),
                new TreeItem('Banana', vscode.TreeItemCollapsibleState.None),
            ]),
            new TreeItem('Vegetables', vscode.TreeItemCollapsibleState.Collapsed, [
                new TreeItem('Tomato', vscode.TreeItemCollapsibleState.None),
                new TreeItem('Carrot', vscode.TreeItemCollapsibleState.None),
            ])
        ];
    }

    getTreeItem(element: TreeItem): vscode.TreeItem | Thenable<vscode.TreeItem> {
        return element;
    }

    getChildren(element?: TreeItem): vscode.ProviderResult<TreeItem[]> {
        if (element === undefined) {
            return this.data;
        }
        return element.children;
    }

    getParent(element: TreeItem): vscode.ProviderResult<TreeItem> {
        return undefined; // Implement if you want to enable navigating back
    }

    async handleDrag(source: TreeItem[], treeDataTransfer: vscode.DataTransfer, token: vscode.CancellationToken): Promise<void> {
        treeDataTransfer.set('application/vnd.code.tree.customtree', new vscode.DataTransferItem(source));
    }

    async handleDrop(target: TreeItem | undefined, sources: vscode.DataTransfer, token: vscode.CancellationToken): Promise<void> {
        const transferItem = sources.get('application/vnd.code.tree.customtree');
        if (!transferItem) {
            return;
        }
        const transferredItems = transferItem.value as TreeItem[];
        
        if (!target) {
            // Dropped onto the root
            this.data.push(...transferredItems);
        } else {
            // Dropped onto a node
            target.children.push(...transferredItems);
        }

        // Remove items from their original location
        this.removeItems(this.data, transferredItems);

        this._onDidChangeTreeData.fire();
    }

    private removeItems(items: TreeItem[], itemsToRemove: TreeItem[]) {
        for (let i = items.length - 1; i >= 0; i--) {
            if (itemsToRemove.includes(items[i])) {
                items.splice(i, 1);
            } else if (items[i].children.length > 0) {
                this.removeItems(items[i].children, itemsToRemove);
            }
        }
    }
}

// In extension.ts
const treeDataProvider = new CustomTreeDataProvider();
context.subscriptions.push(
    vscode.window.createTreeView('customTreeView', { 
        treeDataProvider: treeDataProvider,
        dragAndDropController: treeDataProvider
    })
);
```

## Custom Webview Panel with State Management

Webview panels can provide rich, interactive interfaces. Here's an example with state management:

```typescript
import * as vscode from 'vscode';

export class CustomWebviewPanel {
    public static currentPanel: CustomWebviewPanel | undefined;
    private readonly _panel: vscode.WebviewPanel;
    private _disposables: vscode.Disposable[] = [];

    private constructor(panel: vscode.WebviewPanel, extensionUri: vscode.Uri) {
        this._panel = panel;
        this._panel.onDidDispose(() => this.dispose(), null, this._disposables);
        this._panel.webview.html = this._getWebviewContent(this._panel.webview, extensionUri);
        this._setWebviewMessageListener(this._panel.webview);
    }

    public static createOrShow(extensionUri: vscode.Uri) {
        const column = vscode.window.activeTextEditor ? vscode.window.activeTextEditor.viewColumn : undefined;
        if (CustomWebviewPanel.currentPanel) {
            CustomWebviewPanel.currentPanel._panel.reveal(column);
        } else {
            const panel = vscode.window.createWebviewPanel(
                'customWebview',
                'Custom Webview',
                column || vscode.ViewColumn.One,
                {
                    enableScripts: true,
                    localResourceRoots: [vscode.Uri.joinPath(extensionUri, 'media')]
                }
            );
            CustomWebviewPanel.currentPanel = new CustomWebviewPanel(panel, extensionUri);
        }
    }

    private _getWebviewContent(webview: vscode.Webview, extensionUri: vscode.Uri) {
        const scriptUri = webview.asWebviewUri(vscode.Uri.joinPath(extensionUri, 'media', 'main.js'));
        const styleUri = webview.asWebviewUri(vscode.Uri.joinPath(extensionUri, 'media', 'style.css'));

        return `
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <link href="${styleUri}" rel="stylesheet">
                <title>Custom Webview</title>
            </head>
            <body>
                <div id="app"></div>
                <script src="${scriptUri}"></script>
            </body>
            </html>
        `;
    }

    private _setWebviewMessageListener(webview: vscode.Webview) {
        webview.onDidReceiveMessage(
            message => {
                switch (message.command) {
                    case 'alert':
                        vscode.window.showErrorMessage(message.text);
                        return;
                }
            },
            undefined,
            this._disposables
        );
    }

    public dispose() {
        CustomWebviewPanel.currentPanel = undefined;
        this._panel.dispose();
        while (this._disposables.length) {
            const disposable = this._disposables.pop();
            if (disposable) {
                disposable.dispose();
            }
        }
    }
}

// In extension.ts
context.subscriptions.push(
    vscode.commands.registerCommand('extension.showCustomWebview', () => {
        CustomWebviewPanel.createOrShow(context.extensionUri);
    })
);
```

## Custom Welcome View

A custom welcome view can provide a great entry point for users to interact with your extension:

```typescript
import * as vscode from 'vscode';

export class WelcomeViewProvider implements vscode.WebviewViewProvider {
    public static readonly viewType = 'extension.welcomeView';

    private _view?: vscode.WebviewView;

    constructor(private readonly _extensionUri: vscode.Uri) {}

    resolveWebviewView(webviewView: vscode.WebviewView): void {
        this._view = webviewView;

        webviewView.webview.options = {
            enableScripts: true,
            localResourceRoots: [this._extensionUri]
        };

        webviewView.webview.html = this._getHtmlForWebview(webviewView.webview);

        webviewView.webview.onDidReceiveMessage(data => {
            switch (data.type) {
                case 'showCommand':
                    vscode.commands.executeCommand(data.value);
                    break;
            }
        });
    }

    private _getHtmlForWebview(webview: vscode.Webview) {
        const scriptUri = webview.asWebviewUri(vscode.Uri.joinPath(this._extensionUri, 'media', 'main.js'));
        const styleUri = webview.asWebviewUri(vscode.Uri.joinPath(this._extensionUri, 'media', 'style.css'));

        return `
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <link href="${styleUri}" rel="stylesheet">
                <title>Welcome</title>
            </head>
            <body>
                <h1>Welcome to My Extension</h1>
                <button id="showCommand">Show Command</button>
                <script src="${scriptUri}"></script>
            </body>
            </html>
        `;
    }
}

// In extension.ts
context.subscriptions.push(
    vscode.window.registerWebviewViewProvider(WelcomeViewProvider.viewType, new WelcomeViewProvider(context.extensionUri))
);
```

## Status Bar Integration

Status bar items can provide quick access to extension features:

```typescript
import * as vscode from 'vscode';

export class StatusBarManager {
    private statusBarItem: vscode.StatusBarItem;

    constructor() {
        this.statusBarItem = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Right, 100);
        this.statusBarItem.text = "$(zap) My Extension";
        this.statusBarItem.command = 'extension.showCustomWebview';
        this.statusBarItem.show();
    }

    public dispose() {
        this.statusBarItem.dispose();
    }
}

// In extension.ts
const statusBarManager = new StatusBarManager();
context.subscriptions.push(statusBarManager);
```

## Custom Keybindings and Menus

You can define custom keybindings and contribute to VSCode's menus:

```json
// In package.json
{
    "contributes": {
        "keybindings": [
            {
                "command": "extension.showCustomWebview",
                "key": "ctrl+shift+f10",
                "mac": "cmd+shift+f10"
            }
        ],
        "menus": {
            "editor/context": [
                {
                    "when": "editorFocus",
                    "command": "extension.showCustomWebview",
                    "group": "navigation"
                }
            ]
        }
    }
}
```

## Theming and Icon Customization

You can provide custom icons and respect VSCode's theming:

```json
// In package.json
{
    "contributes": {
        "iconThemes": [
            {
                "id": "myExtensionIcons",
                "label": "My Extension Icons",
                "path": "./fileicons/my-icon-theme.json"
            }
        ]
    }
}
```

```json
// my-icon-theme.json
{
    "iconDefinitions": {
        "_file": {
            "iconPath": "./file.svg"
        },
        "_folder": {
            "iconPath": "./folder.svg"
        }
    },
    "file": "_file",
    "folder": "_folder"
}
```

## Conclusion

These advanced UI and UX features can significantly enhance the user experience of your VSCode extension. By implementing custom editors, tree views with drag and drop, interactive webviews, and more, you can create rich, intuitive interfaces that make your extension stand out.

## Exercises

1. Create a custom editor for a simple markdown-based task list format.
2. Implement a tree view with drag and drop support for a file system-like structure.
3. Design a custom webview panel that allows users to interactively generate code snippets.
4. Create a welcome view for your extension that guides users through its main features.
5. Implement a status bar item that shows real-time information related to your extension's functionality.

By completing these exercises, you'll gain hands-on experience with these advanced UI and UX features and be well-equipped to implement them in your own VSCode extensions.