# Lesson 2: VSCode Extension API Deep Dive

## Table of Contents
1. [Introduction](#introduction)
2. [Understanding the VSCode Namespace and API](#understanding-the-vscode-namespace-and-api)
3. [Working with Workspaces](#working-with-workspaces)
4. [Working with Documents](#working-with-documents)
5. [Implementing Commands and Keybindings](#implementing-commands-and-keybindings)
6. [Using the Configuration API](#using-the-configuration-api)
7. [Exploring Language Server Protocol Basics](#exploring-language-server-protocol-basics)
8. [Exercises and Mini-Projects](#exercises-and-mini-projects)
9. [Conclusion](#conclusion)

## Introduction

In this lesson, we'll dive deeper into the VSCode Extension API, exploring its core components and how to leverage them to create powerful extensions. We'll cover working with workspaces and documents, implementing commands and keybindings, using the configuration API, and introduce the basics of the Language Server Protocol.

## Understanding the VSCode Namespace and API

The VSCode API is exposed through the `vscode` module, which you import in your extension:

```typescript
import * as vscode from 'vscode';
```

This module provides access to various namespaces and classes that allow you to interact with different parts of VSCode. Some key namespaces include:

- `vscode.window`: For working with the VSCode window and UI elements
- `vscode.workspace`: For working with the current workspace
- `vscode.languages`: For language-related functionality
- `vscode.commands`: For registering and executing commands

Let's explore some of these in detail.

## Working with Workspaces

A workspace in VSCode represents the root directory of your project. The `vscode.workspace` namespace provides APIs for interacting with the workspace.

Here are some common operations:

1. **Getting the workspace folders**:

```typescript
const workspaceFolders = vscode.workspace.workspaceFolders;
if (workspaceFolders) {
    workspaceFolders.forEach(folder => {
        console.log(folder.uri.fsPath);
    });
}
```

2. **Watching for file changes**:

```typescript
const watcher = vscode.workspace.createFileSystemWatcher('**/*.ts');
watcher.onDidChange(uri => {
    console.log(`File changed: ${uri.fsPath}`);
});
```

3. **Finding files in the workspace**:

```typescript
vscode.workspace.findFiles('**/*.ts', '**/node_modules/**').then(files => {
    files.forEach(file => console.log(file.fsPath));
});
```

## Working with Documents

Documents represent text files open in the editor. The `vscode.window.activeTextEditor` provides access to the currently active editor, and `vscode.workspace.textDocuments` gives you access to all open text documents.

Here are some examples:

1. **Getting the active editor's content**:

```typescript
const editor = vscode.window.activeTextEditor;
if (editor) {
    const document = editor.document;
    console.log(document.getText());
}
```

2. **Modifying document content**:

```typescript
vscode.window.activeTextEditor?.edit(editBuilder => {
    const position = new vscode.Position(0, 0);
    editBuilder.insert(position, 'Hello, World!');
});
```

3. **Listening for document changes**:

```typescript
vscode.workspace.onDidChangeTextDocument(event => {
    console.log(`Document ${event.document.uri} changed`);
});
```

## Implementing Commands and Keybindings

Commands are central to VSCode's extensibility model. They can be invoked from the Command Palette, assigned to keybindings, or called programmatically.

1. **Registering a command**:

```typescript
const disposable = vscode.commands.registerCommand('myExtension.helloWorld', () => {
    vscode.window.showInformationMessage('Hello World!');
});
context.subscriptions.push(disposable);
```

2. **Executing a command programmatically**:

```typescript
vscode.commands.executeCommand('workbench.action.toggleSidebarVisibility');
```

3. **Adding a keybinding**:

To add a keybinding, you need to add it to your `package.json`:

```json
"contributes": {
    "keybindings": [{
        "command": "myExtension.helloWorld",
        "key": "ctrl+f1",
        "mac": "cmd+f1",
        "when": "editorTextFocus"
    }]
}
```

## Using the Configuration API

VSCode provides a powerful configuration API that allows extensions to store and retrieve settings. These settings can be user-configurable or internal to your extension.

1. **Defining configuration in package.json**:

```json
"contributes": {
    "configuration": {
        "title": "MyExtension",
        "properties": {
            "myExtension.userName": {
                "type": "string",
                "default": "John Doe",
                "description": "The user's name for MyExtension"
            }
        }
    }
}
```

2. **Reading configuration values**:

```typescript
const config = vscode.workspace.getConfiguration('myExtension');
const userName = config.get('userName');
console.log(`Hello, ${userName}!`);
```

3. **Updating configuration values**:

```typescript
vscode.workspace.getConfiguration('myExtension').update('userName', 'Jane Doe', true);
```

## Exploring Language Server Protocol Basics

The Language Server Protocol (LSP) is a powerful tool for adding language features like auto-complete, go to definition, or error checking to your extension. While a full implementation is beyond the scope of this lesson, let's look at a basic setup:

1. **Install the vscode-languageclient package**:

```bash
npm install vscode-languageclient
```

2. **Basic Language Client setup**:

```typescript
import * as path from 'path';
import { workspace, ExtensionContext } from 'vscode';
import {
    LanguageClient,
    LanguageClientOptions,
    ServerOptions,
    TransportKind
} from 'vscode-languageclient/node';

let client: LanguageClient;

export function activate(context: ExtensionContext) {
    const serverModule = context.asAbsolutePath(path.join('server', 'out', 'server.js'));
    const serverOptions: ServerOptions = {
        run: { module: serverModule, transport: TransportKind.ipc },
        debug: {
            module: serverModule,
            transport: TransportKind.ipc,
            options: { execArgv: ['--nolazy', '--inspect=6009'] }
        }
    };

    const clientOptions: LanguageClientOptions = {
        documentSelector: [{ scheme: 'file', language: 'plaintext' }],
        synchronize: {
            fileEvents: workspace.createFileSystemWatcher('**/.clientrc')
        }
    };

    client = new LanguageClient(
        'languageServerExample',
        'Language Server Example',
        serverOptions,
        clientOptions
    );

    client.start();
}

export function deactivate(): Thenable<void> | undefined {
    if (!client) {
        return undefined;
    }
    return client.stop();
}
```

This sets up a basic Language Client that communicates with a Language Server (which you would implement separately) to provide language features for plain text files.

## Exercises and Mini-Projects

To reinforce your learning, try these exercises:

1. **Workspace Statistics**: Create an extension that displays statistics about the current workspace (e.g., number of files, total lines of code).

2. **Custom Explorer View**: Implement a custom explorer view that shows a tree of TODO comments found in the workspace.

3. **Code Formatter**: Create a simple code formatter for a language of your choice using the Document and Edit APIs.

4. **Settings Sync**: Build an extension that syncs a specific setting across multiple workspaces.

5. **Basic Language Support**: Implement basic language support (e.g., syntax highlighting and bracket matching) for a simple custom language.

## Conclusion

In this lesson, we've explored the core components of the VSCode Extension API, including working with workspaces and documents, implementing commands and keybindings, using the configuration API, and introducing the Language Server Protocol.

These powerful APIs allow you to create extensions that can significantly enhance the VSCode environment. As you progress, you'll be able to combine these features to create more complex and useful extensions.

In the next lesson, we'll dive into creating interactive UI components, exploring how to implement custom views and webviews in VSCode.

Remember to consult the [official VSCode Extension API documentation](https://code.visualstudio.com/api) for more detailed information on each of these topics. Happy coding!
