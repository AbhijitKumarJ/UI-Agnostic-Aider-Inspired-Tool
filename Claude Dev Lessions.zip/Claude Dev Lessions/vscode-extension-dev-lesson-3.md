# Lesson 3: Creating Interactive UI Components (Part 1)

## Table of Contents
1. [Introduction](#introduction)
2. [Introduction to VSCode Webviews](#introduction-to-vscode-webviews)
3. [Implementing a Basic Sidebar View](#implementing-a-basic-sidebar-view)
4. [Creating and Managing Webview Panels](#creating-and-managing-webview-panels)
5. [Handling Messages Between Extension and Webview](#handling-messages-between-extension-and-webview)
6. [Implementing Persistence and State Management in Webviews](#implementing-persistence-and-state-management-in-webviews)
7. [Exercises and Mini-Projects](#exercises-and-mini-projects)
8. [Conclusion](#conclusion)

## Introduction

In this lesson, we'll explore how to create interactive UI components in VSCode extensions. We'll focus on webviews, which allow you to create custom views with HTML, CSS, and JavaScript. We'll cover implementing sidebar views, creating webview panels, handling communication between your extension and webviews, and managing state in webviews.

## Introduction to VSCode Webviews

Webviews in VSCode are customizable views that use web technologies (HTML, CSS, and JavaScript) to render content. They provide a powerful way to create rich, interactive interfaces for your extension.

Key points about webviews:

1. They run in a separate context from your extension.
2. They use a subset of web APIs for security reasons.
3. They can communicate with your extension through message passing.

To use webviews, you'll need to add the following to your `package.json`:

```json
"activationEvents": [
    "onWebviewPanel:yourWebviewType"
],
"contributes": {
    "webviews": [
        {
            "type": "yourWebviewType",
            "name": "Your Webview",
            "icon": "path/to/icon.svg"
        }
    ]
}
```

## Implementing a Basic Sidebar View

Let's start by creating a basic sidebar view using webviews. First, update your `package.json`:

```json
"activationEvents": [
    "onView:yourViewId"
],
"contributes": {
    "views": {
        "explorer": [
            {
                "type": "webview",
                "id": "yourViewId",
                "name": "Your View"
            }
        ]
    }
}
```

Now, let's implement the view in your extension:

```typescript
import * as vscode from 'vscode';

export function activate(context: vscode.ExtensionContext) {
    const provider = new YourViewProvider(context.extensionUri);

    context.subscriptions.push(
        vscode.window.registerWebviewViewProvider("yourViewId", provider)
    );
}

class YourViewProvider implements vscode.WebviewViewProvider {
    constructor(private readonly _extensionUri: vscode.Uri) {}

    public resolveWebviewView(
        webviewView: vscode.WebviewView,
        context: vscode.WebviewViewResolveContext,
        _token: vscode.CancellationToken,
    ) {
        webviewView.webview.options = {
            enableScripts: true,
            localResourceRoots: [this._extensionUri]
        };

        webviewView.webview.html = this._getHtmlForWebview(webviewView.webview);
    }

    private _getHtmlForWebview(webview: vscode.Webview) {
        return `
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Your View</title>
            </head>
            <body>
                <h1>Hello from Your View!</h1>
            </body>
            </html>
        `;
    }
}
```

This creates a simple sidebar view with a "Hello" message.

## Creating and Managing Webview Panels

Webview panels are similar to sidebar views but appear as separate tabs. Here's how to create one:

```typescript
import * as vscode from 'vscode';

export function activate(context: vscode.ExtensionContext) {
    let disposable = vscode.commands.registerCommand('yourExtension.openWebview', () => {
        const panel = vscode.window.createWebviewPanel(
            'yourWebview',
            'Your Webview',
            vscode.ViewColumn.One,
            {
                enableScripts: true
            }
        );

        panel.webview.html = getWebviewContent();
    });

    context.subscriptions.push(disposable);
}

function getWebviewContent() {
    return `
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Your Webview</title>
        </head>
        <body>
            <h1>Hello from Your Webview!</h1>
        </body>
        </html>
    `;
}
```

To open this webview, you would call the `yourExtension.openWebview` command.

## Handling Messages Between Extension and Webview

Communication between your extension and webview is done through message passing. Here's an example:

In your extension:

```typescript
panel.webview.onDidReceiveMessage(
    message => {
        switch (message.command) {
            case 'alert':
                vscode.window.showErrorMessage(message.text);
                return;
        }
    },
    undefined,
    context.subscriptions
);
```

In your webview HTML:

```html
<script>
    const vscode = acquireVsCodeApi();
    
    function sendMessage() {
        vscode.postMessage({
            command: 'alert',
            text: 'Hello from the webview!'
        });
    }
</script>
<button onclick="sendMessage()">Send Message</button>
```

To send a message from your extension to the webview:

```typescript
panel.webview.postMessage({ command: 'refactor' });
```

And in your webview HTML:

```html
<script>
    window.addEventListener('message', event => {
        const message = event.data;
        switch (message.command) {
            case 'refactor':
                // Handle the message
                break;
        }
    });
</script>
```

## Implementing Persistence and State Management in Webviews

Webviews can maintain state even when they're not visible. Use the `vscode.getState()` and `vscode.setState()` methods in your webview:

```html
<script>
    const vscode = acquireVsCodeApi();

    // Restore old state
    const oldState = vscode.getState();
    let count = oldState ? oldState.count : 0;

    // Update state
    function updateCount() {
        count++;
        vscode.setState({ count: count });
        document.getElementById('count').textContent = count;
    }
</script>
<button onclick="updateCount()">Increment</button>
<p>Count: <span id="count">0</span></p>
```

In your extension, you can persist state across reloads:

```typescript
let state = context.workspaceState.get('yourExtensionState', { count: 0 });

// When updating state
context.workspaceState.update('yourExtensionState', state);
```

## Exercises and Mini-Projects

To reinforce your learning, try these exercises:

1. **To-Do List Sidebar**: Create a sidebar view that displays a to-do list. Allow adding, removing, and marking items as complete.

2. **Markdown Preview**: Implement a webview panel that shows a live preview of a markdown file as you edit it.

3. **Extension Settings UI**: Create a custom settings page for your extension using a webview.

4. **File Diff Viewer**: Build a webview panel that shows the diff between two files, with syntax highlighting.

5. **Interactive Code Snippet Library**: Develop a sidebar view that displays a library of code snippets. Allow users to search, preview, and insert snippets into their active editor.

## Conclusion

In this lesson, we've explored the basics of creating interactive UI components in VSCode extensions using webviews. We've covered implementing sidebar views and webview panels, handling communication between extensions and webviews, and managing state in webviews.

These techniques allow you to create rich, interactive interfaces for your extensions, greatly enhancing their functionality and user experience. As you progress, you'll be able to create more complex and sophisticated UI components.

In the next lesson, we'll dive deeper into UI components, exploring how to create more advanced interfaces, implement custom CSS styling and theming, and ensure accessibility in your custom UI components.

Remember to consult the [official VSCode Extension API documentation](https://code.visualstudio.com/api/extension-guides/webview) for more detailed information on webviews and UI components. Happy coding!
