# Lesson 4: Creating Interactive UI Components (Part 2)

## Table of Contents
1. [Introduction](#introduction)
2. [Building a Chat-like Interface in Webviews](#building-a-chat-like-interface-in-webviews)
3. [Implementing Custom CSS Styling and Theming](#implementing-custom-css-styling-and-theming)
4. [Creating Reusable UI Components](#creating-reusable-ui-components)
5. [Adding Icons and Visual Elements](#adding-icons-and-visual-elements)
6. [Ensuring Accessibility in Custom UI Components](#ensuring-accessibility-in-custom-ui-components)
7. [Exercises and Mini-Projects](#exercises-and-mini-projects)
8. [Conclusion](#conclusion)

## Introduction

In this lesson, we'll dive deeper into creating advanced UI components for VSCode extensions. We'll focus on building a chat-like interface, implementing custom styling and theming, creating reusable components, adding visual elements, and ensuring accessibility. These techniques will enable you to create rich, interactive, and user-friendly interfaces for your extensions.

## Building a Chat-like Interface in Webviews

Let's start by creating a chat-like interface in a webview panel. This will involve creating a message list, an input field, and handling message sending and receiving.

First, update your extension to create a webview panel:

```typescript
import * as vscode from 'vscode';

export function activate(context: vscode.ExtensionContext) {
    context.subscriptions.push(
        vscode.commands.registerCommand('yourExtension.openChat', () => {
            const panel = vscode.window.createWebviewPanel(
                'chatInterface',
                'Chat Interface',
                vscode.ViewColumn.One,
                {
                    enableScripts: true
                }
            );

            panel.webview.html = getChatWebviewContent();

            // Handle messages from the webview
            panel.webview.onDidReceiveMessage(
                message => {
                    switch (message.command) {
                        case 'sendMessage':
                            // Handle the sent message
                            vscode.window.showInformationMessage(`Sent: ${message.text}`);
                            // Echo the message back to the webview
                            panel.webview.postMessage({ command: 'receiveMessage', text: message.text });
                            return;
                    }
                },
                undefined,
                context.subscriptions
            );
        })
    );
}

function getChatWebviewContent() {
    return `
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Chat Interface</title>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    margin: 0;
                    padding: 0;
                    display: flex;
                    flex-direction: column;
                    height: 100vh;
                }
                #chat-container {
                    flex-grow: 1;
                    overflow-y: auto;
                    padding: 20px;
                }
                #input-container {
                    display: flex;
                    padding: 10px;
                }
                #message-input {
                    flex-grow: 1;
                    margin-right: 10px;
                }
            </style>
        </head>
        <body>
            <div id="chat-container"></div>
            <div id="input-container">
                <input type="text" id="message-input" placeholder="Type a message...">
                <button onclick="sendMessage()">Send</button>
            </div>
            <script>
                const vscode = acquireVsCodeApi();
                const chatContainer = document.getElementById('chat-container');
                const messageInput = document.getElementById('message-input');

                function sendMessage() {
                    const text = messageInput.value;
                    if (text) {
                        vscode.postMessage({
                            command: 'sendMessage',
                            text: text
                        });
                        messageInput.value = '';
                    }
                }

                window.addEventListener('message', event => {
                    const message = event.data;
                    switch (message.command) {
                        case 'receiveMessage':
                            const messageElement = document.createElement('p');
                            messageElement.textContent = message.text;
                            chatContainer.appendChild(messageElement);
                            chatContainer.scrollTop = chatContainer.scrollHeight;
                            break;
                    }
                });

                // Allow sending message with Enter key
                messageInput.addEventListener('keypress', function(event) {
                    if (event.key === 'Enter') {
                        sendMessage();
                    }
                });
            </script>
        </body>
        </html>
    `;
}
```

This creates a basic chat interface with a message list and an input field. Messages sent from the input are echoed back to the chat.

## Implementing Custom CSS Styling and Theming

To make your UI components fit seamlessly into VSCode, you should use VSCode's built-in CSS variables for theming. Here's how you can modify the chat interface to use VSCode's theming:

```html
<style>
    body {
        font-family: var(--vscode-font-family);
        color: var(--vscode-foreground);
        background-color: var(--vscode-editor-background);
    }
    #chat-container {
        flex-grow: 1;
        overflow-y: auto;
        padding: 20px;
    }
    #input-container {
        display: flex;
        padding: 10px;
        background-color: var(--vscode-input-background);
    }
    #message-input {
        flex-grow: 1;
        margin-right: 10px;
        background-color: var(--vscode-input-background);
        color: var(--vscode-input-foreground);
        border: 1px solid var(--vscode-input-border);
        padding: 5px;
    }
    button {
        background-color: var(--vscode-button-background);
        color: var(--vscode-button-foreground);
        border: none;
        padding: 5px 10px;
    }
    button:hover {
        background-color: var(--vscode-button-hoverBackground);
    }
</style>
```

This styling will automatically adapt to the user's chosen VSCode theme.

## Creating Reusable UI Components

For more complex interfaces, it's beneficial to create reusable components. Let's create a message component for our chat interface:

```javascript
class ChatMessage extends HTMLElement {
    constructor() {
        super();
        const shadow = this.attachShadow({mode: 'open'});
        const message = this.getAttribute('message');
        const sender = this.getAttribute('sender');

        shadow.innerHTML = `
            <style>
                .message {
                    background-color: var(--vscode-editor-background);
                    border: 1px solid var(--vscode-input-border);
                    border-radius: 5px;
                    padding: 10px;
                    margin-bottom: 10px;
                }
                .sender {
                    font-weight: bold;
                    margin-bottom: 5px;
                }
            </style>
            <div class="message">
                <div class="sender">${sender}</div>
                <div>${message}</div>
            </div>
        `;
    }
}

customElements.define('chat-message', ChatMessage);
```

Now you can use this component in your chat interface:

```javascript
function addMessage(sender, text) {
    const messageElement = document.createElement('chat-message');
    messageElement.setAttribute('sender', sender);
    messageElement.setAttribute('message', text);
    chatContainer.appendChild(messageElement);
    chatContainer.scrollTop = chatContainer.scrollHeight;
}
```

## Adding Icons and Visual Elements

VSCode provides a set of built-in icons (Codicons) that you can use in your extensions. To use these icons, you need to include the Codicon CSS file in your webview:

```html
<style>
    @font-face {
        font-family: "codicon";
        src: url("${webview.asWebviewUri(vscode.Uri.joinPath(context.extensionUri, 'node_modules', '@vscode/codicons', 'dist', 'codicon.ttf'))}") format("truetype");
    }
</style>
```

Then you can use the icons in your HTML:

```html
<button onclick="sendMessage()">
    <i class="codicon codicon-send"></i>
    Send
</button>
```

## Ensuring Accessibility in Custom UI Components

Accessibility is crucial for creating inclusive user interfaces. Here are some tips to improve accessibility in your custom UI components:

1. Use semantic HTML elements (e.g., `<button>`, `<input>`, `<label>`) whenever possible.
2. Provide alternative text for images and icons.
3. Ensure sufficient color contrast.
4. Make sure all interactive elements are keyboard accessible.
5. Use ARIA attributes when necessary.

Let's update our chat interface with some accessibility improvements:

```html
<div id="chat-container" role="log" aria-live="polite"></div>
<div id="input-container">
    <label for="message-input" class="visually-hidden">Type a message</label>
    <input type="text" id="message-input" placeholder="Type a message..." aria-describedby="send-button">
    <button id="send-button" onclick="sendMessage()" aria-label="Send message">
        <i class="codicon codicon-send" aria-hidden="true"></i>
        Send
    </button>
</div>
<style>
    .visually-hidden {
        position: absolute;
        width: 1px;
        height: 1px;
        padding: 0;
        margin: -1px;
        overflow: hidden;
        clip: rect(0, 0, 0, 0);
        white-space: nowrap;
        border: 0;
    }
</style>
```

These changes improve the accessibility of the chat interface by providing proper labeling and ARIA attributes.

## Exercises and Mini-Projects

To reinforce your learning, try these exercises:

1. **Emoji Picker**: Add an emoji picker to the chat interface. Include a button that opens a panel with selectable emojis.

2. **Message Formatting**: Implement basic text formatting in the chat (bold, italic, code blocks) using markdown-style syntax.

3. **Theme Switcher**: Create a button that allows users to switch between light and dark themes in your webview.

4. **Autocomplete Component**: Develop a reusable autocomplete component that can be used in various parts of your extension.

5. **Accessible Form**: Create a form with various input types, ensuring it's fully accessible. Include proper labeling, error messaging, and keyboard navigation.

## Conclusion

In this lesson, we've explored advanced techniques for creating interactive UI components in VSCode extensions. We've covered building a chat-like interface, implementing custom styling and theming, creating reusable components, adding visual elements, and ensuring accessibility.

These skills will allow you to create sophisticated, user-friendly interfaces for your extensions that integrate seamlessly with VSCode. Remember to always consider accessibility and theming to ensure your extension provides a great experience for all users.

In the next lesson, we'll dive into advanced VSCode integration, exploring how to create custom tree views, implement custom explorers, and extend VSCode's built-in functionality.

Don't forget to refer to the [VSCode Extension API documentation](https://code.visualstudio.com/api) and the [Webview API guide](https://code.visualstudio.com/api/extension-guides/webview) for more detailed information. Happy coding!
