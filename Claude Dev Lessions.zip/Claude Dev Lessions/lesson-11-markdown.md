# Lesson 11: AI Service Integration (Part 1)

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Overview of AI Services and APIs](#overview-of-ai-services-and-apis)
4. [Designing a Provider-Agnostic Interface](#designing-a-provider-agnostic-interface)
5. [Implementing OpenAI's API Integration](#implementing-openais-api-integration)
6. [Adding Support for Anthropic's Claude API](#adding-support-for-anthropics-claude-api)
7. [Creating a Fallback and Load Balancing System](#creating-a-fallback-and-load-balancing-system)
8. [Integrating the AI Service into the Extension](#integrating-the-ai-service-into-the-extension)
9. [Conclusion](#conclusion)
10. [Exercises](#exercises)

## Introduction

In this lesson, we'll explore the integration of AI services into our VSCode extension. We'll focus on creating a provider-agnostic interface that allows us to seamlessly work with multiple AI services, such as OpenAI, Anthropic, and others. By the end of this lesson, you'll have a flexible system for interacting with various AI providers, setting the foundation for advanced AI-powered features in your extension.

## Project Structure

Before we dive into the implementation, let's review the project structure we'll be working with:

```
- src/
    - ClaudeDev.ts
    - extension.ts
    - api/
        - anthropic.ts
        - bedrock.ts
        - gemini.ts
        - index.ts
        - ollama.ts
        - openai-native.ts
        - openai.ts
        - openrouter.ts
        - vertex.ts
    - shared/
        - api.ts
        - ClaudeRequestResult.ts
        - ExtensionMessage.ts
        - Tool.ts
        - WebviewMessage.ts
    - utils/
        - validate.ts
- webview-ui/
    - src/
        - components/
            - ApiOptions.tsx
        - context/
            - ExtensionStateContext.tsx
        - utils/
            - vscode.ts
- package.json
- tsconfig.json
```

We'll be focusing on the `src/api/` directory and creating new files for each AI service integration.

## Overview of AI Services and APIs

Before we dive into the implementation, let's briefly discuss some popular AI services and their APIs:

1. **OpenAI**: Offers GPT models through their API, known for high-quality language generation.
2. **Anthropic**: Provides the Claude model, which excels in following instructions and handling complex tasks.
3. **Google's Vertex AI**: Offers various AI models, including language models and specialized tools.
4. **AWS Bedrock**: Amazon's AI service that provides access to various foundation models.

Each of these services has its own API structure, authentication methods, and unique features. Our goal is to create an abstraction layer that allows us to work with these services interchangeably.

## Designing a Provider-Agnostic Interface

To create a flexible system that can work with multiple AI providers, we'll design an abstract interface that defines the common operations we need. This approach allows us to easily switch between providers or add new ones in the future.

Let's create a new file `src/api/index.ts` with our core interface:

```typescript
import { Anthropic } from "@anthropic-ai/sdk"
import { ApiConfiguration, ModelInfo } from "../shared/api"

export interface ApiHandlerMessageResponse {
    message: Anthropic.Messages.Message
    userCredits?: number
}

export interface ApiHandler {
    createMessage(
        systemPrompt: string,
        messages: Anthropic.Messages.MessageParam[],
        tools: Anthropic.Messages.Tool[]
    ): Promise<ApiHandlerMessageResponse>

    getModel(): { id: string; info: ModelInfo }
}

export function buildApiHandler(configuration: ApiConfiguration): ApiHandler {
    const { apiProvider, ...options } = configuration
    switch (apiProvider) {
        case "anthropic":
            return new AnthropicHandler(options)
        case "openrouter":
            return new OpenRouterHandler(options)
        case "bedrock":
            return new AwsBedrockHandler(options)
        case "vertex":
            return new VertexHandler(options)
        case "openai":
            return new OpenAiHandler(options)
        case "ollama":
            return new OllamaHandler(options)
        case "gemini":
            return new GeminiHandler(options)
        case "openai-native":
            return new OpenAiNativeHandler(options)
        default:
            return new AnthropicHandler(options)
    }
}
```

This interface defines two key methods:
1. `createMessage`: Sends a request to the AI service with a system prompt, conversation history, and available tools.
2. `getModel`: Retrieves information about the currently selected model.

The `buildApiHandler` function is a factory that creates the appropriate handler based on the provided configuration.

## Implementing OpenAI's API Integration

Now, let's implement the OpenAI integration. Create a new file `src/api/openai.ts`:

```typescript
import { Anthropic } from "@anthropic-ai/sdk"
import OpenAI from "openai"
import { ApiHandler, ApiHandlerMessageResponse } from "."
import { ApiHandlerOptions, ModelInfo, openAiModelInfoSaneDefaults } from "../shared/api"
import { convertToAnthropicMessage, convertToOpenAiMessages } from "../utils/openai-format"

export class OpenAiHandler implements ApiHandler {
    private options: ApiHandlerOptions
    private client: OpenAI

    constructor(options: ApiHandlerOptions) {
        this.options = options
        this.client = new OpenAI({
            baseURL: this.options.openAiBaseUrl,
            apiKey: this.options.openAiApiKey,
        })
    }

    async createMessage(
        systemPrompt: string,
        messages: Anthropic.Messages.MessageParam[],
        tools: Anthropic.Messages.Tool[]
    ): Promise<ApiHandlerMessageResponse> {
        const openAiMessages: OpenAI.Chat.ChatCompletionMessageParam[] = [
            { role: "system", content: systemPrompt },
            ...convertToOpenAiMessages(messages),
        ]
        const openAiTools: OpenAI.Chat.ChatCompletionTool[] = tools.map((tool) => ({
            type: "function",
            function: {
                name: tool.name,
                description: tool.description,
                parameters: tool.input_schema,
            },
        }))
        const createParams: OpenAI.Chat.Completions.ChatCompletionCreateParamsNonStreaming = {
            model: this.options.openAiModelId ?? "",
            messages: openAiMessages,
            tools: openAiTools,
            tool_choice: "auto",
        }
        const completion = await this.client.chat.completions.create(createParams)
        const errorMessage = (completion as any).error?.message
        if (errorMessage) {
            throw new Error(errorMessage)
        }
        const anthropicMessage = convertToAnthropicMessage(completion)
        return { message: anthropicMessage }
    }

    getModel(): { id: string; info: ModelInfo } {
        return {
            id: this.options.openAiModelId ?? "",
            info: openAiModelInfoSaneDefaults,
        }
    }
}
```

This implementation:
1. Creates an OpenAI client with the provided API key and base URL.
2. Converts our standardized message format to OpenAI's expected format.
3. Sends a request to the OpenAI API with the converted messages and tools.
4. Converts the OpenAI response back to our standardized format.

Note that we're using utility functions `convertToOpenAiMessages` and `convertToAnthropicMessage` to handle the format conversions. You'll need to implement these in a separate utility file.

## Adding Support for Anthropic's Claude API

Now, let's implement the Anthropic Claude API integration. Create a new file `src/api/anthropic.ts`:

```typescript
import { Anthropic } from "@anthropic-ai/sdk"
import { ApiHandler, ApiHandlerMessageResponse } from "."
import { anthropicDefaultModelId, AnthropicModelId, anthropicModels, ApiHandlerOptions, ModelInfo } from "../shared/api"

export class AnthropicHandler implements ApiHandler {
    private options: ApiHandlerOptions
    private client: Anthropic

    constructor(options: ApiHandlerOptions) {
        this.options = options
        this.client = new Anthropic({
            apiKey: this.options.apiKey,
            baseURL: this.options.anthropicBaseUrl || undefined,
        })
    }

    async createMessage(
        systemPrompt: string,
        messages: Anthropic.Messages.MessageParam[],
        tools: Anthropic.Messages.Tool[]
    ): Promise<ApiHandlerMessageResponse> {
        const modelId = this.getModel().id
        const message = await this.client.messages.create({
            model: modelId,
            max_tokens: this.getModel().info.maxTokens,
            system: systemPrompt,
            messages,
            tools,
            tool_choice: { type: "auto" },
        })
        return { message }
    }

    getModel(): { id: AnthropicModelId; info: ModelInfo } {
        const modelId = this.options.apiModelId
        if (modelId && modelId in anthropicModels) {
            const id = modelId as AnthropicModelId
            return { id, info: anthropicModels[id] }
        }
        return { id: anthropicDefaultModelId, info: anthropicModels[anthropicDefaultModelId] }
    }
}
```

This implementation:
1. Creates an Anthropic client with the provided API key and optional base URL.
2. Sends a request to the Anthropic API using the standardized message and tool format.
3. Returns the response directly, as it's already in our standardized format.

## Creating a Fallback and Load Balancing System

To create a robust system that can handle multiple providers, we'll implement a simple fallback and load balancing mechanism. Create a new file `src/api/multi-provider.ts`:

```typescript
import { ApiHandler, ApiHandlerMessageResponse } from "."
import { ApiConfiguration } from "../shared/api"
import { AnthropicHandler } from "./anthropic"
import { OpenAiHandler } from "./openai"
// Import other handlers as needed

export class MultiProviderHandler implements ApiHandler {
    private handlers: ApiHandler[]

    constructor(configurations: ApiConfiguration[]) {
        this.handlers = configurations.map((config) => {
            switch (config.apiProvider) {
                case "anthropic":
                    return new AnthropicHandler(config)
                case "openai":
                    return new OpenAiHandler(config)
                // Add other providers here
                default:
                    throw new Error(`Unsupported provider: ${config.apiProvider}`)
            }
        })
    }

    async createMessage(
        systemPrompt: string,
        messages: Anthropic.Messages.MessageParam[],
        tools: Anthropic.Messages.Tool[]
    ): Promise<ApiHandlerMessageResponse> {
        for (const handler of this.handlers) {
            try {
                return await handler.createMessage(systemPrompt, messages, tools)
            } catch (error) {
                console.error(`Error with provider ${handler.constructor.name}:`, error)
                // Continue to the next provider
            }
        }
        throw new Error("All providers failed")
    }

    getModel() {
        // Return the model of the first successful handler
        for (const handler of this.handlers) {
            try {
                return handler.getModel()
            } catch (error) {
                console.error(`Error getting model for ${handler.constructor.name}:`, error)
            }
        }
        throw new Error("Unable to get model information from any provider")
    }
}
```

This multi-provider handler:
1. Takes an array of API configurations and creates the appropriate handlers.
2. Tries each provider in order when making a request, moving to the next on failure.
3. Returns the model information from the first successful handler.

## Integrating the AI Service into the Extension

Now that we have our AI service integration set up, let's update the main `ClaudeDev` class to use our new API handler. Update `src/ClaudeDev.ts`:

```typescript
import { ApiHandler, buildApiHandler } from "./api"
import { ApiConfiguration } from "./shared/api"

export class ClaudeDev {
    private api: ApiHandler

    constructor(apiConfiguration: ApiConfiguration) {
        this.api = buildApiHandler(apiConfiguration)
    }

    async handleUserInput(userInput: string) {
        // Prepare messages and tools
        const systemPrompt = "You are a helpful AI assistant."
        const messages = [{ role: "user", content: userInput }]
        const tools = [] // Define your tools here

        try {
            const response = await this.api.createMessage(systemPrompt, messages, tools)
            // Process and display the response
            console.log(response.message.content)
        } catch (error) {
            console.error("Error calling AI service:", error)
        }
    }

    // Other methods...
}
```

This integration:
1. Creates an API handler based on the provided configuration.
2. Uses the handler to send messages to the AI service.
3. Processes and displays the response.

You'll need to update other parts of your extension to use this `ClaudeDev` class and handle user input appropriately.

## Conclusion

In this lesson, we've created a flexible, provider-agnostic system for integrating AI services into our VSCode extension. We've implemented handlers for OpenAI and Anthropic, and created a multi-provider system for fallback and load balancing.

This approach allows us to:
1. Easily switch between AI providers based on availability or user preference.
2. Add new providers in the future without changing the core logic of our extension.
3. Implement fallback mechanisms to ensure reliability.

In the next lesson, we'll dive deeper into handling streaming responses, managing rate limits, and optimizing token usage across different AI services.

## Exercises

1. Implement a handler for Google's Vertex AI or AWS Bedrock, following the pattern established for OpenAI and Anthropic.

2. Extend the `MultiProviderHandler` to support weighted load balancing, where some providers are used more frequently than others. You can do this by adding a `weight` property to the `ApiConfiguration` interface and using it in the `MultiProviderHandler`:

```typescript
interface WeightedApiConfiguration extends ApiConfiguration {
    weight: number
}

class WeightedMultiProviderHandler implements ApiHandler {
    private handlers: { handler: ApiHandler; weight: number }[]

    constructor(configurations: WeightedApiConfiguration[]) {
        this.handlers = configurations.map((config) => ({
            handler: buildApiHandler(config),
            weight: config.weight
        }))
    }

    async createMessage(
        systemPrompt: string,
        messages: Anthropic.Messages.MessageParam[],
        tools: Anthropic.Messages.Tool[]
    ): Promise<ApiHandlerMessageResponse> {
        const totalWeight = this.handlers.reduce((sum, h) => sum + h.weight, 0)
        const randomValue = Math.random() * totalWeight

        let cumulativeWeight = 0
        for (const { handler, weight } of this.handlers) {
            cumulativeWeight += weight
            if (randomValue <= cumulativeWeight) {
                try {
                    return await handler.createMessage(systemPrompt, messages, tools)
                } catch (error) {
                    console.error(`Error with provider ${handler.constructor.name}:`, error)
                    // Continue to the next provider
                }
            }
        }
        throw new Error("All providers failed")
    }

    // ... implement getModel() ...
}
```

3. Create a configuration UI in the extension that allows users to add and prioritize multiple AI providers. You can do this by updating the `ApiOptions.tsx` component in the webview:

```tsx
import React, { useState } from 'react'
import { VSCodeDropdown, VSCodeOption, VSCodeTextField, VSCodeButton } from '@vscode/webview-ui-toolkit/react'
import { ApiConfiguration } from '../../../src/shared/api'

interface ApiOptionsProps {
    configurations: ApiConfiguration[]
    onConfigurationsChange: (configurations: ApiConfiguration[]) => void
}

const ApiOptions: React.FC<ApiOptionsProps> = ({ configurations, onConfigurationsChange }) => {
    const [newProvider, setNewProvider] = useState<ApiConfiguration>({
        apiProvider: 'anthropic',
        apiKey: '',
        weight: 1
    })

    const handleAddProvider = () => {
        onConfigurationsChange([...configurations, newProvider])
        setNewProvider({ apiProvider: 'anthropic', apiKey: '', weight: 1 })
    }

    const handleRemoveProvider = (index: number) => {
        const newConfigurations = configurations.filter((_, i) => i !== index)
        onConfigurationsChange(newConfigurations)
    }

    const handleProviderChange = (index: number, updates: Partial<ApiConfiguration>) => {
        const newConfigurations = configurations.map((config, i) =>
            i === index ? { ...config, ...updates } : config
        )
        onConfigurationsChange(newConfigurations)
    }

    return (
        <div>
            <h2>AI Providers</h2>
            {configurations.map((config, index) => (
                <div key={index} style={{ marginBottom: '20px' }}>
                    <VSCodeDropdown
                        value={config.apiProvider}
                        onChange={(e) => handleProviderChange(index, { apiProvider: e.target.value })}
                    >
                        <VSCodeOption value="anthropic">Anthropic</VSCodeOption>
                        <VSCodeOption value="openai">OpenAI</VSCodeOption>
                        {/* Add other providers here */}
                    </VSCodeDropdown>
                    <VSCodeTextField
                        value={config.apiKey}
                        onChange={(e) => handleProviderChange(index, { apiKey: e.target.value })}
                        placeholder="API Key"
                    />
                    <VSCodeTextField
                        type="number"
                        value={config.weight.toString()}
                        onChange={(e) => handleProviderChange(index, { weight: Number(e.target.value) })}
                        placeholder="Weight"
                    />
                    <VSCodeButton onClick={() => handleRemoveProvider(index)}>Remove</VSCodeButton>
                </div>
            ))}
            <div>
                <VSCodeDropdown
                    value={newProvider.apiProvider}
                    onChange={(e) => setNewProvider({ ...newProvider, apiProvider: e.target.value })}
                >
                    <VSCodeOption value="anthropic">Anthropic</VSCodeOption>
                    <VSCodeOption value="openai">OpenAI</VSCodeOption>
                    {/* Add other providers here */}
                </VSCodeDropdown>
                <VSCodeTextField
                    value={newProvider.apiKey}
                    onChange={(e) => setNewProvider({ ...newProvider, apiKey: e.target.value })}
                    placeholder="API Key"
                />
                <VSCodeTextField
                    type="number"
                    value={newProvider.weight.toString()}
                    onChange={(e) => setNewProvider({ ...newProvider, weight: Number(e.target.value) })}
                    placeholder="Weight"
                />
                <VSCodeButton onClick={handleAddProvider}>Add Provider</VSCodeButton>
            </div>
        </div>
    )
}

export default ApiOptions
```

This component allows users to add, remove, and configure multiple AI providers, including setting weights for load balancing.

4. Implement a caching layer that stores responses for frequently asked queries to reduce API usage. You can create a new `CachingApiHandler` that wraps another `ApiHandler`:

```typescript
import { ApiHandler, ApiHandlerMessageResponse } from "."
import { Anthropic } from "@anthropic-ai/sdk"

interface CacheEntry {
    response: ApiHandlerMessageResponse
    timestamp: number
}

export class CachingApiHandler implements ApiHandler {
    private handler: ApiHandler
    private cache: Map<string, CacheEntry> = new Map()
    private cacheDuration: number // in milliseconds

    constructor(handler: ApiHandler, cacheDuration: number = 3600000) { // default 1 hour
        this.handler = handler
        this.cacheDuration = cacheDuration
    }

    private getCacheKey(systemPrompt: string, messages: Anthropic.Messages.MessageParam[], tools: Anthropic.Messages.Tool[]): string {
        return JSON.stringify({ systemPrompt, messages, tools })
    }

    async createMessage(
        systemPrompt: string,
        messages: Anthropic.Messages.MessageParam[],
        tools: Anthropic.Messages.Tool[]
    ): Promise<ApiHandlerMessageResponse> {
        const cacheKey = this.getCacheKey(systemPrompt, messages, tools)
        const cachedEntry = this.cache.get(cacheKey)

        if (cachedEntry && (Date.now() - cachedEntry.timestamp) < this.cacheDuration) {
            console.log("Cache hit")
            return cachedEntry.response
        }

        console.log("Cache miss")
        const response = await this.handler.createMessage(systemPrompt, messages, tools)
        this.cache.set(cacheKey, { response, timestamp: Date.now() })
        return response
    }

    getModel() {
        return this.handler.getModel()
    }
}
```

To use this caching layer, you would wrap your existing handler:

```typescript
const baseHandler = buildApiHandler(apiConfiguration)
const cachingHandler = new CachingApiHandler(baseHandler)
```

5. Implement a simple rate limiting mechanism to prevent exceeding API rate limits. Create a `RateLimitingApiHandler`:

```typescript
import { ApiHandler, ApiHandlerMessageResponse } from "."
import { Anthropic } from "@anthropic-ai/sdk"

export class RateLimitingApiHandler implements ApiHandler {
    private handler: ApiHandler
    private requestsPerMinute: number
    private requestTimestamps: number[] = []

    constructor(handler: ApiHandler, requestsPerMinute: number = 60) {
        this.handler = handler
        this.requestsPerMinute = requestsPerMinute
    }

    private async waitForRateLimit(): Promise<void> {
        const now = Date.now()
        this.requestTimestamps = this.requestTimestamps.filter(t => (now - t) < 60000)

        if (this.requestTimestamps.length >= this.requestsPerMinute) {
            const oldestTimestamp = this.requestTimestamps[0]
            const waitTime = 60000 - (now - oldestTimestamp)
            await new Promise(resolve => setTimeout(resolve, waitTime))
        }

        this.requestTimestamps.push(Date.now())
    }

    async createMessage(
        systemPrompt: string,
        messages: Anthropic.Messages.MessageParam[],
        tools: Anthropic.Messages.Tool[]
    ): Promise<ApiHandlerMessageResponse> {
        await this.waitForRateLimit()
        return this.handler.createMessage(systemPrompt, messages, tools)
    }

    getModel() {
        return this.handler.getModel()
    }
}
```

You can use this rate limiting handler by wrapping your existing handler:

```typescript
const baseHandler = buildApiHandler(apiConfiguration)
const rateLimitingHandler = new RateLimitingApiHandler(baseHandler, 60) // 60 requests per minute
```

These exercises will help you create a more robust and flexible AI integration system for your VSCode extension. They cover important aspects such as load balancing, user configuration, caching, and rate limiting, which are crucial for building a production-ready AI-powered extension.

Remember to test each implementation thoroughly and consider edge cases, such as handling errors gracefully and providing appropriate feedback to the user when rate limits are reached or when the cache is being used.