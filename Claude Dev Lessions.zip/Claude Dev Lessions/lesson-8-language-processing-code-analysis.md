# Lesson 8: Language Processing and Code Analysis in VSCode Extensions

## Introduction

In this lesson, we'll explore language processing and code analysis techniques in VSCode extensions. We'll focus on integrating tree-sitter for robust code parsing, implementing language-agnostic code analysis, and creating features like an AST explorer and code metrics generator. We'll use the Claude Dev project as a reference, examining how it implements these concepts.

## Project Structure

Let's start by looking at the relevant parts of the Claude Dev project structure:

```
claude-dev/
├── src/
│   ├── ClaudeDev.ts
│   ├── extension.ts
│   ├── parse-source-code/
│   │   ├── index.ts
│   │   ├── languageParser.ts
│   │   └── queries/
│   │       ├── c-sharp.ts
│   │       ├── c.ts
│   │       ├── cpp.ts
│   │       ├── go.ts
│   │       ├── index.ts
│   │       ├── java.ts
│   │       ├── javascript.ts
│   │       ├── php.ts
│   │       ├── python.ts
│   │       ├── ruby.ts
│   │       ├── rust.ts
│   │       ├── swift.ts
│   │       └── typescript.ts
│   └── utils/
│       └── getLanguageFromPath.ts
├── webview-ui/
│   └── src/
│       └── components/
│           └── CodeAccordian.tsx
├── package.json
└── tsconfig.json
```

This structure highlights the main files we'll be referencing throughout the lesson, particularly the `parse-source-code` directory which contains the code analysis implementation.

## 1. Integrating Tree-sitter for Robust Code Parsing

Claude Dev uses tree-sitter for parsing source code. Tree-sitter is a parser generator tool and an incremental parsing library that can build a concrete syntax tree for a source file and efficiently update the syntax tree as the source file is edited.

Let's look at how Claude Dev integrates tree-sitter:

```typescript
// In src/parse-source-code/languageParser.ts
import Parser from "web-tree-sitter"

export interface LanguageParser {
    [key: string]: {
        parser: Parser
        query: Parser.Query
    }
}

async function loadLanguage(langName: string) {
    return await Parser.Language.load(path.join(__dirname, `tree-sitter-${langName}.wasm`))
}

let isParserInitialized = false

async function initializeParser() {
    if (!isParserInitialized) {
        await Parser.init()
        isParserInitialized = true
    }
}

export async function loadRequiredLanguageParsers(filesToParse: string[]): Promise<LanguageParser> {
    await initializeParser()
    const extensionsToLoad = new Set(filesToParse.map((file) => path.extname(file).toLowerCase().slice(1)))
    const parsers: LanguageParser = {}
    for (const ext of extensionsToLoad) {
        let language: Parser.Language
        let query: Parser.Query
        switch (ext) {
            case "js":
            case "jsx":
                language = await loadLanguage("javascript")
                query = language.query(javascriptQuery)
                break
            // ... (other language cases)
        }
        const parser = new Parser()
        parser.setLanguage(language)
        parsers[ext] = { parser, query }
    }
    return parsers
}
```

This code sets up tree-sitter parsers for different languages. It loads the appropriate WASM files for each language and initializes the parsers.

## 2. Implementing Language-Agnostic Code Analysis

Claude Dev implements language-agnostic code analysis by using tree-sitter queries. These queries allow it to extract specific information from the parsed syntax trees regardless of the programming language.

Here's an example of how it's implemented:

```typescript
// In src/parse-source-code/index.ts
async function parseFile(filePath: string, languageParsers: LanguageParser): Promise<string | undefined> {
    const fileContent = await fs.readFile(filePath, "utf8")
    const ext = path.extname(filePath).toLowerCase().slice(1)

    const { parser, query } = languageParsers[ext] || {}
    if (!parser || !query) {
        return `Unsupported file type: ${filePath}`
    }

    let formattedOutput = ""

    try {
        const tree = parser.parse(fileContent)
        const captures = query.captures(tree.rootNode)

        captures.sort((a, b) => a.node.startPosition.row - b.node.startPosition.row)

        const lines = fileContent.split("\n")
        let lastLine = -1

        captures.forEach((capture) => {
            const { node, name } = capture
            const startLine = node.startPosition.row
            const endLine = node.endPosition.row

            if (lastLine !== -1 && startLine > lastLine + 1) {
                formattedOutput += "|----\n"
            }

            if (name.includes("name") && lines[startLine]) {
                formattedOutput += `│${lines[startLine]}\n`
            }

            lastLine = endLine
        })
    } catch (error) {
        console.log(`Error parsing file: ${error}\n`)
    }

    if (formattedOutput.length > 0) {
        return `|----\n${formattedOutput}|----\n`
    }
    return undefined
}
```

This function parses a file using the appropriate tree-sitter parser and query, then extracts and formats relevant information from the syntax tree.

## 3. Creating an AST Explorer

While Claude Dev doesn't include a full AST explorer, we can create a simple one based on its parsing functionality. Here's an example of how you could implement a basic AST explorer:

```typescript
// In a new file, e.g., src/ASTExplorer.ts
import * as vscode from 'vscode'
import Parser from 'web-tree-sitter'
import { loadRequiredLanguageParsers } from './parse-source-code/languageParser'

export class ASTExplorer implements vscode.TreeDataProvider<ASTNode> {
    private _onDidChangeTreeData: vscode.EventEmitter<ASTNode | undefined | null | void> = new vscode.EventEmitter<ASTNode | undefined | null | void>()
    readonly onDidChangeTreeData: vscode.Event<ASTNode | undefined | null | void> = this._onDidChangeTreeData.event

    constructor(private context: vscode.ExtensionContext) {}

    refresh(): void {
        this._onDidChangeTreeData.fire()
    }

    getTreeItem(element: ASTNode): vscode.TreeItem {
        return element
    }

    async getChildren(element?: ASTNode): Promise<ASTNode[]> {
        if (!element) {
            const editor = vscode.window.activeTextEditor
            if (editor) {
                const document = editor.document
                const parser = await this.getParser(document.fileName)
                if (parser) {
                    const tree = parser.parse(document.getText())
                    return [new ASTNode(tree.rootNode)]
                }
            }
        } else {
            return element.node.children.map(child => new ASTNode(child))
        }
        return []
    }

    private async getParser(fileName: string): Promise<Parser | undefined> {
        const ext = path.extname(fileName).toLowerCase().slice(1)
        const parsers = await loadRequiredLanguageParsers([fileName])
        return parsers[ext]?.parser
    }
}

class ASTNode extends vscode.TreeItem {
    constructor(public readonly node: Parser.SyntaxNode) {
        super(
            node.type,
            node.children.length > 0 ? vscode.TreeItemCollapsibleState.Collapsed : vscode.TreeItemCollapsibleState.None
        )
        this.tooltip = `${node.type} (${node.startPosition.row}:${node.startPosition.column} - ${node.endPosition.row}:${node.endPosition.column})`
        this.description = node.text.length > 20 ? node.text.slice(0, 20) + '...' : node.text
    }
}

// In extension.ts
export function activate(context: vscode.ExtensionContext) {
    // ... other activation code ...
    const astExplorer = new ASTExplorer(context)
    vscode.window.registerTreeDataProvider('astExplorer', astExplorer)
}

// In package.json
{
    "contributes": {
        "views": {
            "explorer": [
                {
                    "id": "astExplorer",
                    "name": "AST Explorer"
                }
            ]
        }
    }
}
```

This implementation creates a tree view that displays the AST of the currently active file.

## 4. Implementing Multi-Language Support for Code Analysis

Claude Dev already supports multiple languages through its use of tree-sitter. The `queries` directory contains language-specific queries for extracting information from different programming languages.

Here's an example of a language-specific query (for JavaScript):

```typescript
// In src/parse-source-code/queries/javascript.ts
export default `
(
  (comment)* @doc
  .
  [
    (function_declaration
      name: (identifier) @name)
    (generator_function_declaration
      name: (identifier) @name)
  ] @definition.function
  (#strip! @doc "^[\\s\\*/]+|^[\\s\\*/]$")
  (#select-adjacent! @doc @definition.function)
)

// ... more query patterns ...
`
```

These queries are used in the `parseFile` function we saw earlier to extract relevant information from the AST.

## 5. Generating Code Metrics and Complexity Analysis

While Claude Dev doesn't directly implement code metrics or complexity analysis, we can extend its functionality to include these features. Here's an example of how you might implement a simple complexity analysis:

```typescript
// In a new file, e.g., src/CodeMetrics.ts
import * as vscode from 'vscode'
import Parser from 'web-tree-sitter'
import { loadRequiredLanguageParsers } from './parse-source-code/languageParser'

export async function analyzeComplexity(document: vscode.TextDocument): Promise<number> {
    const parser = await getParser(document.fileName)
    if (!parser) {
        return 0
    }

    const tree = parser.parse(document.getText())
    return calculateComplexity(tree.rootNode)
}

function calculateComplexity(node: Parser.SyntaxNode): number {
    let complexity = 0

    // Increment complexity for control flow statements
    switch (node.type) {
        case 'if_statement':
        case 'for_statement':
        case 'while_statement':
        case 'switch_statement':
        case 'catch_clause':
            complexity++
            break
    }

    // Recursively calculate complexity for child nodes
    for (const child of node.children) {
        complexity += calculateComplexity(child)
    }

    return complexity
}

async function getParser(fileName: string): Promise<Parser | undefined> {
    const ext = path.extname(fileName).toLowerCase().slice(1)
    const parsers = await loadRequiredLanguageParsers([fileName])
    return parsers[ext]?.parser
}

// In extension.ts
export function activate(context: vscode.ExtensionContext) {
    // ... other activation code ...
    let disposable = vscode.commands.registerCommand('extension.analyzeComplexity', async () => {
        const editor = vscode.window.activeTextEditor
        if (editor) {
            const complexity = await analyzeComplexity(editor.document)
            vscode.window.showInformationMessage(`Cyclomatic complexity: ${complexity}`)
        }
    })
    context.subscriptions.push(disposable)
}
```

This implementation calculates a simple cyclomatic complexity metric by counting control flow statements in the AST.

## Conclusion

In this lesson, we've explored language processing and code analysis techniques in VSCode extensions, using the Claude Dev project as a reference. We've covered integrating tree-sitter for robust parsing, implementing language-agnostic code analysis, creating an AST explorer, supporting multiple languages, and generating code metrics.

These techniques allow you to create powerful extensions that can understand and analyze code across multiple programming languages. By leveraging tools like tree-sitter and implementing custom analysis algorithms, you can provide valuable insights to developers and enhance their coding experience in VSCode.

## Exercises

1. Extend the AST explorer to highlight the corresponding code in the editor when a node is selected in the tree view.
2. Implement a "find all references" feature using tree-sitter queries.
3. Create a code smell detector that uses AST analysis to identify potential issues in the code.
4. Implement a more comprehensive complexity analysis that considers factors like nesting depth and cognitive complexity.

By completing these exercises, you'll gain hands-on experience with language processing and code analysis in VSCode extensions, and explore ways to provide valuable insights to developers.

