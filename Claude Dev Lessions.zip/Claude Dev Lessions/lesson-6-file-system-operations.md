# Lesson 6: File System Operations and Workspace Management in VSCode Extensions

## Introduction

In this lesson, we'll explore how to work with the file system and manage workspaces in VSCode extensions. We'll use the Claude Dev project as a reference to demonstrate real-world implementations of these concepts. By the end of this lesson, you'll be able to create, read, update, and delete files programmatically, manage workspace folders, and implement a custom file explorer with advanced features.

## Project Structure

Before we dive into the details, let's take a look at the relevant parts of the Claude Dev project structure:

```
claude-dev/
├── src/
│   ├── ClaudeDev.ts
│   ├── extension.ts
│   ├── providers/
│   │   └── ClaudeDevProvider.ts
│   └── utils/
│       ├── open-file.ts
│       └── ripgrep.ts
├── webview-ui/
│   └── src/
│       └── components/
│           └── CodeAccordian.tsx
├── package.json
└── tsconfig.json
```

This structure highlights the main files we'll be referencing throughout the lesson.

## 1. Working with the VSCode File System API

VSCode provides a powerful API for working with the file system. Let's start by examining how to perform basic file operations.

### Reading Files

To read a file, we can use the `vscode.workspace.fs.readFile` method. Here's an example from the `ClaudeDev` class:

```typescript
async readFile(relPath?: string): Promise<[boolean, ToolResponse]> {
    if (relPath === undefined) {
        this.consecutiveMistakeCount++
        return [false, await this.sayAndCreateMissingParamError("read_file", "path")]
    }
    this.consecutiveMistakeCount = 0
    try {
        const absolutePath = path.resolve(cwd, relPath)
        const content = await extractTextFromFile(absolutePath)

        // ... (code for user confirmation and response)

        return [false, content]
    } catch (error) {
        const errorString = `Error reading file: ${JSON.stringify(serializeError(error))}`
        await this.say(
            "error",
            `Error reading file:\n${error.message ?? JSON.stringify(serializeError(error), null, 2)}`
        )
        return [false, await this.formatToolError(errorString)]
    }
}
```

This method demonstrates error handling, path resolution, and the use of a helper function `extractTextFromFile` to read the file content.

### Writing Files

Writing files is done using the `vscode.workspace.fs.writeFile` method. Here's a simplified example from the `ClaudeDev` class:

```typescript
async writeToFile(relPath?: string, newContent?: string): Promise<[boolean, ToolResponse]> {
    // ... (parameter validation)

    try {
        const absolutePath = path.resolve(cwd, relPath)
        const fileExists = await fs.access(absolutePath).then(() => true).catch(() => false)

        // ... (code for handling existing files and user confirmation)

        await fs.writeFile(absolutePath, newContent)

        // ... (code for opening the file in the editor)

        return [false, await this.formatToolResult(`The content was successfully saved to ${relPath}.`)]
    } catch (error) {
        // ... (error handling)
    }
}
```

This method showcases how to check if a file exists, write content to it, and handle potential errors.

## 2. Implementing File Watching and Change Detection

VSCode allows extensions to watch for file changes using the `vscode.workspace.createFileSystemWatcher` API. While Claude Dev doesn't explicitly use this feature, here's an example of how you could implement it:

```typescript
const watcher = vscode.workspace.createFileSystemWatcher("**/*.ts")

watcher.onDidChange((uri) => {
    console.log(`File ${uri.fsPath} has been changed`)
})

watcher.onDidCreate((uri) => {
    console.log(`File ${uri.fsPath} has been created`)
})

watcher.onDidDelete((uri) => {
    console.log(`File ${uri.fsPath} has been deleted`)
})
```

This code creates a watcher for all TypeScript files and logs messages when files are changed, created, or deleted.

## 3. Managing Workspace Folders and Multi-root Workspaces

VSCode supports multi-root workspaces, allowing users to work with multiple project folders in a single window. Let's look at how Claude Dev handles workspace folders:

```typescript
// In ClaudeDevProvider.ts
const cwd =
    vscode.workspace.workspaceFolders?.map((folder) => folder.uri.fsPath).at(0) ?? path.join(os.homedir(), "Desktop")
```

This code gets the first workspace folder or defaults to the user's desktop if no workspace is open.

To work with multiple workspace folders, you can iterate through `vscode.workspace.workspaceFolders`:

```typescript
vscode.workspace.workspaceFolders?.forEach((folder) => {
    console.log(`Workspace folder: ${folder.name} (${folder.uri.fsPath})`)
})
```

## 4. Implementing a Custom File Explorer with Advanced Features

While Claude Dev doesn't implement a full custom file explorer, it does provide file listing functionality. Let's look at how it's implemented:

```typescript
// In ClaudeDev.ts
async listFiles(relDirPath?: string, recursiveRaw?: string): Promise<[boolean, ToolResponse]> {
    // ... (parameter validation)

    try {
        const recursive = recursiveRaw?.toLowerCase() === "true"
        const absolutePath = path.resolve(cwd, relDirPath)
        const files = await listFiles(absolutePath, recursive)
        const result = this.formatFilesList(absolutePath, files)

        // ... (code for user confirmation)

        return [false, await this.formatToolResult(result)]
    } catch (error) {
        // ... (error handling)
    }
}
```

This method uses a helper function `listFiles` to get the file list and then formats it for display.

To implement a more advanced file explorer, you could create a custom TreeDataProvider. Here's a basic example:

```typescript
class FileExplorer implements vscode.TreeDataProvider<vscode.TreeItem> {
    private _onDidChangeTreeData: vscode.EventEmitter<vscode.TreeItem | undefined | null | void> = new vscode.EventEmitter<vscode.TreeItem | undefined | null | void>()
    readonly onDidChangeTreeData: vscode.Event<vscode.TreeItem | undefined | null | void> = this._onDidChangeTreeData.event

    refresh(): void {
        this._onDidChangeTreeData.fire()
    }

    getTreeItem(element: vscode.TreeItem): vscode.TreeItem {
        return element
    }

    getChildren(element?: vscode.TreeItem): Thenable<vscode.TreeItem[]> {
        if (element) {
            return Promise.resolve([])
        } else {
            const workspaceFolders = vscode.workspace.workspaceFolders
            return Promise.resolve(
                workspaceFolders?.map(
                    folder => new vscode.TreeItem(folder.name, vscode.TreeItemCollapsibleState.Collapsed)
                ) || []
            )
        }
    }
}

// Register the TreeDataProvider
vscode.window.registerTreeDataProvider('fileExplorer', new FileExplorer())
```

This basic file explorer shows workspace folders as top-level items. You can expand on this to show files and subfolders, and add features like file icons, context menus, and drag-and-drop functionality.

## Conclusion

In this lesson, we've explored file system operations and workspace management in VSCode extensions, using Claude Dev as a reference. We've covered reading and writing files, watching for file changes, managing workspace folders, and implementing a basic custom file explorer.

These concepts are crucial for building extensions that interact with the user's project files and structure. As you develop your extensions, consider how you can use these APIs to provide valuable functionality to your users while respecting VSCode's multi-root workspace capabilities.

## Exercises

1. Implement a function that recursively lists all files in a workspace, ignoring specified directories (e.g., node_modules, .git).
2. Create a custom file explorer that shows only files of a specific type (e.g., .ts, .js) and allows filtering by filename.
3. Implement a file watcher that automatically runs a linter on TypeScript files when they change.
4. Create a function that allows users to create a new file or folder through a custom UI in your extension.

By completing these exercises, you'll gain hands-on experience with file system operations and workspace management in VSCode extensions.

