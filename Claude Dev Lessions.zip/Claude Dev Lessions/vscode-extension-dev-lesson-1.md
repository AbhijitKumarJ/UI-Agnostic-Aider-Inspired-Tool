# Lesson 1: Introduction to VSCode Extension Development

## Table of Contents
1. [Overview of VSCode's Extensibility Model](#overview-of-vscodes-extensibility-model)
2. [Setting Up the Development Environment](#setting-up-the-development-environment)
3. [Creating Your First Extension (Hello World)](#creating-your-first-extension-hello-world)
4. [Understanding the Extension Manifest (package.json)](#understanding-the-extension-manifest-packagejson)
5. [Exploring the Extension Lifecycle](#exploring-the-extension-lifecycle)
6. [Debugging and Testing Extensions](#debugging-and-testing-extensions)
7. [Exercises and Mini-Projects](#exercises-and-mini-projects)
8. [Conclusion](#conclusion)

## Overview of VSCode's Extensibility Model

Visual Studio Code (VSCode) is designed with extensibility at its core. This means that developers can create extensions to add new features, modify existing functionality, and integrate external tools seamlessly into the VSCode environment.

The VSCode extensibility model is built on a few key concepts:

1. **Extension Host**: VSCode runs extensions in a separate process called the Extension Host. This isolation ensures stability and performance of the main VSCode process.

2. **Activation Events**: Extensions are loaded on-demand, triggered by specific events to optimize performance.

3. **Contribution Points**: These are predefined areas in VSCode where extensions can add functionality, such as commands, menus, or views.

4. **VSCode API**: A rich set of APIs that allow extensions to interact with various parts of VSCode, including the editor, workspace, and UI.

5. **Extension Manifest**: A JSON file (package.json) that defines the extension's metadata and contribution points.

Understanding these concepts is crucial for developing effective VSCode extensions.

## Setting Up the Development Environment

To start developing VSCode extensions, you'll need to set up your environment. Here's a step-by-step guide:

1. **Install Node.js**: VSCode extensions are developed using Node.js. Download and install the latest LTS version from [nodejs.org](https://nodejs.org/).

2. **Install VSCode**: If you haven't already, download and install VSCode from [code.visualstudio.com](https://code.visualstudio.com/).

3. **Install Yeoman and the VSCode Extension Generator**:
   Open a terminal and run the following commands:

   ```bash
   npm install -g yo generator-code
   ```

   This installs Yeoman (a scaffolding tool) and the VSCode extension generator.

4. **Install Visual Studio Code Extension Manager (vsce)**:
   Run the following command:

   ```bash
   npm install -g @vscode/vsce
   ```

   This tool is used for packaging and publishing VSCode extensions.

With these tools installed, you're ready to start creating VSCode extensions!

## Creating Your First Extension (Hello World)

Let's create a simple "Hello World" extension to understand the basics. This extension will add a command that displays a "Hello World" message.

1. **Generate the Extension Scaffold**:
   In your terminal, navigate to the directory where you want to create your extension and run:

   ```bash
   yo code
   ```

2. **Follow the Prompts**:
   - Choose "New Extension (TypeScript)"
   - Name your extension (e.g., "helloworld")
   - Provide an identifier (e.g., "helloworld")
   - Provide a description
   - Choose to initialize a git repository (optional)
   - Choose to use strict null checks for TypeScript (recommended)

3. **Explore the Generated Project Structure**:
   After the generator completes, you'll have a new folder with the following structure:

   ```
   helloworld/
   ├── .vscode/
   │   ├── launch.json
   │   └── tasks.json
   ├── src/
   │   └── extension.ts
   ├── .gitignore
   ├── .vscodeignore
   ├── package.json
   ├── README.md
   ├── CHANGELOG.md
   └── tsconfig.json
   ```

4. **Understand the Key Files**:
   - `src/extension.ts`: This is where your extension's code lives.
   - `package.json`: The extension manifest file.
   - `.vscode/launch.json`: Configuration for debugging your extension.

5. **Modify the Extension Code**:
   Open `src/extension.ts` and replace its contents with the following:

   ```typescript
   import * as vscode from 'vscode';

   export function activate(context: vscode.ExtensionContext) {
       console.log('Congratulations, your extension "helloworld" is now active!');

       let disposable = vscode.commands.registerCommand('helloworld.helloWorld', () => {
           vscode.window.showInformationMessage('Hello World from HelloWorld!');
       });

       context.subscriptions.push(disposable);
   }

   export function deactivate() {}
   ```

6. **Update the package.json**:
   Open `package.json` and add the following to the `contributes` section:

   ```json
   "contributes": {
       "commands": [
           {
               "command": "helloworld.helloWorld",
               "title": "Hello World"
           }
       ]
   }
   ```

7. **Run the Extension**:
   - Press `F5` to start debugging.
   - In the new VSCode window that opens (Extension Development Host), press `Ctrl+Shift+P` (or `Cmd+Shift+P` on macOS) to open the command palette.
   - Type "Hello World" and select your command.
   - You should see the "Hello World" message appear!

Congratulations! You've just created your first VSCode extension.

## Understanding the Extension Manifest (package.json)

The `package.json` file is crucial for your extension. It defines metadata about your extension and specifies how it integrates with VSCode. Let's break down the key sections:

```json
{
    "name": "helloworld",
    "displayName": "HelloWorld",
    "description": "A simple Hello World extension",
    "version": "0.0.1",
    "engines": {
        "vscode": "^1.60.0"
    },
    "categories": [
        "Other"
    ],
    "activationEvents": [
        "onCommand:helloworld.helloWorld"
    ],
    "main": "./out/extension.js",
    "contributes": {
        "commands": [
            {
                "command": "helloworld.helloWorld",
                "title": "Hello World"
            }
        ]
    },
    "scripts": {
        "vscode:prepublish": "npm run compile",
        "compile": "tsc -p ./",
        "watch": "tsc -watch -p ./",
        "pretest": "npm run compile && npm run lint",
        "lint": "eslint src --ext ts",
        "test": "node ./out/test/runTest.js"
    },
    "devDependencies": {
        "@types/vscode": "^1.60.0",
        "@types/node": "14.x",
        "@typescript-eslint/eslint-plugin": "^4.26.0",
        "@typescript-eslint/parser": "^4.26.0",
        "eslint": "^7.27.0",
        "typescript": "^4.3.2"
    }
}
```

Key sections to understand:

- **name, displayName, description**: Metadata about your extension.
- **version**: The current version of your extension.
- **engines**: Specifies the version of VSCode your extension is compatible with.
- **categories**: Helps users find your extension in the marketplace.
- **activationEvents**: Defines when your extension should be activated.
- **main**: The entry point of your extension.
- **contributes**: Defines the contributions your extension makes to VSCode (e.g., commands, configuration, views).
- **scripts**: NPM scripts for development tasks.
- **devDependencies**: Development dependencies for your extension.

## Exploring the Extension Lifecycle

Understanding the lifecycle of a VSCode extension is crucial for efficient development. The main stages are:

1. **Installation**: When a user installs your extension.

2. **Activation**: When your extension is loaded into memory. This is controlled by the `activationEvents` in your `package.json`.

3. **Execution**: Your extension runs and performs its tasks.

4. **Deactivation**: When VSCode is shutting down or your extension is being disabled/uninstalled.

Let's look at the key functions in the extension lifecycle:

```typescript
import * as vscode from 'vscode';

// This method is called when your extension is activated
export function activate(context: vscode.ExtensionContext) {
    console.log('Extension is now active!');

    // Register your commands, create UI components, etc. here
    let disposable = vscode.commands.registerCommand('helloworld.helloWorld', () => {
        vscode.window.showInformationMessage('Hello World!');
    });

    // Add the disposable to the context subscriptions
    context.subscriptions.push(disposable);
}

// This method is called when your extension is deactivated
export function deactivate() {
    console.log('Extension is now deactivated!');
    // Clean up resources, stop processes, etc. here
}
```

- The `activate` function is called when your extension is activated. This is where you set up your extension's functionality.
- The `deactivate` function is called when your extension is deactivated. Use this to clean up any resources your extension is using.

## Debugging and Testing Extensions

Debugging and testing are essential parts of extension development. VSCode provides excellent tools for both:

### Debugging

1. **Launch Configuration**: The `.vscode/launch.json` file in your project contains the debug configuration. It should look something like this:

   ```json
   {
       "version": "0.2.0",
       "configurations": [
           {
               "name": "Run Extension",
               "type": "extensionHost",
               "request": "launch",
               "args": [
                   "--extensionDevelopmentPath=${workspaceFolder}"
               ],
               "outFiles": [
                   "${workspaceFolder}/out/**/*.js"
               ],
               "preLaunchTask": "${defaultBuildTask}"
           }
       ]
   }
   ```

2. **Start Debugging**: Press `F5` or use the "Run and Debug" view to start debugging your extension.

3. **Breakpoints**: Set breakpoints in your TypeScript files to pause execution and inspect variables.

4. **Debug Console**: Use `console.log` statements in your code to output debug information to the Debug Console.

### Testing

VSCode extensions typically use Mocha for testing. Here's how to set up and run tests:

1. **Test Files**: Create test files in a `src/test` directory with names ending in `.test.ts`.

2. **Example Test**:

   ```typescript
   import * as assert from 'assert';
   import * as vscode from 'vscode';

   suite('Extension Test Suite', () => {
       vscode.window.showInformationMessage('Start all tests.');

       test('Sample test', () => {
           assert.strictEqual(-1, [1, 2, 3].indexOf(5));
           assert.strictEqual(-1, [1, 2, 3].indexOf(0));
       });
   });
   ```

3. **Run Tests**: Use the `npm test` command to run your tests.

4. **Coverage**: Consider using a tool like `istanbul` to measure code coverage.

## Exercises and Mini-Projects

To reinforce your learning, try these exercises:

1. **Command Counter**: Create an extension that adds a command which, when executed, displays how many times it has been called.

2. **Status Bar Item**: Add a status bar item that shows the current time and updates every second.

3. **File Explorer Decorator**: Create an extension that adds an icon to JavaScript files in the file explorer.

4. **Snippet Provider**: Implement an extension that provides custom code snippets for a programming language of your choice.

5. **Theme Switcher**: Create an extension that allows users to quickly switch between light and dark themes using a command.

## Conclusion

In this lesson, we've covered the fundamentals of VSCode extension development. We've learned about VSCode's extensibility model, set up our development environment, created a basic extension, explored the extension manifest and lifecycle, and looked at debugging and testing techniques.

VSCode extension development opens up a world of possibilities for customizing and enhancing your development environment. As you progress, you'll be able to create more complex extensions that can significantly improve your productivity and the productivity of other developers.

In the next lesson, we'll dive deeper into the VSCode Extension API, exploring how to work with workspaces, documents, and implement more advanced commands and features.

Remember, the key to mastering extension development is practice. Try out the exercises, experiment with different APIs, and don't hesitate to consult the [official VSCode Extension API documentation](https://code.visualstudio.com/api) for more detailed information.

Happy coding!
