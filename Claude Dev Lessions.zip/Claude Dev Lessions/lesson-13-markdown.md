# Lesson 13: Building an AI Coding Assistant (Part 1)

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Designing the Architecture for an AI Coding Assistant](#designing-the-architecture-for-an-ai-coding-assistant)
4. [Implementing Context-Aware Code Completion](#implementing-context-aware-code-completion)
5. [Creating an AI-Powered Code Reviewer](#creating-an-ai-powered-code-reviewer)
6. [Generating Unit Tests with AI Assistance](#generating-unit-tests-with-ai-assistance)
7. [Implementing Natural Language to Code Translation](#implementing-natural-language-to-code-translation)
8. [Conclusion](#conclusion)
9. [Exercises](#exercises)

## Introduction

In this lesson, we'll start building advanced AI-powered coding features for our VSCode extension. We'll focus on implementing context-aware code completion, an AI-powered code reviewer, unit test generation, and natural language to code translation. These features will significantly enhance the productivity of developers using our extension.

## Project Structure

Before we dive into the implementation, let's review the updated project structure:

```
- src/
    - ClaudeDev.ts
    - extension.ts
    - api/
        - anthropic.ts
        - bedrock.ts
        - gemini.ts
        - index.ts
        - ollama.ts
        - openai-native.ts
        - openai.ts
        - openrouter.ts
        - vertex.ts
        - streaming-handler.ts
        - rate-limiting-handler.ts
        - retry-handler.ts
        - caching-handler.ts
    - features/
        - code-completion.ts    (new)
        - code-review.ts        (new)
        - unit-test-gen.ts      (new)
        - nl-to-code.ts         (new)
    - shared/
        - api.ts
        - ClaudeRequestResult.ts
        - ExtensionMessage.ts
        - Tool.ts
        - WebviewMessage.ts
    - utils/
        - token-counter.ts
        - context-management.ts
        - code-parser.ts        (new)
        - prompt-templates.ts   (new)
        - validate.ts
- webview-ui/
    - src/
        - components/
            - ApiOptions.tsx
            - StreamingOutput.tsx
            - CodeCompletionView.tsx  (new)
            - CodeReviewView.tsx      (new)
            - UnitTestView.tsx        (new)
            - NLToCodeView.tsx        (new)
        - context/
            - ExtensionStateContext.tsx
        - utils/
            - vscode.ts
- package.json
- tsconfig.json
```

We'll be adding several new files to implement the AI coding assistant features discussed in this lesson.

## Designing the Architecture for an AI Coding Assistant

Before we implement specific features, let's design a high-level architecture for our AI coding assistant. We'll create a base class that our features can extend, which will handle common functionality like interacting with the AI API and managing context.

Create a new file `src/features/base-feature.ts`:

```typescript
import { ApiHandler } from '../api'
import { countTokens } from '../utils/token-counter'
import { truncateConversationHistory } from '../utils/context-management'

export abstract class BaseFeature {
    protected api: ApiHandler
    protected maxTokens: number

    constructor(api: ApiHandler, maxTokens: number) {
        this.api = api
        this.maxTokens = maxTokens
    }

    protected async getAIResponse(prompt: string, context: string): Promise<string> {
        const systemPrompt = "You are an AI coding assistant. Provide concise and accurate responses."
        const messages = [
            { role: "system", content: systemPrompt },
            { role: "user", content: `Context:\n${context}\n\nTask:\n${prompt}` }
        ]

        const truncatedMessages = truncateConversationHistory(messages, this.maxTokens)
        const response = await this.api.createMessage(systemPrompt, truncatedMessages, [])
        return response.message.content.toString()
    }

    protected getFileContent(filePath: string): string {
        // Implementation to get file content from VSCode API
        // This is a placeholder and should be replaced with actual VSCode API calls
        return "File content placeholder"
    }

    protected getProjectStructure(): string {
        // Implementation to get project structure
        // This is a placeholder and should be replaced with actual VSCode API calls
        return "Project structure placeholder"
    }
}
```

This base class provides common functionality that our specific features will use, such as interacting with the AI API and retrieving file content and project structure.

## Implementing Context-Aware Code Completion

Let's implement context-aware code completion. Create a new file `src/features/code-completion.ts`:

```typescript
import { BaseFeature } from './base-feature'
import * as vscode from 'vscode'

export class CodeCompletionFeature extends BaseFeature {
    async provideCompletionItems(document: vscode.TextDocument, position: vscode.Position): Promise<vscode.CompletionItem[]> {
        const linePrefix = document.lineAt(position).text.substr(0, position.character)
        if (!linePrefix.endsWith('claude.')) {
            return []
        }

        const context = this.getContext(document, position)
        const prompt = `Complete the following code:\n\n${linePrefix}`
        
        const aiResponse = await this.getAIResponse(prompt, context)
        
        // Parse the AI response and create completion items
        const completionItems = this.parseCompletionItems(aiResponse)
        
        return completionItems
    }

    private getContext(document: vscode.TextDocument, position: vscode.Position): string {
        const start = new vscode.Position(Math.max(0, position.line - 10), 0)
        const range = new vscode.Range(start, position)
        const textBefore = document.getText(range)

        const fileContent = this.getFileContent(document.fileName)
        const projectStructure = this.getProjectStructure()

        return `${projectStructure}\n\nCurrent file (${document.fileName}):\n${fileContent}\n\nCurrent context:\n${textBefore}`
    }

    private parseCompletionItems(aiResponse: string): vscode.CompletionItem[] {
        // Implement parsing logic to convert AI response to CompletionItems
        // This is a placeholder implementation
        return [new vscode.CompletionItem('placeholder', vscode.CompletionItemKind.Method)]
    }
}
```

To use this feature, you'll need to register it as a completion provider in your `extension.ts`:

```typescript
import * as vscode from 'vscode'
import { CodeCompletionFeature } from './features/code-completion'
import { ApiHandler } from './api'

export function activate(context: vscode.ExtensionContext) {
    const apiHandler: ApiHandler = // ... initialize your API handler

    const codeCompletion = new CodeCompletionFeature(apiHandler, 4000)
    
    context.subscriptions.push(
        vscode.languages.registerCompletionItemProvider(
            { scheme: 'file', language: '*' },
            {
                provideCompletionItems: codeCompletion.provideCompletionItems.bind(codeCompletion)
            },
            '.' // Trigger character
        )
    )
}
```

## Creating an AI-Powered Code Reviewer

Next, let's implement an AI-powered code reviewer. Create a new file `src/features/code-review.ts`:

```typescript
import { BaseFeature } from './base-feature'
import * as vscode from 'vscode'

export class CodeReviewFeature extends BaseFeature {
    async reviewCode(document: vscode.TextDocument): Promise<vscode.Diagnostic[]> {
        const fileContent = document.getText()
        const fileName = document.fileName
        const projectStructure = this.getProjectStructure()

        const prompt = `Review the following code for potential issues, bugs, and style improvements:\n\n${fileContent}`
        const context = `File: ${fileName}\n\nProject Structure:\n${projectStructure}`

        const aiResponse = await this.getAIResponse(prompt, context)
        
        return this.parseDiagnostics(aiResponse, document)
    }

    private parseDiagnostics(aiResponse: string, document: vscode.TextDocument): vscode.Diagnostic[] {
        // Implement parsing logic to convert AI response to Diagnostics
        // This is a placeholder implementation
        const diagnostic = new vscode.Diagnostic(
            new vscode.Range(0, 0, 0, 1),
            "AI Review: Placeholder diagnostic",
            vscode.DiagnosticSeverity.Information
        )
        return [diagnostic]
    }
}
```

To use this feature, you'll need to register it as a diagnostic provider in your `extension.ts`:

```typescript
import * as vscode from 'vscode'
import { CodeReviewFeature } from './features/code-review'
import { ApiHandler } from './api'

export function activate(context: vscode.ExtensionContext) {
    const apiHandler: ApiHandler = // ... initialize your API handler

    const codeReview = new CodeReviewFeature(apiHandler, 4000)
    
    const diagnosticCollection = vscode.languages.createDiagnosticCollection('ai-code-review')
    context.subscriptions.push(diagnosticCollection)

    context.subscriptions.push(
        vscode.workspace.onDidSaveTextDocument(async (document) => {
            const diagnostics = await codeReview.reviewCode(document)
            diagnosticCollection.set(document.uri, diagnostics)
        })
    )
}
```

## Generating Unit Tests with AI Assistance

Now, let's implement AI-assisted unit test generation. Create a new file `src/features/unit-test-gen.ts`:

```typescript
import { BaseFeature } from './base-feature'
import * as vscode from 'vscode'
import * as path from 'path'

export class UnitTestGenFeature extends BaseFeature {
    async generateUnitTests(document: vscode.TextDocument): Promise<string> {
        const fileContent = document.getText()
        const fileName = document.fileName
        const projectStructure = this.getProjectStructure()

        const prompt = `Generate unit tests for the following code:\n\n${fileContent}`
        const context = `File: ${fileName}\n\nProject Structure:\n${projectStructure}`

        const aiResponse = await this.getAIResponse(prompt, context)
        
        return this.formatUnitTests(aiResponse, fileName)
    }

    private formatUnitTests(aiResponse: string, originalFileName: string): string {
        // Implement formatting logic to create a proper unit test file
        // This is a placeholder implementation
        const testFileName = this.getTestFileName(originalFileName)
        return `// ${testFileName}\n\n${aiResponse}`
    }

    private getTestFileName(originalFileName: string): string {
        const parsedPath = path.parse(originalFileName)
        return path.format({
            dir: parsedPath.dir,
            name: `${parsedPath.name}.test`,
            ext: parsedPath.ext
        })
    }
}
```

To use this feature, you can add a command to your `extension.ts`:

```typescript
import * as vscode from 'vscode'
import { UnitTestGenFeature } from './features/unit-test-gen'
import { ApiHandler } from './api'

export function activate(context: vscode.ExtensionContext) {
    const apiHandler: ApiHandler = // ... initialize your API handler

    const unitTestGen = new UnitTestGenFeature(apiHandler, 4000)
    
    context.subscriptions.push(
        vscode.commands.registerCommand('extension.generateUnitTests', async () => {
            const editor = vscode.window.activeTextEditor
            if (editor) {
                const unitTests = await unitTestGen.generateUnitTests(editor.document)
                const testFilePath = unitTestGen.getTestFileName(editor.document.fileName)
                const testFileUri = vscode.Uri.file(testFilePath)
                
                await vscode.workspace.fs.writeFile(testFileUri, Buffer.from(unitTests, 'utf8'))
                await vscode.window.showTextDocument(testFileUri)
            }
        })
    )
}
```

## Implementing Natural Language to Code Translation

Finally, let's implement natural language to code translation. Create a new file `src/features/nl-to-code.ts`:

```typescript
import { BaseFeature } from './base-feature'
import * as vscode from 'vscode'

export class NLToCodeFeature extends BaseFeature {
    async translateToCode(nlDescription: string, language: string): Promise<string> {
        const projectStructure = this.getProjectStructure()

        const prompt = `Translate the following natural language description into ${language} code:\n\n${nlDescription}`
        const context = `Project Structure:\n${projectStructure}\n\nTarget Language: ${language}`

        const aiResponse = await this.getAIResponse(prompt, context)
        
        return this.formatCodeResponse(aiResponse, language)
    }

    private formatCodeResponse(aiResponse: string, language: string): string {
        // Implement formatting logic to properly format the code
        // This is a placeholder implementation
        return `// Generated ${language} code\n\n${aiResponse}`
    }
}
```

To use this feature, you can add a command to your `extension.ts`:

```typescript
import * as vscode from 'vscode'
import { NLToCodeFeature } from './features/nl-to-code'
import { ApiHandler } from './api'

export function activate(context: vscode.ExtensionContext) {
    const apiHandler: ApiHandler = // ... initialize your API handler

    const nlToCode = new NLToCodeFeature(apiHandler, 4000)
    
    context.subscriptions.push(
        vscode.commands.registerCommand('extension.nlToCode', async () => {
            const nlDescription = await vscode.window.showInputBox({
                prompt: "Enter a natural language description of the code you want to generate"
            })
            
            const language = await vscode.window.showQuickPick(['JavaScript', 'Python', 'Java', 'C#'], {
                placeHolder: 'Select the target programming language'
            })
            
            if (nlDescription && language) {
                const generatedCode = await nlToCode.translateToCode(nlDescription, language)
                const document = await vscode.workspace.openTextDocument({
                    content: generatedCode,
                    language: language.toLowerCase()
                })
                await vscode.window.showTextDocument(document)
            }
        })
    )
}
```

## Conclusion

In this lesson, we've implemented the core features of an AI coding assistant:

1. Context-aware code completion
2. AI-powered code review
3. Unit test generation
4. Natural language to code translation

These features leverage the power of AI to enhance developer productivity within VSCode. We've designed a flexible architecture that allows for easy extension and modification of these features.

## Exercises

1. Improve the code completion feature to provide more accurate and context-aware suggestions. Consider using the project's dependencies and import statements to enhance completions.

2. Enhance the code review feature to provide more detailed feedback, including suggestions for refactoring and performance improvements.

3. Extend the unit test generation feature to support different testing frameworks (e.g., Jest for JavaScript, pytest for Python) based on the project configuration.

4. Implement a feature that allows developers to ask questions about their code and receive explanations from the AI.

5. Create a feature that suggests code optimizations based on performance metrics or best practices for the specific language or framework being used.

6. Implement a feature that generates documentation comments for functions and classes based on their implementation.

7. Extend the natural language to code translation feature to support translating code from one programming language to another.

8. Create a feature that helps developers write regex patterns by translating natural language descriptions into regular expressions. Here's a starting point:

```typescript
import { BaseFeature } from './base-feature'
import * as vscode from 'vscode'

export class RegexGeneratorFeature extends BaseFeature {
    async generateRegex(description: string): Promise<string> {
        const prompt = `Generate a regular expression that matches the following description:\n\n${description}`
        const context = "You are a regex expert. Provide a concise and accurate regular expression."

        const aiResponse = await this.getAIResponse(prompt, context)
        
        return this.extractRegex(aiResponse)
    }

    private extractRegex(aiResponse: string): string {
        // Implement logic to extract the regex pattern from the AI response
        // This is a placeholder implementation
        const regexMatch = aiResponse.match(/`(.*?)`/)
        return regexMatch ? regexMatch[1] : aiResponse
    }
}
```

9. Implement a "code explanation" feature that allows developers to select a block of code and receive a natural language explanation of what the code does:

```typescript
import { BaseFeature } from './base-feature'
import * as vscode from 'vscode'

export class CodeExplanationFeature extends BaseFeature {
    async explainCode(code: string, language: string): Promise<string> {
        const prompt = `Explain the following ${language} code in simple terms:\n\n${code}`
        const context = "You are an expert programmer. Provide a clear and concise explanation of the code."

        const aiResponse = await this.getAIResponse(prompt, context)
        
        return this.formatExplanation(aiResponse)
    }

    private formatExplanation(aiResponse: string): string {
        // Implement formatting logic for the explanation
        // This is a placeholder implementation
        return `Code Explanation:\n\n${aiResponse}`
    }
}
```

10. Develop a "code outlining" feature that generates a high-level overview of a file's structure, including classes, methods, and important logic blocks:

```typescript
import { BaseFeature } from './base-feature'
import * as vscode from 'vscode'

export class CodeOutlineFeature extends BaseFeature {
    async generateOutline(document: vscode.TextDocument): Promise<string> {
        const fileContent = document.getText()
        const fileName = document.fileName
        const language = document.languageId

        const prompt = `Generate a high-level outline of the following ${language} code, including classes, methods, and important logic blocks:\n\n${fileContent}`
        const context = `File: ${fileName}\nLanguage: ${language}\n\nYou are an expert in code structure and organization.`

        const aiResponse = await this.getAIResponse(prompt, context)
        
        return this.formatOutline(aiResponse)
    }

    private formatOutline(aiResponse: string): string {
        // Implement formatting logic for the outline
        // This is a placeholder implementation
        return `Code Outline:\n\n${aiResponse}`
    }
}
```

To integrate these new features into your extension, you'll need to add them to your `extension.ts` file:

```typescript
import * as vscode from 'vscode'
import { RegexGeneratorFeature } from './features/regex-generator'
import { CodeExplanationFeature } from './features/code-explanation'
import { CodeOutlineFeature } from './features/code-outline'
import { ApiHandler } from './api'

export function activate(context: vscode.ExtensionContext) {
    const apiHandler: ApiHandler = // ... initialize your API handler

    const regexGenerator = new RegexGeneratorFeature(apiHandler, 4000)
    const codeExplanation = new CodeExplanationFeature(apiHandler, 4000)
    const codeOutline = new CodeOutlineFeature(apiHandler, 4000)

    context.subscriptions.push(
        vscode.commands.registerCommand('extension.generateRegex', async () => {
            const description = await vscode.window.showInputBox({
                prompt: "Describe the pattern you want to match with a regex"
            })
            
            if (description) {
                const regex = await regexGenerator.generateRegex(description)
                await vscode.env.clipboard.writeText(regex)
                vscode.window.showInformationMessage(`Regex copied to clipboard: ${regex}`)
            }
        }),

        vscode.commands.registerCommand('extension.explainCode', async () => {
            const editor = vscode.window.activeTextEditor
            if (editor) {
                const selection = editor.selection
                const code = editor.document.getText(selection)
                const language = editor.document.languageId
                
                if (code) {
                    const explanation = await codeExplanation.explainCode(code, language)
                    const document = await vscode.workspace.openTextDocument({
                        content: explanation,
                        language: 'markdown'
                    })
                    await vscode.window.showTextDocument(document, { viewColumn: vscode.ViewColumn.Beside })
                }
            }
        }),

        vscode.commands.registerCommand('extension.generateCodeOutline', async () => {
            const editor = vscode.window.activeTextEditor
            if (editor) {
                const outline = await codeOutline.generateOutline(editor.document)
                const document = await vscode.workspace.openTextDocument({
                    content: outline,
                    language: 'markdown'
                })
                await vscode.window.showTextDocument(document, { viewColumn: vscode.ViewColumn.Beside })
            }
        })
    )
}
```

## Further Considerations

As you implement these advanced features, consider the following points:

1. **Performance**: AI-powered features can be computationally intensive. Implement caching mechanisms and consider using worker threads for long-running tasks to keep the UI responsive.

2. **Error Handling**: Implement robust error handling for AI API calls and parsing of AI responses. Provide meaningful feedback to users when things go wrong.

3. **User Settings**: Allow users to customize the behavior of these features through VSCode settings. For example, they might want to adjust the verbosity of code explanations or the strictness of the code review.

4. **Integration with Existing Tools**: Consider how your AI-powered features can complement existing development tools and workflows rather than replacing them entirely.

5. **Privacy and Security**: Be mindful of the data being sent to AI services. Implement measures to protect sensitive information and comply with data protection regulations.

6. **Continuous Learning**: Implement feedback mechanisms that allow users to rate the quality of AI-generated content. This data can be used to improve the AI model over time.

7. **Language and Framework Specificity**: Enhance the AI prompts with language-specific and framework-specific knowledge to provide more accurate and relevant assistance.

By implementing these advanced features and considering these points, you'll create a powerful AI coding assistant that can significantly enhance developer productivity within VSCode.