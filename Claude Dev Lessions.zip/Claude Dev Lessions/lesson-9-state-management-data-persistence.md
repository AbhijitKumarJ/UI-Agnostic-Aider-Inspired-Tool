# Lesson 9: State Management and Data Persistence in VSCode Extensions

## Introduction

In this lesson, we'll explore state management and data persistence techniques in VSCode extensions. We'll cover managing global and workspace state, implementing secure storage for sensitive data, creating robust caching mechanisms, designing a task history feature, and implementing user preferences. We'll use the Claude Dev project as a reference, examining how it implements these concepts.

## Project Structure

Let's start by looking at the relevant parts of the Claude Dev project structure:

```
claude-dev/
├── src/
│   ├── ClaudeDev.ts
│   ├── extension.ts
│   ├── providers/
│   │   └── ClaudeDevProvider.ts
│   ├── shared/
│   │   ├── api.ts
│   │   ├── ClaudeRequestResult.ts
│   │   ├── combineApiRequests.ts
│   │   ├── combineCommandSequences.ts
│   │   ├── ExtensionMessage.ts
│   │   ├── getApiMetrics.ts
│   │   └── HistoryItem.ts
│   └── utils/
│       └── export-markdown.ts
├── webview-ui/
│   └── src/
│       ├── components/
│       │   ├── ApiOptions.tsx
│       │   ├── HistoryPreview.tsx
│       │   ├── HistoryView.tsx
│       │   └── SettingsView.tsx
│       └── context/
│           └── ExtensionStateContext.tsx
├── package.json
└── tsconfig.json
```

This structure highlights the main files we'll be referencing throughout the lesson, particularly the `ClaudeDevProvider.ts` and `ExtensionStateContext.tsx` files which handle much of the state management and persistence.

## 1. Managing Global and Workspace State

VSCode provides two types of state storage for extensions: global state (persists across all workspaces) and workspace state (specific to the current workspace). Claude Dev uses both types of state storage. Let's look at how it's implemented:

```typescript
// In src/providers/ClaudeDevProvider.ts

export class ClaudeDevProvider implements vscode.WebviewViewProvider {
    // ...

    private async updateGlobalState(key: GlobalStateKey, value: any) {
        await this.context.globalState.update(key, value)
    }

    private async getGlobalState(key: GlobalStateKey) {
        return await this.context.globalState.get(key)
    }

    private async updateWorkspaceState(key: string, value: any) {
        await this.context.workspaceState.update(key, value)
    }

    private async getWorkspaceState(key: string) {
        return await this.context.workspaceState.get(key)
    }

    // ...
}
```

These methods provide a simple interface for updating and retrieving both global and workspace state. The `GlobalStateKey` type ensures that only predefined keys are used for global state:

```typescript
type GlobalStateKey =
    | "apiProvider"
    | "apiModelId"
    | "awsRegion"
    | "vertexProjectId"
    | "vertexRegion"
    | "lastShownAnnouncementId"
    | "customInstructions"
    | "alwaysAllowReadOnly"
    | "taskHistory"
    | "openAiBaseUrl"
    | "openAiModelId"
    | "ollamaModelId"
    | "ollamaBaseUrl"
    | "anthropicBaseUrl"
```

## 2. Implementing Secure Storage for Sensitive Data

For sensitive data like API keys, Claude Dev uses VSCode's secrets storage. This provides an encrypted storage for sensitive information:

```typescript
// In src/providers/ClaudeDevProvider.ts

export class ClaudeDevProvider implements vscode.WebviewViewProvider {
    // ...

    private async storeSecret(key: SecretKey, value?: string) {
        if (value) {
            await this.context.secrets.store(key, value)
        } else {
            await this.context.secrets.delete(key)
        }
    }

    private async getSecret(key: SecretKey) {
        return await this.context.secrets.get(key)
    }

    // ...
}
```

The `SecretKey` type ensures that only predefined keys are used for secrets:

```typescript
type SecretKey =
    | "apiKey"
    | "openRouterApiKey"
    | "awsAccessKey"
    | "awsSecretKey"
    | "awsSessionToken"
    | "openAiApiKey"
    | "geminiApiKey"
    | "openAiNativeApiKey"
```

## 3. Creating a Robust Caching Mechanism for API Responses

Claude Dev implements a caching mechanism for API responses to improve performance and reduce API calls. This is implemented in the `ClaudeDev` class:

```typescript
// In src/ClaudeDev.ts

export class ClaudeDev {
    // ...

    private async getSavedApiConversationHistory(): Promise<Anthropic.MessageParam[]> {
        const filePath = path.join(await this.ensureTaskDirectoryExists(), "api_conversation_history.json")
        const fileExists = await fs
            .access(filePath)
            .then(() => true)
            .catch(() => false)
        if (fileExists) {
            return JSON.parse(await fs.readFile(filePath, "utf8"))
        }
        return []
    }

    private async addToApiConversationHistory(message: Anthropic.MessageParam) {
        this.apiConversationHistory.push(message)
        await this.saveApiConversationHistory()
    }

    private async saveApiConversationHistory() {
        try {
            const filePath = path.join(await this.ensureTaskDirectoryExists(), "api_conversation_history.json")
            await fs.writeFile(filePath, JSON.stringify(this.apiConversationHistory))
        } catch (error) {
            console.error("Failed to save API conversation history:", error)
        }
    }

    // ...
}
```

This implementation saves the API conversation history to a JSON file, which can be loaded in future sessions. It also includes error handling to ensure that failures in saving don't disrupt the main functionality.

## 4. Designing a Task History Feature with Persistence

Claude Dev includes a task history feature that persists across sessions. This is implemented using the global state:

```typescript
// In src/providers/ClaudeDevProvider.ts

export class ClaudeDevProvider implements vscode.WebviewViewProvider {
    // ...

    async updateTaskHistory(item: HistoryItem): Promise<HistoryItem[]> {
        const history = ((await this.getGlobalState("taskHistory")) as HistoryItem[]) || []
        const existingItemIndex = history.findIndex((h) => h.id === item.id)
        if (existingItemIndex !== -1) {
            history[existingItemIndex] = item
        } else {
            history.push(item)
        }
        await this.updateGlobalState("taskHistory", history)
        return history
    }

    // ...
}
```

The `HistoryItem` interface defines the structure of a task history item:

```typescript
// In src/shared/HistoryItem.ts

export type HistoryItem = {
    id: string
    ts: number
    task: string
    tokensIn: number
    tokensOut: number
    cacheWrites?: number
    cacheReads?: number
    totalCost: number
}
```

## 5. Implementing User Preferences and Settings

Claude Dev allows users to set preferences and settings, which are stored in the global state. These settings are managed through the `SettingsView` component:

```typescript
// In webview-ui/src/components/SettingsView.tsx

const SettingsView = ({ onDone }: SettingsViewProps) => {
    const {
        apiConfiguration,
        version,
        customInstructions,
        setCustomInstructions,
        alwaysAllowReadOnly,
        setAlwaysAllowReadOnly,
    } = useExtensionState()

    // ...

    const handleSubmit = () => {
        const apiValidationResult = validateApiConfiguration(apiConfiguration)

        setApiErrorMessage(apiValidationResult)

        if (!apiValidationResult) {
            vscode.postMessage({ type: "apiConfiguration", apiConfiguration })
            vscode.postMessage({ type: "customInstructions", text: customInstructions })
            vscode.postMessage({ type: "alwaysAllowReadOnly", bool: alwaysAllowReadOnly })
            onDone()
        }
    }

    // ...
}
```

The settings are then persisted in the extension:

```typescript
// In src/providers/ClaudeDevProvider.ts

export class ClaudeDevProvider implements vscode.WebviewViewProvider {
    // ...

    private setWebviewMessageListener(webview: vscode.Webview) {
        webview.onDidReceiveMessage(
            async (message: WebviewMessage) => {
                switch (message.type) {
                    // ...
                    case "apiConfiguration":
                        if (message.apiConfiguration) {
                            const {
                                apiProvider,
                                apiModelId,
                                apiKey,
                                // ... other configuration properties
                            } = message.apiConfiguration
                            await this.updateGlobalState("apiProvider", apiProvider)
                            await this.updateGlobalState("apiModelId", apiModelId)
                            await this.storeSecret("apiKey", apiKey)
                            // ... update other configuration properties
                        }
                        await this.postStateToWebview()
                        break
                    case "customInstructions":
                        await this.updateGlobalState("customInstructions", message.text || undefined)
                        this.claudeDev?.updateCustomInstructions(message.text || undefined)
                        await this.postStateToWebview()
                        break
                    case "alwaysAllowReadOnly":
                        await this.updateGlobalState("alwaysAllowReadOnly", message.bool ?? undefined)
                        this.claudeDev?.updateAlwaysAllowReadOnly(message.bool ?? undefined)
                        await this.postStateToWebview()
                        break
                    // ...
                }
            },
            null,
            this.disposables
        )
    }

    // ...
}
```

## Conclusion

In this lesson, we've explored state management and data persistence techniques in VSCode extensions, using the Claude Dev project as a reference. We've covered managing global and workspace state, implementing secure storage for sensitive data, creating robust caching mechanisms, designing a task history feature, and implementing user preferences.

These techniques allow you to create extensions that can persist data across sessions, securely store sensitive information, and provide a seamless user experience. By leveraging VSCode's built-in state management and secrets storage, you can create powerful and secure extensions that enhance the development experience.

## Exercises

1. Implement a feature that allows users to export and import their settings and task history.
2. Create a system for managing and persisting multiple API configurations.
3. Implement a feature that syncs certain settings across different machines using VSCode's built-in sync capabilities.
4. Create a local database using SQLite to store and query large amounts of extension data efficiently.

By completing these exercises, you'll gain hands-on experience with state management and data persistence in VSCode extensions, and explore ways to enhance the user experience through effective data handling and storage.

