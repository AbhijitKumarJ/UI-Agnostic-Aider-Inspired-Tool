# Lesson 10: Local Knowledge Management with Vector Databases in VSCode Extensions

## Introduction

In this lesson, we'll explore how to integrate vector databases for local knowledge management in VSCode extensions. We'll cover setting up a local vector database, indexing workspace files, generating embeddings, implementing semantic search functionality, and creating a Q&A feature using the local knowledge base. While the Claude Dev project doesn't directly implement these features, we'll use its structure as a basis and propose how such functionality could be integrated.

## Project Structure

Let's start by looking at the relevant parts of the Claude Dev project structure and propose additions for vector database integration:

```
claude-dev/
├── src/
│   ├── ClaudeDev.ts
│   ├── extension.ts
│   ├── providers/
│   │   └── ClaudeDevProvider.ts
│   ├── parse-source-code/
│   │   ├── index.ts
│   │   └── languageParser.ts
│   ├── vector-db/                 (new)
│   │   ├── index.ts               (new)
│   │   ├── chromadb.ts            (new)
│   │   └── embeddingGenerator.ts  (new)
│   └── utils/
│       └── getLanguageFromPath.ts
├── webview-ui/
│   └── src/
│       └── components/
│           ├── SearchView.tsx     (new)
│           └── QAView.tsx         (new)
├── package.json
└── tsconfig.json
```

We've added a new `vector-db` directory to handle vector database operations, and two new components in the webview for search and Q&A functionality.

## 1. Setting Up a Local Vector Database

For this example, we'll use Chroma, an open-source embedding database. First, let's set up Chroma in our extension:

```typescript
// In src/vector-db/chromadb.ts

import { ChromaClient, Collection } from 'chromadb'

export class ChromaManager {
    private client: ChromaClient
    private collection: Collection | null = null

    constructor() {
        this.client = new ChromaClient()
    }

    async initializeCollection(name: string): Promise<void> {
        this.collection = await this.client.createCollection({
            name: name,
            metadata: { "hnsw:space": "cosine" }
        })
    }

    async addDocuments(documents: string[], ids: string[], metadata: object[]): Promise<void> {
        if (!this.collection) {
            throw new Error("Collection not initialized")
        }
        await this.collection.add({
            ids: ids,
            documents: documents,
            metadatas: metadata
        })
    }

    async query(queryText: string, nResults: number = 5): Promise<any> {
        if (!this.collection) {
            throw new Error("Collection not initialized")
        }
        return await this.collection.query({
            queryTexts: [queryText],
            nResults: nResults
        })
    }
}
```

This `ChromaManager` class provides methods to initialize a collection, add documents, and perform queries.

## 2. Indexing Workspace Files and Generating Embeddings

Next, let's create a system to index workspace files and generate embeddings:

```typescript
// In src/vector-db/embeddingGenerator.ts

import * as vscode from 'vscode'
import * as path from 'path'
import { encode } from '@dqbd/tiktoken'
import { ChromaManager } from './chromadb'
import { parseSourceCodeForDefinitionsTopLevel } from '../parse-source-code'

export class EmbeddingGenerator {
    private chromaManager: ChromaManager

    constructor(chromaManager: ChromaManager) {
        this.chromaManager = chromaManager
    }

    async indexWorkspace(): Promise<void> {
        const workspaceFolders = vscode.workspace.workspaceFolders
        if (!workspaceFolders) {
            return
        }

        await this.chromaManager.initializeCollection('workspace_index')

        for (const folder of workspaceFolders) {
            const files = await vscode.workspace.findFiles(
                new vscode.RelativePattern(folder, '**/*.{js,ts,py,java,c,cpp,go,rb}')
            )

            for (const file of files) {
                const content = await vscode.workspace.openTextDocument(file).then(doc => doc.getText())
                const definitions = await parseSourceCodeForDefinitionsTopLevel(file.fsPath)
                const embedding = this.generateEmbedding(content)
                
                await this.chromaManager.addDocuments(
                    [content],
                    [file.fsPath],
                    [{
                        path: file.fsPath,
                        language: path.extname(file.fsPath).slice(1),
                        definitions: definitions
                    }]
                )
            }
        }
    }

    private generateEmbedding(text: string): number[] {
        // For simplicity, we're using a basic tokenization method.
        // In a real-world scenario, you'd use a more sophisticated embedding model.
        const tokens = encode(text)
        return Array.from(tokens).map(token => token / tokens.length)
    }
}
```

This `EmbeddingGenerator` class indexes workspace files, generates embeddings, and stores them in the Chroma database. It uses the existing `parseSourceCodeForDefinitionsTopLevel` function from Claude Dev to extract code definitions.

## 3. Implementing Semantic Search Functionality

Now, let's implement a semantic search feature:

```typescript
// In src/vector-db/index.ts

import { ChromaManager } from './chromadb'
import { EmbeddingGenerator } from './embeddingGenerator'

export class VectorDBManager {
    private chromaManager: ChromaManager
    private embeddingGenerator: EmbeddingGenerator

    constructor() {
        this.chromaManager = new ChromaManager()
        this.embeddingGenerator = new EmbeddingGenerator(this.chromaManager)
    }

    async initializeWorkspaceIndex(): Promise<void> {
        await this.embeddingGenerator.indexWorkspace()
    }

    async semanticSearch(query: string, nResults: number = 5): Promise<any> {
        return await this.chromaManager.query(query, nResults)
    }
}

// In src/extension.ts

import { VectorDBManager } from './vector-db'

export function activate(context: vscode.ExtensionContext) {
    // ... other activation code ...

    const vectorDBManager = new VectorDBManager()
    context.subscriptions.push(
        vscode.commands.registerCommand('extension.initializeWorkspaceIndex', () => {
            vectorDBManager.initializeWorkspaceIndex()
        }),
        vscode.commands.registerCommand('extension.semanticSearch', async () => {
            const query = await vscode.window.showInputBox({ prompt: 'Enter your search query' })
            if (query) {
                const results = await vectorDBManager.semanticSearch(query)
                // Display results in a new editor
                const resultDocument = await vscode.workspace.openTextDocument({
                    content: JSON.stringify(results, null, 2),
                    language: 'json'
                })
                await vscode.window.showTextDocument(resultDocument)
            }
        })
    )
}
```

This implementation adds two new commands: one to initialize the workspace index, and another to perform semantic searches.

## 4. Creating a Q&A Feature Using the Local Knowledge Base

Finally, let's create a Q&A feature that uses the local knowledge base:

```typescript
// In src/vector-db/index.ts

import { VectorDBManager } from './vector-db'
import { ClaudeDev } from './ClaudeDev'

export class QASystem {
    private vectorDBManager: VectorDBManager
    private claudeDev: ClaudeDev

    constructor(vectorDBManager: VectorDBManager, claudeDev: ClaudeDev) {
        this.vectorDBManager = vectorDBManager
        this.claudeDev = claudeDev
    }

    async answerQuestion(question: string): Promise<string> {
        const searchResults = await this.vectorDBManager.semanticSearch(question, 3)
        const context = searchResults.documents.join('\n\n')
        
        const prompt = `
Based on the following context from the codebase, please answer the question: "${question}"

Context:
${context}

Answer:
`
        const answer = await this.claudeDev.getAIResponse(prompt)
        return answer
    }
}

// In src/extension.ts

import { QASystem } from './vector-db'

export function activate(context: vscode.ExtensionContext) {
    // ... other activation code ...

    const qaSystem = new QASystem(vectorDBManager, claudeDev)
    context.subscriptions.push(
        vscode.commands.registerCommand('extension.askQuestion', async () => {
            const question = await vscode.window.showInputBox({ prompt: 'Ask a question about your codebase' })
            if (question) {
                const answer = await qaSystem.answerQuestion(question)
                // Display answer in a new editor
                const answerDocument = await vscode.workspace.openTextDocument({
                    content: answer,
                    language: 'markdown'
                })
                await vscode.window.showTextDocument(answerDocument)
            }
        })
    )
}
```

This implementation adds a new command to ask questions about the codebase. It uses the semantic search functionality to find relevant context, then uses the AI (via `ClaudeDev`) to generate an answer based on that context.

## 5. Integrating with the UI

To make these features accessible to users, we can add new components to the webview:

```typescript
// In webview-ui/src/components/SearchView.tsx

import React, { useState } from 'react'
import { VSCodeTextField, VSCodeButton } from '@vscode/webview-ui-toolkit/react'
import { vscode } from '../utils/vscode'

export const SearchView: React.FC = () => {
    const [query, setQuery] = useState('')

    const handleSearch = () => {
        vscode.postMessage({ type: 'semanticSearch', query })
    }

    return (
        <div>
            <VSCodeTextField value={query} onChange={(e: any) => setQuery(e.target.value)} />
            <VSCodeButton onClick={handleSearch}>Search</VSCodeButton>
        </div>
    )
}

// In webview-ui/src/components/QAView.tsx

import React, { useState } from 'react'
import { VSCodeTextField, VSCodeButton } from '@vscode/webview-ui-toolkit/react'
import { vscode } from '../utils/vscode'

export const QAView: React.FC = () => {
    const [question, setQuestion] = useState('')

    const handleAsk = () => {
        vscode.postMessage({ type: 'askQuestion', question })
    }

    return (
        <div>
            <VSCodeTextField value={question} onChange={(e: any) => setQuestion(e.target.value)} />
            <VSCodeButton onClick={handleAsk}>Ask</VSCodeButton>
        </div>
    )
}
```

These components can be integrated into the main webview, allowing users to perform semantic searches and ask questions about their codebase.

## Conclusion

In this lesson, we've explored how to integrate vector databases for local knowledge management in VSCode extensions. We've covered setting up a local vector database using Chroma, indexing workspace files, generating embeddings, implementing semantic search functionality, and creating a Q&A feature using the local knowledge base.

While the Claude Dev project doesn't directly implement these features, we've shown how they could be integrated into a similar project structure. These techniques allow you to create powerful extensions that can understand and provide insights about the user's codebase, enhancing the development experience in VSCode.

## Exercises

1. Implement a more sophisticated embedding model, such as one based on transformers, to improve the quality of semantic search results.
2. Create a system for incrementally updating the vector database as files in the workspace change.
3. Implement a feature that suggests related code snippets based on the currently open file.
4. Create a visualization of the codebase based on the semantic relationships between files.

By completing these exercises, you'll gain hands-on experience with vector databases and semantic search in the context of VSCode extensions, and explore ways to provide valuable insights to developers about their codebase.

