# Lesson 18: Claude Dev UI Implementation

## Introduction

In this lesson, we'll focus on implementing the user interface for Claude Dev, our AI-powered VSCode extension. We'll create a responsive and intuitive chat interface, design a settings panel for API configuration, implement a task history view, and create a file diff view for AI-suggested changes. We'll also implement a progress and status indicator system to keep users informed about ongoing processes.

## Project Structure

Before we dive into the implementation, let's review the updated project structure for our Claude Dev extension:

```
claude-dev/
│
├── src/
│   ├── extension.ts
│   ├── ClaudeDev.ts
│   ├── api/
│   │   ├── index.ts
│   │   ├── anthropic.ts
│   │   ├── openai.ts
│   │   └── openrouter.ts
│   ├── utils/
│   │   ├── context-management.ts
│   │   ├── prompt-engineering.ts
│   │   └── tool-execution.ts
│   └── providers/
│       └── ClaudeDevProvider.ts
│
├── webview-ui/
│   ├── src/
│   │   ├── components/
│   │   │   ├── ChatView.tsx
│   │   │   ├── SettingsPanel.tsx
│   │   │   ├── TaskHistory.tsx
│   │   │   ├── FileDiffView.tsx
│   │   │   ├── ProgressIndicator.tsx
│   │   │   └── StatusBar.tsx
│   │   ├── contexts/
│   │   │   └── ClaudeDevContext.tsx
│   │   ├── styles/
│   │   │   └── index.css
│   │   └── App.tsx
│   ├── public/
│   │   └── index.html
│   └── package.json
│
├── package.json
└── tsconfig.json
```

This structure separates our extension's backend logic (`src/`) from the frontend UI (`webview-ui/`), allowing for a clean separation of concerns.

## 1. Designing and Implementing the Main Chat Interface

The main chat interface is the primary point of interaction for users. We'll use React to create a responsive and interactive chat view.

First, let's create a context to manage the global state of our UI:

```typescript
// webview-ui/src/contexts/ClaudeDevContext.tsx

import React, { createContext, useContext, useState } from 'react';

interface ClaudeDevContextType {
  messages: Message[];
  addMessage: (message: Message) => void;
  // Add other state and functions as needed
}

const ClaudeDevContext = createContext<ClaudeDevContextType | undefined>(undefined);

export const ClaudeDevProvider: React.FC = ({ children }) => {
  const [messages, setMessages] = useState<Message[]>([]);

  const addMessage = (message: Message) => {
    setMessages((prevMessages) => [...prevMessages, message]);
  };

  return (
    <ClaudeDevContext.Provider value={{ messages, addMessage }}>
      {children}
    </ClaudeDevContext.Provider>
  );
};

export const useClaudeDev = () => {
  const context = useContext(ClaudeDevContext);
  if (context === undefined) {
    throw new Error('useClaudeDev must be used within a ClaudeDevProvider');
  }
  return context;
};
```

Now, let's implement the main ChatView component:

```typescript
// webview-ui/src/components/ChatView.tsx

import React, { useState } from 'react';
import { useClaudeDev } from '../contexts/ClaudeDevContext';
import { VSCodeButton, VSCodeTextArea } from '@vscode/webview-ui-toolkit/react';

export const ChatView: React.FC = () => {
  const { messages, addMessage } = useClaudeDev();
  const [input, setInput] = useState('');

  const handleSend = () => {
    if (input.trim()) {
      addMessage({ role: 'user', content: input });
      setInput('');
      // Here you would typically call a function to send the message to the extension
      // and handle the response
    }
  };

  return (
    <div className="chat-view">
      <div className="message-list">
        {messages.map((message, index) => (
          <div key={index} className={`message ${message.role}`}>
            {message.content}
          </div>
        ))}
      </div>
      <div className="input-area">
        <VSCodeTextArea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Type your message..."
        />
        <VSCodeButton onClick={handleSend}>Send</VSCodeButton>
      </div>
    </div>
  );
};
```

Add some basic styling:

```css
/* webview-ui/src/styles/index.css */

.chat-view {
  display: flex;
  flex-direction: column;
  height: 100vh;
}

.message-list {
  flex: 1;
  overflow-y: auto;
  padding: 1rem;
}

.message {
  margin-bottom: 1rem;
  padding: 0.5rem;
  border-radius: 4px;
}

.message.user {
  background-color: var(--vscode-editor-background);
  color: var(--vscode-editor-foreground);
}

.message.assistant {
  background-color: var(--vscode-editorWidget-background);
  color: var(--vscode-editorWidget-foreground);
}

.input-area {
  display: flex;
  padding: 1rem;
  background-color: var(--vscode-editor-background);
}

.input-area vscode-text-area {
  flex: 1;
  margin-right: 0.5rem;
}
```

## 2. Creating the Settings Panel for API Configuration

The settings panel allows users to configure their API settings. Let's create a component for this:

```typescript
// webview-ui/src/components/SettingsPanel.tsx

import React, { useState } from 'react';
import { VSCodeTextField, VSCodeDropdown, VSCodeOption, VSCodeButton } from '@vscode/webview-ui-toolkit/react';

export const SettingsPanel: React.FC = () => {
  const [apiKey, setApiKey] = useState('');
  const [provider, setProvider] = useState('anthropic');

  const handleSave = () => {
    // Here you would typically call a function to save the settings to the extension
    console.log('Saving settings:', { apiKey, provider });
  };

  return (
    <div className="settings-panel">
      <h2>API Settings</h2>
      <VSCodeTextField
        value={apiKey}
        onChange={(e) => setApiKey(e.target.value)}
        placeholder="Enter your API key"
      />
      <VSCodeDropdown value={provider} onChange={(e) => setProvider(e.target.value)}>
        <VSCodeOption value="anthropic">Anthropic</VSCodeOption>
        <VSCodeOption value="openai">OpenAI</VSCodeOption>
        <VSCodeOption value="openrouter">OpenRouter</VSCodeOption>
      </VSCodeDropdown>
      <VSCodeButton onClick={handleSave}>Save Settings</VSCodeButton>
    </div>
  );
};
```

## 3. Implementing the Task History View

The task history view allows users to review past interactions. Let's create a component for this:

```typescript
// webview-ui/src/components/TaskHistory.tsx

import React from 'react';
import { useClaudeDev } from '../contexts/ClaudeDevContext';
import { VSCodeList, VSCodeListItem } from '@vscode/webview-ui-toolkit/react';

export const TaskHistory: React.FC = () => {
  const { messages } = useClaudeDev();

  // Group messages into tasks
  const tasks = messages.reduce((acc, message) => {
    if (message.role === 'user') {
      acc.push([message]);
    } else if (acc.length > 0) {
      acc[acc.length - 1].push(message);
    }
    return acc;
  }, [] as Message[][]);

  return (
    <div className="task-history">
      <h2>Task History</h2>
      <VSCodeList>
        {tasks.map((task, index) => (
          <VSCodeListItem key={index}>
            <strong>{task[0].content}</strong>
            <span>{task.length - 1} responses</span>
          </VSCodeListItem>
        ))}
      </VSCodeList>
    </div>
  );
};
```

## 4. Creating a File Diff View for AI-Suggested Changes

When Claude Dev suggests changes to a file, we need a way to display these changes to the user. Let's create a component for this:

```typescript
// webview-ui/src/components/FileDiffView.tsx

import React from 'react';
import { VSCodeButton } from '@vscode/webview-ui-toolkit/react';

interface FileDiffViewProps {
  originalContent: string;
  modifiedContent: string;
  filePath: string;
}

export const FileDiffView: React.FC<FileDiffViewProps> = ({
  originalContent,
  modifiedContent,
  filePath,
}) => {
  const handleApplyChanges = () => {
    // Here you would typically call a function to apply the changes in the extension
    console.log('Applying changes to:', filePath);
  };

  return (
    <div className="file-diff-view">
      <h2>Suggested Changes for {filePath}</h2>
      <div className="diff-container">
        <div className="original">
          <h3>Original</h3>
          <pre>{originalContent}</pre>
        </div>
        <div className="modified">
          <h3>Modified</h3>
          <pre>{modifiedContent}</pre>
        </div>
      </div>
      <VSCodeButton onClick={handleApplyChanges}>Apply Changes</VSCodeButton>
    </div>
  );
};
```

## 5. Implementing a Progress and Status Indicator System

To keep users informed about ongoing processes, let's create a progress indicator and a status bar:

```typescript
// webview-ui/src/components/ProgressIndicator.tsx

import React from 'react';
import { VSCodeProgressRing } from '@vscode/webview-ui-toolkit/react';

interface ProgressIndicatorProps {
  isVisible: boolean;
}

export const ProgressIndicator: React.FC<ProgressIndicatorProps> = ({ isVisible }) => {
  if (!isVisible) return null;

  return (
    <div className="progress-indicator">
      <VSCodeProgressRing />
      <span>Processing...</span>
    </div>
  );
};

// webview-ui/src/components/StatusBar.tsx

import React from 'react';

interface StatusBarProps {
  status: string;
}

export const StatusBar: React.FC<StatusBarProps> = ({ status }) => {
  return (
    <div className="status-bar">
      <span>{status}</span>
    </div>
  );
};
```

Now, let's update our App component to include all these new components:

```typescript
// webview-ui/src/App.tsx

import React, { useState } from 'react';
import { ClaudeDevProvider } from './contexts/ClaudeDevContext';
import { ChatView } from './components/ChatView';
import { SettingsPanel } from './components/SettingsPanel';
import { TaskHistory } from './components/TaskHistory';
import { FileDiffView } from './components/FileDiffView';
import { ProgressIndicator } from './components/ProgressIndicator';
import { StatusBar } from './components/StatusBar';
import { VSCodeDivider } from '@vscode/webview-ui-toolkit/react';

const App: React.FC = () => {
  const [isProcessing, setIsProcessing] = useState(false);
  const [status, setStatus] = useState('Ready');

  return (
    <ClaudeDevProvider>
      <div className="app-container">
        <ChatView />
        <VSCodeDivider />
        <SettingsPanel />
        <VSCodeDivider />
        <TaskHistory />
        <VSCodeDivider />
        <FileDiffView
          originalContent="Original content here"
          modifiedContent="Modified content here"
          filePath="/path/to/file.js"
        />
        <ProgressIndicator isVisible={isProcessing} />
        <StatusBar status={status} />
      </div>
    </ClaudeDevProvider>
  );
};

export default App;
```

Finally, let's add some additional styling to tie everything together:

```css
/* webview-ui/src/styles/index.css */

/* ... previous styles ... */

.app-container {
  display: flex;
  flex-direction: column;
  height: 100vh;
}

.settings-panel,
.task-history,
.file-diff-view {
  padding: 1rem;
}

.file-diff-view .diff-container {
  display: flex;
  margin-bottom: 1rem;
}

.file-diff-view .original,
.file-diff-view .modified {
  flex: 1;
  padding: 0.5rem;
  border: 1px solid var(--vscode-panel-border);
}

.progress-indicator {
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  display: flex;
  flex-direction: column;
  align-items: center;
  background-color: var(--vscode-editor-background);
  padding: 1rem;
  border-radius: 4px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
}

.status-bar {
  background-color: var(--vscode-statusBar-background);
  color: var(--vscode-statusBar-foreground);
  padding: 0.25rem 0.5rem;
}
```

## Conclusion

In this lesson, we've implemented the core UI components for Claude Dev:

1. A main chat interface for interacting with the AI
2. A settings panel for configuring API settings
3. A task history view for reviewing past interactions
4. A file diff view for displaying AI-suggested changes
5. A progress indicator and status bar for keeping users informed

These components work together to create an intuitive and responsive user interface for our AI-powered coding assistant. The use of the VSCode Webview UI Toolkit ensures that our UI is consistent with the VSCode theme and provides a native-like experience.

## Exercise

To practice what you've learned, try implementing the following enhancements:

1. Add a "Clear Chat" button to the ChatView component that clears the message history.
2. Implement a "Dark Mode" toggle in the SettingsPanel component that changes the color scheme of the UI.
3. Create a new component called "CodeSnippet" that displays syntax-highlighted code snippets in the chat messages.
4. Enhance the TaskHistory component to allow users to click on a task and load it into the ChatView.

Remember, the key to building effective UI for AI-powered tools is to create an intuitive, responsive, and informative interface that allows users to interact with the AI assistant efficiently. Happy coding!
