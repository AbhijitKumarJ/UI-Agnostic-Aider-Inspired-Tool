# Lesson 15: Natural Language Understanding and Generation Techniques

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Improving Prompt Engineering](#improving-prompt-engineering)
4. [Implementing Context-Aware Responses](#implementing-context-aware-responses)
5. [Techniques for Maintaining Conversation Coherence](#techniques-for-maintaining-conversation-coherence)
6. [Hands-on: Enhancing the Agent's Language Capabilities](#hands-on-enhancing-the-agents-language-capabilities)
7. [Conclusion](#conclusion)

## Introduction

In this lesson, we'll dive deep into advanced natural language processing (NLP) techniques to enhance Agent Zero's language capabilities. We'll focus on improving prompt engineering, implementing context-aware responses, and maintaining conversation coherence. By the end of this lesson, you'll have the skills to significantly upgrade your AI agent's language understanding and generation abilities.

## Project Structure

Before we begin, let's review the project structure, highlighting the files we'll be working with in this lesson:

```
agent-zero/
│
├── agent.py
├── initialize.py
├── models.py
├── prompts/
│   └── default/
│       ├── agent.system.md
│       ├── agent.memory.md
│       └── fw.msg_cleanup.md
│
├── python/
│   ├── helpers/
│   │   ├── messages.py
│   │   └── vector_db.py
│   │
│   └── tools/
│       ├── knowledge_tool.py
│       └── memory_tool.py
│
└── tests/
    └── test_language_capabilities.py
```

We'll be focusing on modifying and enhancing the following files:
- `prompts/default/agent.system.md`
- `prompts/default/agent.memory.md`
- `python/helpers/messages.py`
- `python/tools/knowledge_tool.py`
- `python/tools/memory_tool.py`

## Improving Prompt Engineering

Prompt engineering is crucial for getting the best results from language models. Let's explore some techniques to improve our prompts.

### 1. Be Specific and Provide Context

Always provide clear instructions and relevant context in your prompts. This helps the model understand the task better.

Example: Let's update the `agent.system.md` file:

```markdown
# Your role
- Your name is {{agent_name}}
- You are an AI assistant specialized in {{specific_domain}}
- Your primary goal is to {{primary_goal}}

# Task Context
- The user is working on {{current_project}}
- They have previously asked about {{recent_topics}}

# Communication Guidelines
- Always respond in a {{tone}} tone
- Use {{language}} terminology when discussing technical topics
- If unsure, ask clarifying questions before providing an answer

# Problem-Solving Approach
1. Understand the user's query thoroughly
2. Break down complex problems into smaller, manageable steps
3. Provide explanations for your reasoning
4. Offer multiple solutions when applicable
```

This structured prompt provides the agent with specific information about its role, the context of the conversation, and guidelines for communication.

### 2. Use Few-Shot Learning

Provide examples of desired inputs and outputs to guide the model's responses.

Example: Add this to `agent.system.md`:

```markdown
# Example Interactions
User: How do I optimize a Python function?
Assistant: To optimize a Python function, we can follow these steps:
1. Profile the function to identify bottlenecks
2. Use appropriate data structures (e.g., sets for lookups)
3. Employ caching techniques like memoization
4. Consider using built-in functions and libraries
5. Parallelize operations when possible

Can you tell me more about the specific function you want to optimize?

User: What's the capital of France?
Assistant: The capital of France is Paris. 

Is there any specific aspect of Paris or French geography you'd like to know more about?
```

### 3. Implement Dynamic Prompts

Create a system for dynamically generating prompts based on the current conversation context. Update `initialize.py` to include a `generate_dynamic_prompt` function:

```python
def generate_dynamic_prompt(agent_config, conversation_history):
    recent_topics = extract_recent_topics(conversation_history)
    user_preferences = analyze_user_preferences(conversation_history)
    
    prompt_template = agent_config.read_prompt("agent.system.md")
    
    filled_prompt = prompt_template.format(
        specific_domain=agent_config.domain,
        primary_goal=agent_config.goal,
        current_project=agent_config.project,
        recent_topics=", ".join(recent_topics),
        tone=user_preferences.get("tone", "professional"),
        language=user_preferences.get("language", "standard")
    )
    
    return filled_prompt

def extract_recent_topics(conversation_history):
    # Implement logic to extract recent topics from conversation history
    pass

def analyze_user_preferences(conversation_history):
    # Implement logic to analyze user preferences based on conversation history
    pass
```

## Implementing Context-Aware Responses

To make our agent's responses more relevant and personalized, we need to implement context-aware mechanisms.

### 1. Enhance the Memory System

Update `python/tools/memory_tool.py` to include more sophisticated memory retrieval:

```python
class Memory(Tool):
    async def execute(self, **kwargs):
        if "query" in kwargs:
            return self.context_aware_search(kwargs["query"])
        # ... (other existing code)

    def context_aware_search(self, query):
        recent_messages = self.agent.get_recent_messages(5)
        expanded_query = self.expand_query_with_context(query, recent_messages)
        
        db = get_db(self.agent)
        results = db.search_similarity_threshold(expanded_query, count=5, threshold=0.1)
        
        return self.format_memory_results(results, query)

    def expand_query_with_context(self, query, recent_messages):
        context = " ".join([msg.content for msg in recent_messages])
        return f"{query} Context: {context}"

    def format_memory_results(self, results, original_query):
        formatted_results = []
        for result in results:
            relevance = self.calculate_relevance(result, original_query)
            formatted_results.append({
                "content": result.page_content,
                "relevance": relevance,
                "source": result.metadata.get("source", "Unknown")
            })
        return sorted(formatted_results, key=lambda x: x["relevance"], reverse=True)

    def calculate_relevance(self, result, query):
        # Implement a relevance scoring mechanism
        pass
```

### 2. Implement a Conversation State Tracker

Create a new file `python/helpers/conversation_state.py`:

```python
class ConversationState:
    def __init__(self):
        self.topic = None
        self.user_intent = None
        self.emotion = None
        self.open_questions = []

    def update(self, message):
        self.topic = self.extract_topic(message)
        self.user_intent = self.identify_intent(message)
        self.emotion = self.analyze_emotion(message)
        self.update_open_questions(message)

    def extract_topic(self, message):
        # Implement topic extraction logic
        pass

    def identify_intent(self, message):
        # Implement intent identification logic
        pass

    def analyze_emotion(self, message):
        # Implement emotion analysis logic
        pass

    def update_open_questions(self, message):
        # Track open questions in the conversation
        pass
```

Update `agent.py` to use the ConversationState:

```python
from python.helpers.conversation_state import ConversationState

class Agent:
    def __init__(self, number: int, config: AgentConfig, context: AgentContext | None = None):
        # ... (existing initialization code)
        self.conversation_state = ConversationState()

    async def message_loop(self, msg: str):
        self.conversation_state.update(msg)
        # ... (rest of the message_loop implementation)
```

## Techniques for Maintaining Conversation Coherence

To ensure our agent maintains coherent conversations, we'll implement several techniques.

### 1. Use Conversation History in Prompts

Update `prompts/default/agent.memory.md` to include recent conversation history:

```markdown
# Memories
- Following are your memories on the current topic

{{memories}}

# Recent Conversation
{{recent_conversation}}

Remember to maintain coherence with the recent conversation while using the provided memories.
```

### 2. Implement Coreference Resolution

Create a new file `python/helpers/coreference_resolution.py`:

```python
import spacy

nlp = spacy.load("en_core_web_sm")

def resolve_coreferences(text):
    doc = nlp(text)
    resolved_text = text

    for cluster in doc._.coref_clusters:
        for mention in cluster.mentions:
            if mention != cluster.main:
                resolved_text = resolved_text.replace(str(mention), str(cluster.main))

    return resolved_text

class CoreferenceResolver:
    def __init__(self):
        self.conversation_history = []

    def add_message(self, message):
        self.conversation_history.append(message)
        if len(self.conversation_history) > 5:
            self.conversation_history.pop(0)

    def resolve(self, message):
        context = " ".join(self.conversation_history)
        full_text = f"{context} {message}"
        resolved_text = resolve_coreferences(full_text)
        return resolved_text.split(context)[-1].strip()
```

Update `agent.py` to use the CoreferenceResolver:

```python
from python.helpers.coreference_resolution import CoreferenceResolver

class Agent:
    def __init__(self, number: int, config: AgentConfig, context: AgentContext | None = None):
        # ... (existing initialization code)
        self.coreference_resolver = CoreferenceResolver()

    async def message_loop(self, msg: str):
        resolved_msg = self.coreference_resolver.resolve(msg)
        self.coreference_resolver.add_message(msg)
        # Use resolved_msg in further processing
        # ... (rest of the message_loop implementation)
```

### 3. Implement Topic Segmentation

Create a new file `python/helpers/topic_segmentation.py`:

```python
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import KMeans

class TopicSegmenter:
    def __init__(self, num_topics=3):
        self.vectorizer = TfidfVectorizer()
        self.kmeans = KMeans(n_clusters=num_topics)

    def segment_conversation(self, messages):
        vectors = self.vectorizer.fit_transform(messages)
        clusters = self.kmeans.fit_predict(vectors)

        segmented_conversation = []
        current_topic = clusters[0]
        current_segment = []

        for message, topic in zip(messages, clusters):
            if topic != current_topic:
                segmented_conversation.append((current_topic, current_segment))
                current_topic = topic
                current_segment = []
            current_segment.append(message)

        segmented_conversation.append((current_topic, current_segment))
        return segmented_conversation
```

Update `agent.py` to use the TopicSegmenter:

```python
from python.helpers.topic_segmentation import TopicSegmenter

class Agent:
    def __init__(self, number: int, config: AgentConfig, context: AgentContext | None = None):
        # ... (existing initialization code)
        self.topic_segmenter = TopicSegmenter()

    async def message_loop(self, msg: str):
        # ... (existing code)
        segmented_conversation = self.topic_segmenter.segment_conversation(self.conversation_history)
        current_topic = segmented_conversation[-1][0]
        # Use current_topic to inform response generation
        # ... (rest of the message_loop implementation)
```

## Hands-on: Enhancing the Agent's Language Capabilities

Now, let's put all these concepts together to enhance our agent's language capabilities.

1. Update `initialize.py` to include our new language processing components:

```python
from python.helpers.conversation_state import ConversationState
from python.helpers.coreference_resolution import CoreferenceResolver
from python.helpers.topic_segmentation import TopicSegmenter

def initialize():
    # ... (existing initialization code)
    
    config = AgentConfig(
        # ... (existing config parameters)
        conversation_state=ConversationState(),
        coreference_resolver=CoreferenceResolver(),
        topic_segmenter=TopicSegmenter(),
    )
    
    return config
```

2. Modify `agent.py` to use these enhanced capabilities:

```python
class Agent:
    async def message_loop(self, msg: str):
        # Resolve coreferences
        resolved_msg = self.config.coreference_resolver.resolve(msg)
        self.config.coreference_resolver.add_message(msg)
        
        # Update conversation state
        self.config.conversation_state.update(resolved_msg)
        
        # Generate dynamic prompt
        dynamic_prompt = generate_dynamic_prompt(self.config, self.history)
        
        # Segment conversation and get current topic
        segmented_conversation = self.config.topic_segmenter.segment_conversation(self.history)
        current_topic = segmented_conversation[-1][0]
        
        # Prepare context for the language model
        context = {
            "resolved_message": resolved_msg,
            "conversation_state": self.config.conversation_state,
            "current_topic": current_topic,
            "dynamic_prompt": dynamic_prompt,
        }
        
        # Generate response using the enhanced context
        response = await self.generate_response(context)
        
        # ... (rest of the message_loop implementation)

    async def generate_response(self, context):
        # Implement response generation using the provided context
        pass
```

3. Create a test file `tests/test_language_capabilities.py` to verify our enhancements:

```python
import unittest
from agent import Agent
from initialize import initialize

class TestLanguageCapabilities(unittest.TestCase):
    def setUp(self):
        config = initialize()
        self.agent = Agent(0, config)

    def test_coreference_resolution(self):
        messages = [
            "John went to the store.",
            "He bought some apples.",
            "They were very fresh."
        ]
        for msg in messages:
            resolved = self.agent.config.coreference_resolver.resolve(msg)
        self.assertEqual(resolved, "The apples were very fresh.")

    def test_topic_segmentation(self):
        messages = [
            "Let's talk about Python programming.",
            "Python is a versatile language.",
            "Now, switching gears to machine learning.",
            "Machine learning is a subset of AI.",
            "Back to Python, it's great for data science."
        ]
        segmented = self.agent.config.topic_segmenter.segment_conversation(messages)
        self.assertEqual(len(segmented), 3)  # Should identify 3 topic segments

    def test_conversation_state(self):
        message = "I'm feeling frustrated with this bug in my code."
        self.agent.config.conversation_state.update(message)
        self.assertEqual(self.agent.config.conversation_state.emotion, "frustrated")
        self.assertIn("bug", self.agent.config.conversation_state.topic)

    def test_dynamic_prompt_generation(self):
        self.agent.history = [
            "User: Tell me about Python.",
            "Agent: Python is a high-level programming language...",
            "User: How can I use it for data analysis?"
        ]
        dynamic_prompt = generate_dynamic_prompt(self.agent.config, self.agent.history)
        self.assertIn("data analysis", dynamic_prompt)
        self.assertIn("Python", dynamic_prompt)

    def test_end_to_end_response(self):
        user_message = "Can you explain how to use pandas for data analysis? I tried using it yesterday but got confused."
        response = self.agent.message_loop(user_message)
        
        # Check if the response addresses the user's question about pandas
        self.assertIn("pandas", response)
        self.assertIn("data analysis", response)
        
        # Check if the response acknowledges the user's previous experience
        self.assertIn("yesterday", response)
        self.assertIn("confused", response)

if __name__ == '__main__':
    unittest.main()
```

These tests will help ensure that our enhanced language capabilities are working as expected.

## Implementing Advanced Response Generation

Now that we have improved our agent's understanding of context and coherence, let's enhance its response generation capabilities.

1. Create a new file `python/helpers/response_generator.py`:

```python
import random
from typing import List, Dict

class ResponseGenerator:
    def __init__(self, agent_config):
        self.config = agent_config
        self.templates = self.load_response_templates()

    def load_response_templates(self) -> Dict[str, List[str]]:
        # Load response templates from a file or database
        # This is a simplified example
        return {
            "greeting": [
                "Hello! How can I assist you today?",
                "Greetings! What can I help you with?",
                "Hi there! What's on your mind?"
            ],
            "clarification": [
                "I'm not sure I understand. Could you please clarify?",
                "Can you provide more details about that?",
                "I'd like to help, but I need a bit more information. Can you elaborate?"
            ],
            "confirmation": [
                "I see. Let me make sure I understand correctly. You're saying that...",
                "Just to confirm, you mean...",
                "If I'm following correctly, you're asking about..."
            ],
            # Add more categories as needed
        }

    def generate_response(self, context: Dict) -> str:
        intent = context['conversation_state'].user_intent
        emotion = context['conversation_state'].emotion
        topic = context['current_topic']

        response_parts = []

        # Address emotion if detected
        if emotion:
            response_parts.append(self.generate_emotional_response(emotion))

        # Generate main response based on intent and topic
        main_response = self.generate_main_response(intent, topic, context)
        response_parts.append(main_response)

        # Add follow-up question or suggestion
        response_parts.append(self.generate_follow_up(context))

        return " ".join(response_parts)

    def generate_emotional_response(self, emotion: str) -> str:
        emotion_responses = {
            "frustrated": "I understand this might be frustrating.",
            "confused": "It's okay to feel confused. Let's work through this together.",
            "excited": "It's great to see you're excited about this!",
            # Add more emotions and responses
        }
        return emotion_responses.get(emotion, "")

    def generate_main_response(self, intent: str, topic: str, context: Dict) -> str:
        # This is where you'd implement the core logic for generating a response
        # based on the user's intent, the current topic, and other context
        # For simplicity, we'll use a template-based approach here
        template = random.choice(self.templates.get(intent, self.templates['clarification']))
        return template.format(topic=topic)

    def generate_follow_up(self, context: Dict) -> str:
        follow_ups = [
            "Is there anything else you'd like to know about this?",
            "Do you have any other questions on this topic?",
            "Would you like me to expand on any part of that explanation?",
        ]
        return random.choice(follow_ups)
```

2. Update `agent.py` to use the new ResponseGenerator:

```python
from python.helpers.response_generator import ResponseGenerator

class Agent:
    def __init__(self, number: int, config: AgentConfig, context: AgentContext | None = None):
        # ... (existing initialization code)
        self.response_generator = ResponseGenerator(config)

    async def generate_response(self, context: Dict) -> str:
        return self.response_generator.generate_response(context)
```

3. Enhance the `knowledge_tool.py` to provide more context-aware information:

```python
class Knowledge(Tool):
    async def execute(self, question="", **kwargs):
        context = self.agent.conversation_state
        expanded_question = self.expand_question(question, context)
        
        online_results = await self.search_online(expanded_question)
        memory_results = await self.search_memory(expanded_question)
        
        combined_results = self.combine_results(online_results, memory_results, context)
        
        return Response(message=combined_results, break_loop=False)

    def expand_question(self, question, context):
        # Expand the question based on conversation context
        expanded = f"{question} (Context: topic={context.topic}, intent={context.user_intent})"
        return expanded

    async def search_online(self, question):
        # Implement online search logic
        pass

    async def search_memory(self, question):
        # Implement memory search logic
        pass

    def combine_results(self, online_results, memory_results, context):
        # Combine and prioritize results based on context
        combined = []
        for result in online_results + memory_results:
            relevance = self.calculate_relevance(result, context)
            combined.append((relevance, result))
        
        combined.sort(reverse=True)
        return [result for _, result in combined[:5]]  # Return top 5 most relevant results

    def calculate_relevance(self, result, context):
        # Calculate result relevance based on context
        # This is a simplified example
        relevance = 0
        if context.topic.lower() in result.lower():
            relevance += 1
        if context.user_intent.lower() in result.lower():
            relevance += 1
        return relevance
```

## Implementing Continuous Learning

To make our agent even more powerful, let's implement a basic continuous learning mechanism.

1. Create a new file `python/helpers/learner.py`:

```python
from python.helpers.vector_db import VectorDB

class Learner:
    def __init__(self, agent_config):
        self.config = agent_config
        self.db = VectorDB(self.config.logger, self.config.embeddings_model)

    def learn_from_interaction(self, user_message, agent_response, feedback=None):
        # Create a learning entry
        entry = f"User: {user_message}\nAgent: {agent_response}\nFeedback: {feedback}"
        
        # Save the entry to the vector database
        self.db.insert_text(entry)

    def get_relevant_learnings(self, context, limit=5):
        query = f"{context['resolved_message']} {context['conversation_state'].topic}"
        results = self.db.search_similarity(query, limit)
        return [result.page_content for result in results]

    def update_prompt_with_learnings(self, prompt, learnings):
        learning_section = "\n\n# Relevant Past Interactions\n"
        for learning in learnings:
            learning_section += f"- {learning}\n"
        return prompt + learning_section
```

2. Update `agent.py` to incorporate the Learner:

```python
from python.helpers.learner import Learner

class Agent:
    def __init__(self, number: int, config: AgentConfig, context: AgentContext | None = None):
        # ... (existing initialization code)
        self.learner = Learner(config)

    async def message_loop(self, msg: str):
        # ... (existing code)

        # Get relevant learnings
        relevant_learnings = self.learner.get_relevant_learnings(context)

        # Update dynamic prompt with learnings
        dynamic_prompt = self.learner.update_prompt_with_learnings(dynamic_prompt, relevant_learnings)

        # Generate response
        response = await self.generate_response(context)

        # Learn from this interaction
        self.learner.learn_from_interaction(msg, response)

        # ... (rest of the method)
```

## Conclusion

In this lesson, we've significantly enhanced Agent Zero's natural language understanding and generation capabilities. We've implemented:

1. Improved prompt engineering techniques
2. Context-aware responses using conversation state tracking
3. Coreference resolution for better understanding of user inputs
4. Topic segmentation to maintain conversation coherence
5. Advanced response generation using templates and context
6. A basic continuous learning mechanism

These enhancements will make Agent Zero more intelligent, context-aware, and capable of maintaining coherent, engaging conversations. The implementation of continuous learning also allows the agent to improve over time based on its interactions.

To further improve Agent Zero, consider the following next steps:

1. Implement more sophisticated natural language understanding models (e.g., named entity recognition, sentiment analysis)
2. Enhance the continuous learning mechanism with reinforcement learning techniques
3. Develop more advanced response generation methods, possibly using fine-tuned language models
4. Implement multi-turn dialogue management for handling complex conversations

Remember to always test your enhancements thoroughly and continuously gather user feedback to identify areas for improvement.