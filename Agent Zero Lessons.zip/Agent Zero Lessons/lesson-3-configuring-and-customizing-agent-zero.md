# Lesson 3: Configuring and Customizing Agent Zero

## Introduction

In this lesson, we'll dive deep into the configuration and customization options available in Agent Zero. We'll explore how to tailor the agent's behavior, capabilities, and performance to suit your specific needs. By the end of this lesson, you'll be able to fine-tune Agent Zero for various use cases and extend its functionality.

Let's start by revisiting the project structure to remind ourselves where the key configuration files are located:

```
agent-zero/
│
├── agent.py
├── example.env
├── initialize.py
├── models.py
├── README.md
├── requirements.txt
├── run_cli.py
├── run_ui.py
│
├── docker/
│   └── ...
│
├── knowledge/
│   └── .gitkeep
│
├── logs/
│   └── .gitkeep
│
├── memory/
│   └── .gitkeep
│
├── prompts/
│   └── default/
│       ├── agent.memory.md
│       ├── agent.system.md
│       ├── agent.tools.md
│       └── ...
│
├── python/
│   ├── helpers/
│   │   └── ...
│   │
│   └── tools/
│       ├── call_subordinate.py
│       ├── code_execution_tool.py
│       ├── knowledge_tool.py
│       └── ...
│
├── tests/
│   └── ...
│
├── tmp/
│   └── .gitkeep
│
├── webui/
│   └── ...
│
└── work_dir/
    └── .gitkeep
```

## 1. Deep dive into initialize.py and AgentConfig

The `initialize.py` file is the central configuration point for Agent Zero. It's where you set up the AI models, configure the agent's behavior, and define various operational parameters. Let's break down the key components of this file and the `AgentConfig` class.

### 1.1 initialize.py

Here's a typical structure of the `initialize.py` file:

```python
import models
from agent import AgentConfig

def initialize():
    # Configure AI models
    chat_llm = models.get_openai_chat(model_name="gpt-4", temperature=0)
    utility_llm = models.get_openai_chat(model_name="gpt-3.5-turbo", temperature=0)
    embedding_llm = models.get_openai_embedding(model_name="text-embedding-ada-002")

    # Create and return AgentConfig
    config = AgentConfig(
        chat_model=chat_llm,
        utility_model=utility_llm,
        embeddings_model=embedding_llm,
        auto_memory_count=3,
        rate_limit_requests=15,
        max_tool_response_length=3000,
        code_exec_docker_enabled=True,
        code_exec_ssh_enabled=True,
        # Other configuration options...
    )

    return config
```

Let's go through the main sections:

1. **AI Model Configuration**: Here you choose which AI models to use for different purposes:
   - `chat_llm`: The main language model for generating responses
   - `utility_llm`: A potentially smaller/faster model for utility tasks
   - `embedding_llm`: The model used for creating embeddings for memory and search

2. **AgentConfig Creation**: This is where you set various parameters that control the agent's behavior and capabilities.

### 1.2 AgentConfig Class

The `AgentConfig` class (defined in `agent.py`) contains all the configuration options for Agent Zero. Here's a more detailed look at its structure:

```python
from dataclasses import dataclass, field
from typing import Any, Dict
from langchain.schema import BaseLLM
from langchain.chat_models import BaseChatModel
from langchain.embeddings import Embeddings

@dataclass
class AgentConfig:
    chat_model: BaseChatModel | BaseLLM
    utility_model: BaseChatModel | BaseLLM
    embeddings_model: Embeddings
    prompts_subdir: str = ""
    memory_subdir: str = ""
    knowledge_subdir: str = ""
    auto_memory_count: int = 3
    auto_memory_skip: int = 2
    rate_limit_seconds: int = 60
    rate_limit_requests: int = 15
    rate_limit_input_tokens: int = 0
    rate_limit_output_tokens: int = 0
    msgs_keep_max: int = 25
    msgs_keep_start: int = 5
    msgs_keep_end: int = 10
    response_timeout_seconds: int = 60
    max_tool_response_length: int = 3000
    code_exec_docker_enabled: bool = True
    code_exec_docker_name: str = "agent-zero-exe"
    code_exec_docker_image: str = "frdel/agent-zero-exe:latest"
    code_exec_docker_ports: dict[str, int] = field(
        default_factory=lambda: {"22/tcp": 50022}
    )
    code_exec_docker_volumes: dict[str, dict[str, str]] = field(
        default_factory=lambda: {
            files.get_abs_path("work_dir"): {"bind": "/root", "mode": "rw"}
        }
    )
    code_exec_ssh_enabled: bool = True
    code_exec_ssh_addr: str = "localhost"
    code_exec_ssh_port: int = 50022
    code_exec_ssh_user: str = "root"
    code_exec_ssh_pass: str = "toor"
    additional: Dict[str, Any] = field(default_factory=dict)
```

Key configuration options:

- **AI Models**: `chat_model`, `utility_model`, `embeddings_model`
- **Prompt and Memory Management**: `prompts_subdir`, `memory_subdir`, `knowledge_subdir`, `auto_memory_count`, `auto_memory_skip`
- **Rate Limiting**: `rate_limit_seconds`, `rate_limit_requests`, `rate_limit_input_tokens`, `rate_limit_output_tokens`
- **Conversation Management**: `msgs_keep_max`, `msgs_keep_start`, `msgs_keep_end`, `response_timeout_seconds`
- **Code Execution**: Options for Docker and SSH-based code execution environments

### 1.3 Customizing the Configuration

To customize Agent Zero's behavior, you can modify the `initialize()` function in `initialize.py`. Here are some examples:

1. **Changing the main language model**:
   ```python
   chat_llm = models.get_openai_chat(model_name="gpt-3.5-turbo-16k", temperature=0.2)
   ```

2. **Adjusting memory usage**:
   ```python
   config = AgentConfig(
       # ...
       auto_memory_count=5,
       auto_memory_skip=1,
       # ...
   )
   ```

3. **Modifying rate limits**:
   ```python
   config = AgentConfig(
       # ...
       rate_limit_seconds=120,
       rate_limit_requests=30,
       rate_limit_input_tokens=8000,
       rate_limit_output_tokens=2000,
       # ...
   )
   ```

4. **Changing code execution settings**:
   ```python
   config = AgentConfig(
       # ...
       code_exec_docker_enabled=False,
       code_exec_ssh_enabled=True,
       code_exec_ssh_addr="remote_server.example.com",
       code_exec_ssh_port=22,
       code_exec_ssh_user="agent_user",
       code_exec_ssh_pass="secure_password",
       # ...
   )
   ```

## 2. Customizing prompts in the prompts/ directory

Prompts play a crucial role in defining the agent's behavior and capabilities. They are stored in the `prompts/default/` directory and can be customized to change how the agent interacts and responds.

### 2.1 Key Prompt Files

1. **agent.system.md**: Defines the agent's role, capabilities, and general behavior.
2. **agent.tools.md**: Describes available tools and how to use them.
3. **agent.memory.md**: Template for memory-related operations.

### 2.2 Customizing the System Prompt

Let's look at how we can modify the `agent.system.md` file to change the agent's behavior:

```markdown
# Your role
- Your name is {{agent_name}}
- You are an AI research assistant specializing in scientific literature analysis
- Your primary goal is to help researchers find relevant papers, summarize findings, and identify research gaps

# Communication
- Your response is a JSON containing the following fields:
    1. thoughts: Array of thoughts regarding the current research task
    2. tool_name: Name of the tool to be used
    3. tool_args: Object of arguments that are passed to the tool

# Step by step instruction manual for research tasks
1. Understand the research question or topic
2. Search for relevant papers using the knowledge_tool
3. Analyze and summarize key findings
4. Identify gaps in current research
5. Suggest potential future research directions

# General operation manual
- Always cite sources for your information
- Prioritize peer-reviewed articles from reputable journals
- When unsure, ask for clarification before proceeding
```

This customized prompt turns Agent Zero into a specialized research assistant.

### 2.3 Adding New Prompt Files

You can create new prompt files for specific scenarios or tools. For example, let's create a `research_summary.md` prompt:

```markdown
# Research Summary Template

Title: {{paper_title}}
Authors: {{paper_authors}}
Year: {{paper_year}}

## Key Findings
1. {{finding_1}}
2. {{finding_2}}
3. {{finding_3}}

## Methodology
{{methodology_summary}}

## Limitations
{{limitations}}

## Future Directions
{{future_directions}}

## Relevance to Current Research
{{relevance_analysis}}
```

To use this new prompt, you'll need to update the relevant tool or create a new one that utilizes this prompt template.

## 3. Adding and modifying tools in python/tools/

Tools extend the agent's capabilities, allowing it to perform specific tasks or interact with external systems. Let's explore how to modify existing tools and create new ones.

### 3.1 Modifying an Existing Tool

Let's modify the `knowledge_tool.py` to include a new search engine:

```python
import os
from python.helpers import perplexity_search
from python.helpers import duckduckgo_search
from python.helpers import google_search  # New import
from . import memory_tool
import concurrent.futures
from python.helpers.tool import Tool, Response

class Knowledge(Tool):
    async def execute(self, question="", **kwargs):
        with concurrent.futures.ThreadPoolExecutor() as executor:
            # Schedule the functions to be run in parallel
            perplexity = executor.submit(perplexity_search.perplexity_search, question)
            duckduckgo = executor.submit(duckduckgo_search.search, question)
            google = executor.submit(google_search.search, question)  # New search engine
            future_memory = executor.submit(memory_tool.search, self.agent, question)

            # Wait for all functions to complete
            perplexity_result = perplexity.result() or ""
            duckduckgo_result = duckduckgo.result()
            google_result = google.result()  # New result
            memory_result = future_memory.result()

        msg = self.agent.read_prompt("tool.knowledge.response.md", 
                              online_sources = f"{perplexity_result}\n\n{duckduckgo_result}\n\n{google_result}",
                              memory = memory_result )

        return Response(message=msg, break_loop=False)
```

### 3.2 Creating a New Tool

Let's create a new tool for generating research summaries using the prompt we created earlier. This tool will demonstrate how to extend Agent Zero's capabilities with custom functionality.

Create a new file `python/tools/research_summary_tool.py`:

```python
from python.helpers.tool import Tool, Response

class ResearchSummary(Tool):
    async def execute(self, paper_title="", paper_authors="", paper_year="", 
                      findings=[], methodology="", limitations="", 
                      future_directions="", relevance="", **kwargs):
        summary = self.agent.read_prompt("research_summary.md",
                                         paper_title=paper_title,
                                         paper_authors=paper_authors,
                                         paper_year=paper_year,
                                         finding_1=findings[0] if len(findings) > 0 else "",
                                         finding_2=findings[1] if len(findings) > 1 else "",
                                         finding_3=findings[2] if len(findings) > 2 else "",
                                         methodology_summary=methodology,
                                         limitations=limitations,
                                         future_directions=future_directions,
                                         relevance_analysis=relevance)
        
        return Response(message=summary, break_loop=False)
```

This tool uses the `research_summary.md` prompt we created earlier to generate a structured summary of a research paper.

To make this tool available to the agent, you need to update the `agent.tools.md` prompt to include instructions for using this new tool:


### research_summary_tool:
Generate a summary of a research paper.
Provide the following arguments:
- paper_title: Title of the paper
- paper_authors: Authors of the paper
- paper_year: Publication year
- findings: Array of key findings (up to 3)
- methodology: Summary of the research methodology
- limitations: Limitations of the study
- future_directions: Suggested future research directions
- relevance: Analysis of the paper's relevance to current research

**Example usage**:
```json
{
    "thoughts": [
        "I need to summarize the key points of this research paper...",
    ],
    "tool_name": "research_summary_tool",
    "tool_args": {
        "paper_title": "Advanced Natural Language Processing Techniques",
        "paper_authors": "Smith, J. and Johnson, M.",
        "paper_year": "2023",
        "findings": [
            "Improved accuracy in sentiment analysis",
            "Novel approach to named entity recognition",
            "Efficient method for text summarization"
        ],
        "methodology": "The study employed a combination of deep learning and statistical methods...",
        "limitations": "The model's performance was only tested on English language texts...",
        "future_directions": "Future work could explore multilingual applications...",
        "relevance": "This paper is highly relevant to our current research on improving chatbot responses..."
    }
}
```


## 4. Hands-on: Creating a custom configuration

Let's put everything we've learned together and create a custom configuration for a specialized research assistant agent. This example will showcase how to tailor Agent Zero for a specific use case.

### 4.1 Update initialize.py

First, let's update the `initialize.py` file to set up our research assistant configuration:

```python
import models
from agent import AgentConfig
from python.helpers import files

def initialize():
    chat_llm = models.get_openai_chat(model_name="gpt-4", temperature=0.2)
    utility_llm = models.get_openai_chat(model_name="gpt-3.5-turbo", temperature=0)
    embedding_llm = models.get_openai_embedding(model_name="text-embedding-ada-002")

    config = AgentConfig(
        chat_model=chat_llm,
        utility_model=utility_llm,
        embeddings_model=embedding_llm,
        prompts_subdir="research_assistant",
        memory_subdir="research_memory",
        knowledge_subdir="scientific_papers",
        auto_memory_count=5,
        rate_limit_requests=20,
        max_tool_response_length=5000,
        code_exec_docker_enabled=False,
        code_exec_ssh_enabled=False,
        additional={
            "research_fields": ["Natural Language Processing", "Machine Learning", "Artificial Intelligence"],
            "preferred_journals": ["Nature", "Science", "IEEE Transactions on Pattern Analysis and Machine Intelligence"]
        }
    )

    return config
```

This configuration sets up the agent with:
- GPT-4 as the main chat model
- GPT-3.5-Turbo as the utility model
- Custom subdirectories for prompts, memory, and knowledge
- Increased auto memory count and rate limit for research tasks
- Disabled code execution for security (assuming we don't need it for this use case)
- Additional fields for research specialization

### 4.2 Create Custom Prompts

Next, let's create custom prompts for our research assistant. Create a new directory `prompts/research_assistant/` and add the following files:

1. `agent.system.md`:

```markdown
# Your role
- You are an AI research assistant specializing in {{research_fields}}
- Your primary goal is to help researchers find relevant papers, summarize findings, and identify research gaps
- You have extensive knowledge of papers published in {{preferred_journals}}

# Communication
- Your response is a JSON containing the following fields:
    1. thoughts: Array of thoughts regarding the current research task
    2. tool_name: Name of the tool to be used
    3. tool_args: Object of arguments that are passed to the tool

# Step by step instruction manual for research tasks
1. Understand the research question or topic
2. Search for relevant papers using the knowledge_tool
3. Analyze and summarize key findings using the research_summary_tool
4. Identify gaps in current research
5. Suggest potential future research directions

# General operation manual
- Always cite sources for your information
- Prioritize peer-reviewed articles from reputable journals, especially {{preferred_journals}}
- When unsure, ask for clarification before proceeding
- Use your memory to recall previously discussed papers and findings
```

2. `research_summary.md`:

```markdown
# Research Summary Template

Title: {{paper_title}}
Authors: {{paper_authors}}
Year: {{paper_year}}

## Key Findings
1. {{finding_1}}
2. {{finding_2}}
3. {{finding_3}}

## Methodology
{{methodology_summary}}

## Limitations
{{limitations}}

## Future Directions
{{future_directions}}

## Relevance to Current Research
{{relevance_analysis}}

## Citation
{{citation}}
```

### 4.3 Implement a Custom Tool

To further specialize our research assistant, let's create a custom tool for generating research questions. Create a new file `python/tools/research_question_generator.py`:

```python
import random
from python.helpers.tool import Tool, Response

class ResearchQuestionGenerator(Tool):
    async def execute(self, topic="", subtopic="", **kwargs):
        research_questions = [
            f"What are the latest advancements in {topic} related to {subtopic}?",
            f"How does {subtopic} impact the overall field of {topic}?",
            f"What are the current limitations in {subtopic} within {topic}?",
            f"How can machine learning techniques be applied to improve {subtopic} in {topic}?",
            f"What ethical considerations arise when implementing {subtopic} in {topic}?"
        ]
        
        selected_question = random.choice(research_questions)
        
        response = f"Generated Research Question:\n\n{selected_question}\n\nThis question focuses on the intersection of {topic} and {subtopic}, which could lead to interesting research avenues. Consider using the knowledge_tool to find relevant papers on this topic."
        
        return Response(message=response, break_loop=False)
```

Don't forget to update the `agent.tools.md` file to include instructions for this new tool.

### 4.4 Test the Custom Configuration

Now that we have set up our custom research assistant configuration, let's test it with a sample interaction. Update your `run_cli.py` or create a new test script to use this configuration:

```python
import asyncio
from initialize import initialize
from agent import AgentContext

async def main():
    config = initialize()
    context = AgentContext(config)
    
    # Sample interaction
    user_input = "I'm interested in recent advancements in natural language processing for sentiment analysis. Can you help me find some relevant papers and summarize the key findings?"
    
    response = await context.communicate(user_input).result()
    print(f"Agent: {response}")

if __name__ == "__main__":
    asyncio.run(main())
```

When you run this script, you should see the agent using its specialized knowledge and tools to assist with the research query. It will likely use the `knowledge_tool` to find relevant papers, the `research_summary_tool` to summarize findings, and possibly the `research_question_generator` to suggest follow-up questions.

## 5. Conclusion

In this lesson, we've explored how to deeply customize Agent Zero for specific use cases. We've covered:

1. Modifying the `initialize.py` file to set up a specialized configuration
2. Creating custom prompts to define the agent's behavior and capabilities
3. Implementing new tools to extend the agent's functionality
4. Putting it all together in a custom research assistant configuration

By following these steps, you can create highly specialized AI agents tailored to various domains and tasks. The flexibility of Agent Zero allows you to adapt it to a wide range of applications, from research assistants to code analysis tools, creative writing aids, and more.

In the next lesson, we'll dive into the Agent Zero Web Interface, exploring how to create a user-friendly front-end for interacting with our customized agents.