# Lesson 13: Building Complex Tool Chains in Agent Zero

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Understanding Tool Chains](#understanding-tool-chains)
4. [Combining Multiple Tools for Advanced Functionality](#combining-multiple-tools-for-advanced-functionality)
5. [Implementing Tool-Use Strategies in Prompts](#implementing-tool-use-strategies-in-prompts)
6. [Creating Tools that Use Other Tools](#creating-tools-that-use-other-tools)
7. [Hands-on: Developing a Complex Tool Chain](#hands-on-developing-a-complex-tool-chain)
8. [Conclusion](#conclusion)

## 1. Introduction

As AI agents become more sophisticated, their ability to handle complex tasks often depends on chaining together multiple tools in intelligent ways. In this lesson, we'll explore how to build complex tool chains in Agent Zero, enabling your agents to tackle more intricate problems by combining the functionality of multiple tools.

## 2. Project Structure

Before we dive into building complex tool chains, let's review the relevant parts of the Agent Zero project structure:

```
agent-zero/
│
├── agent.py
├── models.py
├── python/
│   ├── helpers/
│   │   ├── tool.py
│   │   └── extract_tools.py
│   └── tools/
│       ├── code_execution_tool.py
│       ├── knowledge_tool.py
│       ├── memory_tool.py
│       └── response.py
├── prompts/
│   └── default/
│       ├── agent.system.md
│       └── agent.tools.md
└── initialize.py
```

This structure highlights the key files we'll be working with for building complex tool chains.

## 3. Understanding Tool Chains

A tool chain is a sequence of tools that are used together to accomplish a complex task. In Agent Zero, tool chains are not explicitly defined structures but rather emerge from the agent's ability to use multiple tools in succession based on its reasoning about the task at hand.

### 3.1 The Anatomy of a Tool

Let's first review the basic structure of a tool in Agent Zero. Here's a simplified version of the `Tool` class from `python/helpers/tool.py`:

```python
from abc import abstractmethod
from dataclasses import dataclass

@dataclass
class Response:
    message: str
    break_loop: bool

class Tool:
    def __init__(self, agent, name, args, message, **kwargs):
        self.agent = agent
        self.name = name
        self.args = args
        self.message = message

    @abstractmethod
    async def execute(self, **kwargs) -> Response:
        pass

    async def before_execution(self, **kwargs):
        # Log tool usage and prepare for execution
        pass

    async def after_execution(self, response, **kwargs):
        # Log tool response and perform any cleanup
        pass
```

This base class provides the foundation for all tools in Agent Zero.

## 4. Combining Multiple Tools for Advanced Functionality

To build complex tool chains, we need to understand how to combine multiple tools effectively. This is primarily achieved through the agent's decision-making process and the system prompt.

### 4.1 Modifying the System Prompt

Let's update the `agent.system.md` prompt to encourage the use of tool chains:

```markdown
# Your role
- You are an autonomous JSON AI task solving agent enhanced with knowledge and execution tools
- You are given tasks by your superior and you solve them using your subordinates and tools
- You can use multiple tools in sequence to solve complex problems
- Always consider whether a combination of tools could solve the task more effectively

# Step by step instruction manual to problem solving
1. Analyze the task and break it down into subtasks if necessary
2. For each subtask, consider which tool or combination of tools would be most effective
3. Execute tools in sequence, using the output of one tool as input for the next if needed
4. After each tool execution, evaluate the result and decide on the next step
5. Repeat steps 3-4 until the task is completed
6. Summarize the results and respond to the user

# Available tools
[List of available tools and their descriptions]
```

This updated prompt encourages the agent to think about using tools in combination.

## 5. Implementing Tool-Use Strategies in Prompts

To further enhance the agent's ability to use tool chains effectively, we can implement specific strategies in the prompts.

### 5.1 Tool Chain Strategies

Let's add some strategies to the `agent.tools.md` file:

```markdown
## Tool Chain Strategies:

1. Data Gathering and Analysis:
   - Use the knowledge_tool to gather information
   - Use the memory_tool to retrieve relevant past experiences
   - Combine the results and analyze using your own reasoning

2. Code Generation and Execution:
   - Use the knowledge_tool to find relevant coding patterns or solutions
   - Use the code_execution_tool to write and test code
   - Use the memory_tool to store successful code snippets for future use

3. Iterative Problem Solving:
   - Break down complex problems into smaller steps
   - Use appropriate tools for each step
   - Evaluate results after each step and adjust your approach

4. Multi-source Verification:
   - Use multiple knowledge sources (knowledge_tool, memory_tool) to cross-verify information
   - Implement a scoring system to weigh the reliability of different sources

Remember to consider these strategies when approaching complex tasks. Combine tools in creative ways to achieve the best results.
```

These strategies provide a framework for the agent to think about using tools in combination.

## 6. Creating Tools that Use Other Tools

One powerful way to create complex tool chains is by developing tools that internally use other tools. This allows for the creation of higher-level tools that encapsulate complex behaviors.

### 6.1 Example: Advanced Research Tool

Let's create an advanced research tool that combines the functionality of the `knowledge_tool`, `memory_tool`, and `code_execution_tool`:

```python
from python.helpers.tool import Tool, Response
from python.tools.knowledge_tool import Knowledge
from python.tools.memory_tool import Memory
from python.tools.code_execution_tool import CodeExecution

class AdvancedResearch(Tool):
    async def execute(self, query="", **kwargs):
        # Step 1: Gather information from knowledge tool
        knowledge_tool = Knowledge(self.agent, "knowledge_tool", {"question": query}, self.message)
        knowledge_response = await knowledge_tool.execute()

        # Step 2: Check memory for relevant past research
        memory_tool = Memory(self.agent, "memory_tool", {"query": query}, self.message)
        memory_response = await memory_tool.execute()

        # Step 3: Analyze and combine results
        combined_info = f"Knowledge: {knowledge_response.message}\nMemory: {memory_response.message}"
        analysis_code = f"""
        import json
        
        def analyze_research(data):
            # Perform analysis on the combined data
            # This is a simplified example
            knowledge = data.split('Knowledge: ')[1].split('\\nMemory:')[0]
            memory = data.split('Memory: ')[1]
            
            analysis = {
                "knowledge_length": len(knowledge),
                "memory_length": len(memory),
                "combined_length": len(knowledge) + len(memory)
            }
            
            return json.dumps(analysis)

        result = analyze_research('''{combined_info}''')
        print(result)
        """

        # Step 4: Execute analysis code
        code_tool = CodeExecution(self.agent, "code_execution_tool", {"runtime": "python", "code": analysis_code}, self.message)
        analysis_response = await code_tool.execute()

        # Step 5: Compile final response
        final_response = f"Research results:\n{combined_info}\n\nAnalysis:\n{analysis_response.message}"

        # Step 6: Store the research results in memory
        await memory_tool.execute(memorize=final_response)

        return Response(message=final_response, break_loop=False)
```

This `AdvancedResearch` tool demonstrates how we can combine multiple tools to create a more powerful, higher-level tool.

## 7. Hands-on: Developing a Complex Tool Chain

Now, let's put everything together and develop a complex tool chain for a specific task. We'll create a system that can research a topic, generate a report, and then answer questions about that report.

### 7.1 Implementing the Tool Chain

First, let's update our `initialize.py` to include our new `AdvancedResearch` tool:

```python
from agent import AgentConfig
import models
from python.tools.advanced_research import AdvancedResearch

def initialize():
    # ... existing initialization code ...

    config = AgentConfig(
        # ... existing config ...
        additional_tools=[AdvancedResearch],
    )

    return config
```

Now, let's create a script that uses this tool chain:

```python
import asyncio
from agent import AgentContext
from initialize import initialize

async def research_and_report():
    config = initialize()
    context = AgentContext(config)
    agent = context.agent0

    # Step 1: Conduct research
    research_query = "Explain the impact of artificial intelligence on modern healthcare."
    research_response = await agent.message_loop(
        f"Use the AdvancedResearch tool to research the following topic: {research_query}"
    )
    print("Research completed:", research_response)

    # Step 2: Generate report
    report_prompt = f"Based on the research results, generate a comprehensive report on {research_query}. Use the code_execution_tool to format the report as a markdown document."
    report_response = await agent.message_loop(report_prompt)
    print("Report generated:", report_response)

    # Step 3: Answer questions about the report
    questions = [
        "What are the main benefits of AI in healthcare?",
        "What ethical concerns arise from using AI in medical diagnosis?",
        "How is AI being used in drug discovery?"
    ]

    for question in questions:
        answer = await agent.message_loop(
            f"Based on the report we generated, please answer the following question: {question}"
        )
        print(f"Q: {question}\nA: {answer}\n")

asyncio.run(research_and_report())
```

This script demonstrates a complex tool chain that:
1. Uses the `AdvancedResearch` tool to gather and analyze information
2. Generates a report based on the research
3. Answers follow-up questions using the generated report

### 7.2 Extending the Tool Chain

To make our tool chain even more powerful, we could add additional steps:

1. Use the `memory_tool` to store the generated report for future reference
2. Implement a fact-checking step using the `knowledge_tool` to verify key points in the report
3. Use the `code_execution_tool` to generate visualizations based on the report data

These extensions would create an even more sophisticated and capable AI assistant.

## 8. Conclusion

In this lesson, we've explored the concept of complex tool chains in Agent Zero:

1. We learned how to combine multiple tools for advanced functionality
2. We implemented tool-use strategies in prompts to guide the agent's decision-making
3. We created tools that use other tools, allowing for higher-level abstractions
4. We developed a hands-on example of a complex tool chain for research, report generation, and question-answering

By mastering these techniques, you can create AI agents capable of handling intricate, multi-step tasks with greater efficiency and effectiveness. As you continue to develop your Agent Zero applications, consider how you can leverage tool chains to solve increasingly complex problems.

Remember, the key to successful tool chains lies in thoughtful design of your tools, clear strategies in your prompts, and a flexible agent architecture that can adapt to different task requirements. Happy coding!
