# Lesson 8: Code Execution and Environment Interaction

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [The code_execution_tool](#the-code_execution_tool)
   - [Python Execution](#python-execution)
   - [Node.js Execution](#nodejs-execution)
   - [Terminal Commands](#terminal-commands)
4. [Docker Integration for Safe Code Execution](#docker-integration-for-safe-code-execution)
5. [SSH Functionality for Remote Execution](#ssh-functionality-for-remote-execution)
6. [Hands-on: Setting up a Secure Execution Environment](#hands-on-setting-up-a-secure-execution-environment)
7. [Conclusion](#conclusion)

## Introduction

In this lesson, we'll dive deep into the code execution capabilities of Agent Zero. We'll explore how the system allows AI agents to interact with the environment, execute code in various languages, and manage security through Docker containers and SSH connections. This functionality is crucial for creating AI agents that can perform real-world tasks and interact with computer systems.

## Project Structure

Before we begin, let's review the relevant parts of the Agent Zero project structure:

```
agent-zero/
│
├── agent.py
├── initialize.py
│
├── python/
│   ├── helpers/
│   │   ├── docker.py
│   │   ├── shell_local.py
│   │   └── shell_ssh.py
│   │
│   └── tools/
│       └── code_execution_tool.py
│
├── docker/
│   ├── Dockerfile
│   └── initialize.sh
│
└── work_dir/
    └── .gitkeep
```

This structure highlights the key components we'll be discussing in this lesson.

## The code_execution_tool

The heart of Agent Zero's code execution functionality is the `code_execution_tool.py` file. This tool allows agents to execute code in Python, Node.js, or run terminal commands. Let's break down its main components and functionality.

### Python Execution

The `code_execution_tool` can execute Python code using the following method:

```python
async def execute_python_code(self, code):
    escaped_code = shlex.quote(code)
    command = f'python3 -c {escaped_code}'
    return await self.terminal_session(command)
```

This method takes a Python code snippet, escapes it to prevent command injection, and then runs it using the `python3` interpreter.

Example usage:
```python
python_code = """
print("Hello from Python!")
for i in range(5):
    print(f"Number: {i}")
"""
result = await self.execute_python_code(python_code)
```

### Node.js Execution

Similarly, Node.js code can be executed:

```python
async def execute_nodejs_code(self, code):
    escaped_code = shlex.quote(code)
    command = f'node -e {escaped_code}'
    return await self.terminal_session(command)
```

This method works similarly to the Python execution, but uses the `node` interpreter.

Example usage:
```python
nodejs_code = """
console.log('Hello from Node.js!');
for (let i = 0; i < 5; i++) {
    console.log(`Number: ${i}`);
}
"""
result = await self.execute_nodejs_code(nodejs_code)
```

### Terminal Commands

The tool can also execute arbitrary terminal commands:

```python
async def execute_terminal_command(self, command):
    return await self.terminal_session(command)
```

This method allows the agent to run any shell command.

Example usage:
```python
command = "ls -la"
result = await self.execute_terminal_command(command)
```

## Docker Integration for Safe Code Execution

To ensure security when executing potentially untrusted code, Agent Zero integrates with Docker. The `DockerContainerManager` class in `docker.py` handles the creation and management of Docker containers.

Key features of the Docker integration:

1. **Container Initialization**: The system can create a new container or use an existing one.

```python
def start_container(self) -> None:
    # ... (container initialization logic)
    self.container = self.client.containers.run(
        self.image,
        detach=True,
        ports=self.ports,
        name=self.name,
        volumes=self.volumes,
    )
```

2. **Security**: The container provides isolation, preventing executed code from affecting the host system.

3. **Resource Management**: Docker allows for easy resource allocation and limitation for executed code.

The `Dockerfile` in the `docker/` directory defines the environment for code execution:

```dockerfile
FROM debian:bookworm-slim

# Install necessary packages
RUN apt-get update && apt-get install -y \
    python3 \
    python3-pip \
    nodejs \
    npm \
    openssh-server \
    sudo

# Set up SSH
RUN mkdir /var/run/sshd && \
    echo 'root:toor' | chpasswd && \
    sed -i 's/#PermitRootLogin prohibit-password/PermitRootLogin yes/' /etc/ssh/sshd_config

# ... (additional setup)

EXPOSE 22

CMD ["/usr/local/bin/initialize.sh"]
```

This Dockerfile sets up a Debian-based environment with Python, Node.js, and SSH capabilities.

## SSH Functionality for Remote Execution

Agent Zero supports remote code execution through SSH. The `SSHInteractiveSession` class in `shell_ssh.py` manages SSH connections and command execution.

Key features of the SSH functionality:

1. **Connection Establishment**: The system can connect to remote servers using SSH.

```python
async def connect(self):
    self.client.connect(self.hostname, self.port, self.username, self.password)
    self.shell = self.client.invoke_shell()
```

2. **Command Execution**: Once connected, commands can be sent and output retrieved.

```python
def send_command(self, command: str):
    self.shell.send(command + "\n")

async def read_output(self) -> Tuple[str, str]:
    # ... (output reading logic)
```

3. **Security**: SSH provides encrypted communication for secure remote execution.

## Hands-on: Setting up a Secure Execution Environment

Let's set up a secure execution environment using Docker and SSH. We'll create a simple agent that can execute Python code in a Docker container.

1. First, ensure Docker is installed on your system.

2. Update the `initialize.py` file to enable Docker and SSH:

```python
def initialize():
    config = AgentConfig(
        # ... (other configurations)
        code_exec_docker_enabled = True,
        code_exec_docker_name = "agent-zero-exe",
        code_exec_docker_image = "frdel/agent-zero-exe:latest",
        code_exec_ssh_enabled = True,
        code_exec_ssh_addr = "localhost",
        code_exec_ssh_port = 50022,
        code_exec_ssh_user = "root",
        code_exec_ssh_pass = "toor",
    )
    return config
```

3. Create a simple agent that uses the `code_execution_tool`:

```python
from agent import Agent, AgentConfig
from initialize import initialize

async def main():
    config = initialize()
    agent = Agent(0, config)
    
    python_code = """
import random

numbers = [random.randint(1, 100) for _ in range(10)]
print(f"Random numbers: {numbers}")
print(f"Sum: {sum(numbers)}")
print(f"Average: {sum(numbers) / len(numbers)}")
"""
    
    result = await agent.get_tool("code_execution_tool").execute(runtime="python", code=python_code)
    print(result.message)

if __name__ == "__main__":
    import asyncio
    asyncio.run(main())
```

4. Run the script. You should see output similar to:

```
Agent 0: Using tool 'code_execution_tool':
Runtime: python
Code: 
import random

numbers = [random.randint(1, 100) for _ in range(10)]
print(f"Random numbers: {numbers}")
print(f"Sum: {sum(numbers)}")
print(f"Average: {sum(numbers) / len(numbers)}")

Agent 0 code execution output:
Random numbers: [23, 45, 67, 89, 12, 34, 56, 78, 90, 11]
Sum: 505
Average: 50.5

Agent 0: Response from tool 'code_execution_tool':
Random numbers: [23, 45, 67, 89, 12, 34, 56, 78, 90, 11]
Sum: 505
Average: 50.5
```

This example demonstrates how to set up and use the code execution environment securely using Docker and SSH.

## Conclusion

In this lesson, we explored the code execution capabilities of Agent Zero, including:

1. The `code_execution_tool` for running Python, Node.js, and terminal commands.
2. Docker integration for safe code execution in isolated environments.
3. SSH functionality for remote code execution.
4. A hands-on example of setting up and using a secure execution environment.

These features allow AI agents to interact with the environment, execute code, and perform complex tasks while maintaining security. As you develop your own AI agents, consider how you can leverage these capabilities to create powerful and flexible systems.

In the next lesson, we'll dive into natural language processing and AI model integration, exploring how Agent Zero interfaces with various AI models to power its conversational abilities.
