# Lesson 6: The Tool System: Building Blocks of Agent Functionality

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Tool Architecture](#tool-architecture)
4. [The Tool Base Class](#the-tool-base-class)
5. [Built-in Tools](#built-in-tools)
   5.1. [Response Tool](#response-tool)
   5.2. [Call Subordinate Tool](#call-subordinate-tool)
   5.3. [Knowledge Tool](#knowledge-tool)
6. [Hands-on: Creating a Custom Tool](#hands-on-creating-a-custom-tool)
7. [Conclusion](#conclusion)

## 1. Introduction

In this lesson, we'll dive deep into the Tool System of Agent Zero, which forms the foundation of the agent's functionality. Tools are modular components that allow the agent to perform specific actions or access particular capabilities. Understanding and mastering the Tool System is crucial for extending and customizing Agent Zero to suit various use cases.

## 2. Project Structure

Before we begin, let's review the relevant parts of the Agent Zero project structure:

```
agent-zero/
│
├── agent.py
├── python/
│   ├── helpers/
│   │   └── tool.py
│   └── tools/
│       ├── response.py
│       ├── call_subordinate.py
│       ├── knowledge_tool.py
│       └── ... (other tool files)
└── prompts/
    └── default/
        ├── agent.tools.md
        └── ... (other prompt files)
```

This structure highlights the key components we'll be focusing on in this lesson.

## 3. Tool Architecture

The Tool System in Agent Zero is designed with modularity and extensibility in mind. Each tool is a separate Python class that inherits from a base `Tool` class. This architecture allows for easy addition of new tools and modification of existing ones.

The main components of the Tool System are:

1. The `Tool` base class (defined in `python/helpers/tool.py`)
2. Individual tool classes (located in `python/tools/`)
3. Tool-related prompts (in `prompts/default/agent.tools.md`)

## 4. The Tool Base Class

Let's examine the `Tool` base class, which serves as the foundation for all tools in Agent Zero:

```python
# python/helpers/tool.py

from abc import abstractmethod
from dataclasses import dataclass
from agent import Agent
from python.helpers.print_style import PrintStyle
from python.helpers import messages

@dataclass
class Response:
    message: str
    break_loop: bool

class Tool:
    def __init__(self, agent: Agent, name: str, args: dict[str, str], message: str, **kwargs) -> None:
        self.agent = agent
        self.name = name
        self.args = args
        self.message = message

    @abstractmethod
    async def execute(self, **kwargs) -> Response:
        pass

    async def before_execution(self, **kwargs):
        # Implementation for actions before tool execution

    async def after_execution(self, response: Response, **kwargs):
        # Implementation for actions after tool execution

    def nice_key(self, key: str):
        # Utility method for formatting keys
```

Key points about the `Tool` base class:

- It's initialized with references to the agent, tool name, arguments, and the original message.
- The `execute` method is abstract and must be implemented by each tool.
- `before_execution` and `after_execution` methods allow for setup and cleanup actions.
- The `Response` class encapsulates the tool's output and whether to break the agent's message loop.

## 5. Built-in Tools

Agent Zero comes with several built-in tools. Let's examine three key tools to understand how they're implemented.

### 5.1. Response Tool

The Response Tool is used to provide the agent's final answer to the user.

```python
# python/tools/response.py

from python.helpers.tool import Tool, Response

class ResponseTool(Tool):
    async def execute(self, **kwargs):
        self.agent.set_data("timeout", self.agent.config.response_timeout_seconds)
        return Response(message=self.args["text"], break_loop=True)

    async def before_execution(self, **kwargs):
        self.log = self.agent.context.log.log(type="response", heading=f"{self.agent.agent_name}: Responding:", content=self.args.get("text", ""))

    async def after_execution(self, response, **kwargs):
        pass  # Do not add anything to the history or output
```

This tool sets a timeout, creates a log entry, and returns a `Response` object with the `break_loop` flag set to `True`, indicating that the agent's task is complete.

### 5.2. Call Subordinate Tool

The Call Subordinate Tool allows an agent to create and communicate with a subordinate agent.

```python
# python/tools/call_subordinate.py

from agent import Agent
from python.helpers.tool import Tool, Response

class Delegation(Tool):
    async def execute(self, message="", reset="", **kwargs):
        if self.agent.get_data("subordinate") is None or str(reset).lower().strip() == "true":
            subordinate = Agent(self.agent.number+1, self.agent.config, self.agent.context)
            subordinate.set_data("superior", self.agent)
            self.agent.set_data("subordinate", subordinate)
        return Response(message=await self.agent.get_data("subordinate").message_loop(message), break_loop=False)
```

This tool creates a new subordinate agent if necessary and runs its message loop with the provided message.

### 5.3. Knowledge Tool

The Knowledge Tool allows the agent to access external information and its own memory.

```python
# python/tools/knowledge_tool.py

import os
from python.helpers import perplexity_search, duckduckgo_search
from . import memory_tool
import concurrent.futures
from python.helpers.tool import Tool, Response
from python.helpers.print_style import PrintStyle
from python.helpers.errors import handle_error

class Knowledge(Tool):
    async def execute(self, question="", **kwargs):
        with concurrent.futures.ThreadPoolExecutor() as executor:
            # Perform searches in parallel
            perplexity = executor.submit(perplexity_search.perplexity_search, question) if os.getenv("API_KEY_PERPLEXITY") else None
            duckduckgo = executor.submit(duckduckgo_search.search, question)
            future_memory = executor.submit(memory_tool.search, self.agent, question)

            # Collect and format results
            perplexity_result = await self.get_result(perplexity, "Perplexity search failed: ")
            duckduckgo_result = await self.get_result(duckduckgo, "DuckDuckGo search failed: ")
            memory_result = await self.get_result(future_memory, "Memory search failed: ")

        msg = self.agent.read_prompt("tool.knowledge.response.md", 
                              online_sources = ((perplexity_result + "\n\n") if perplexity else "") + str(duckduckgo_result),
                              memory = memory_result)

        await self.agent.handle_intervention(msg)

        return Response(message=msg, break_loop=False)

    async def get_result(self, future, error_prefix):
        try:
            return future.result() if future else ""
        except Exception as e:
            handle_error(e)
            return error_prefix + str(e)
```

This tool performs parallel searches using Perplexity (if configured), DuckDuckGo, and the agent's memory, then combines the results.

## 6. Hands-on: Creating a Custom Tool

Now, let's create a custom tool to demonstrate how to extend Agent Zero's capabilities. We'll create a simple "Calculator" tool that can perform basic arithmetic operations.

First, create a new file `calculator_tool.py` in the `python/tools/` directory:

```python
# python/tools/calculator_tool.py

from python.helpers.tool import Tool, Response
import ast
import operator

class Calculator(Tool):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.operations = {
            ast.Add: operator.add,
            ast.Sub: operator.sub,
            ast.Mult: operator.mul,
            ast.Div: operator.truediv,
        }

    async def execute(self, expression="", **kwargs):
        try:
            result = self.evaluate(expression)
            return Response(message=f"The result of {expression} is {result}", break_loop=False)
        except Exception as e:
            return Response(message=f"Error in calculation: {str(e)}", break_loop=False)

    def evaluate(self, expression):
        node = ast.parse(expression, mode='eval')
        return self.eval_node(node.body)

    def eval_node(self, node):
        if isinstance(node, ast.Num):
            return node.n
        elif isinstance(node, ast.BinOp):
            return self.operations[type(node.op)](
                self.eval_node(node.left),
                self.eval_node(node.right)
            )
        else:
            raise TypeError(node)
```

Next, update the `agent.tools.md` file in the `prompts/default/` directory to include the new Calculator tool:

```markdown
# prompts/default/agent.tools.md

...

### calculator_tool:
Performs basic arithmetic calculations.
Provide the "expression" argument with a mathematical expression as a string.
**Example usage**:
~~~json
{
    "thoughts": [
        "I need to calculate 2 + 2 * 3",
    ],
    "tool_name": "calculator_tool",
    "tool_args": {
        "expression": "2 + 2 * 3"
    }
}
~~~

...
```

Now, the Calculator tool is ready to be used by the agent. When the agent encounters a mathematical problem, it can use this tool to perform calculations.

## 7. Conclusion

In this lesson, we've explored the Tool System of Agent Zero, which forms the foundation of the agent's functionality. We've examined the architecture of the Tool System, looked at the base `Tool` class, and studied several built-in tools. Finally, we created a custom Calculator tool to demonstrate how to extend Agent Zero's capabilities.

Key takeaways:
1. The Tool System is modular and extensible, allowing for easy addition of new capabilities.
2. Each tool inherits from the `Tool` base class and implements the `execute` method.
3. Built-in tools like Response, Call Subordinate, and Knowledge provide essential functionalities.
4. Custom tools can be created to add specific capabilities to the agent.
5. The `prompts/default/agent.tools.md` file needs to be updated when adding new tools to provide instructions to the agent.

By mastering the Tool System, you can significantly enhance and customize Agent Zero to suit a wide range of applications and use cases. In the next lesson, we'll explore memory and knowledge management in AI agents, which will further expand our understanding of building sophisticated AI systems.
