# Lesson 12: Performance Optimization and Scaling in Agent Zero

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Rate Limiting and Token Management](#rate-limiting-and-token-management)
4. [Efficient Use of Vector Databases](#efficient-use-of-vector-databases)
5. [Strategies for Handling Long Conversations](#strategies-for-handling-long-conversations)
6. [Hands-on: Optimizing an Agent Zero Application](#hands-on-optimizing-an-agent-zero-application)
7. [Conclusion](#conclusion)

## 1. Introduction

As AI agent systems like Agent Zero grow in complexity and usage, performance optimization and scaling become crucial aspects of development. This lesson focuses on techniques to improve the efficiency and scalability of Agent Zero, covering rate limiting, token management, efficient use of vector databases, and strategies for handling long conversations.

## 2. Project Structure

Before we dive into the optimization techniques, let's review the relevant parts of the Agent Zero project structure:

```
agent-zero/
│
├── agent.py
├── models.py
├── python/
│   ├── helpers/
│   │   ├── rate_limiter.py
│   │   └── vector_db.py
│   └── tools/
│       └── memory_tool.py
├── prompts/
│   └── default/
│       ├── fw.msg_cleanup.md
│       └── msg.memory_cleanup.md
└── initialize.py
```

This structure highlights the key files we'll be working with for performance optimization.

## 3. Rate Limiting and Token Management

Rate limiting is crucial for managing API usage and preventing overuse of AI models. Agent Zero implements rate limiting in the `rate_limiter.py` file.

### 3.1 Understanding the RateLimiter Class

Let's examine the `RateLimiter` class in `python/helpers/rate_limiter.py`:

```python
from collections import deque
from dataclasses import dataclass
import time

@dataclass
class CallRecord:
    timestamp: float
    input_tokens: int
    output_tokens: int = 0

class RateLimiter:
    def __init__(self, logger, max_calls, max_input_tokens, max_output_tokens, window_seconds=60):
        self.logger = logger
        self.max_calls = max_calls
        self.max_input_tokens = max_input_tokens
        self.max_output_tokens = max_output_tokens
        self.window_seconds = window_seconds
        self.call_records = deque()

    def limit_call_and_input(self, input_token_count):
        current_time = time.time()
        self._wait_if_needed(current_time, input_token_count)
        new_record = CallRecord(current_time, input_token_count)
        self.call_records.append(new_record)
        return new_record

    def set_output_tokens(self, output_token_count):
        if self.call_records:
            self.call_records[-1].output_tokens += output_token_count
        return self

    # Other methods (clean_old_records, get_counts, wait_if_needed) ...
```

This class manages rate limiting based on the number of calls, input tokens, and output tokens within a specified time window.

### 3.2 Implementing Rate Limiting in Agent Zero

To use the `RateLimiter` in Agent Zero, we integrate it into the `Agent` class in `agent.py`:

```python
from python.helpers.rate_limiter import RateLimiter

class Agent:
    def __init__(self, number, config, context=None):
        # ... other initializations ...
        self.rate_limiter = RateLimiter(
            self.context.log,
            max_calls=self.config.rate_limit_requests,
            max_input_tokens=self.config.rate_limit_input_tokens,
            max_output_tokens=self.config.rate_limit_output_tokens,
            window_seconds=self.config.rate_limit_seconds,
        )

    async def message_loop(self, msg):
        # ... existing code ...
        
        while True:
            try:
                # ... prepare prompt ...
                
                # Apply rate limiting
                formatted_inputs = prompt.format(messages=self.history)
                tokens = int(len(formatted_inputs) / 4)  # Rough estimation
                self.rate_limiter.limit_call_and_input(tokens)
                
                # Generate response
                async for chunk in chain.astream(inputs):
                    # ... process chunk ...
                
                # Set output tokens
                self.rate_limiter.set_output_tokens(int(len(agent_response) / 4))
                
                # ... rest of the loop ...
            
            except Exception as e:
                # ... error handling ...
```

This implementation ensures that the agent respects the configured rate limits for API calls and token usage.

## 4. Efficient Use of Vector Databases

Vector databases are crucial for implementing long-term memory in AI agents. Efficient use of these databases can significantly improve performance.

### 4.1 Optimizing the VectorDB Class

Let's examine and optimize the `VectorDB` class in `python/helpers/vector_db.py`:

```python
from langchain.storage import LocalFileStore
from langchain.embeddings import CacheBackedEmbeddings
from langchain_community.vectorstores import FAISS
import faiss
from langchain_community.docstore.in_memory import InMemoryDocstore

class VectorDB:
    def __init__(self, logger, embeddings_model, in_memory=False, memory_dir="./memory", knowledge_dir="./knowledge"):
        self.logger = logger
        self.embeddings_model = embeddings_model
        self.em_dir = files.get_abs_path(memory_dir, "embeddings")
        self.db_dir = files.get_abs_path(memory_dir, "database")
        self.kn_dir = files.get_abs_path(knowledge_dir) if knowledge_dir else ""
        
        # Use LocalFileStore for caching embeddings
        self.store = LocalFileStore(self.em_dir)
        self.embedder = CacheBackedEmbeddings.from_bytes_store(
            embeddings_model, 
            self.store, 
            namespace=getattr(embeddings_model, 'model', getattr(embeddings_model, 'model_name', "default"))
        )

        # Initialize FAISS index
        if os.path.exists(self.db_dir) and files.exists(self.db_dir, "index.faiss"):
            self.db = FAISS.load_local(
                folder_path=self.db_dir,
                embeddings=self.embedder,
                allow_dangerous_deserialization=True
            )
        else:
            index = faiss.IndexFlatL2(len(self.embedder.embed_query("example text")))
            self.db = FAISS(
                embedding_function=self.embedder,
                index=index,
                docstore=InMemoryDocstore(),
                index_to_docstore_id={}
            )

        # Preload knowledge files
        if self.kn_dir:
            self.preload_knowledge(self.kn_dir, self.db_dir)

    # Other methods (search_similarity, insert_text, etc.) ...
```

Key optimizations in this class include:
1. Using `CacheBackedEmbeddings` to reduce repeated computations of embeddings.
2. Employing FAISS for efficient similarity search.
3. Preloading knowledge files to reduce startup time for subsequent runs.

### 4.2 Efficient Memory Operations

To optimize memory operations, we can implement batching in the `memory_tool.py`:

```python
from python.helpers.vector_db import VectorDB

class Memory(Tool):
    async def execute(self, **kwargs):
        # ... existing code ...

        if "memorize" in kwargs:
            batch_size = 100  # Adjust based on your needs
            memories = kwargs["memorize"]
            for i in range(0, len(memories), batch_size):
                batch = memories[i:i+batch_size]
                result = save_batch(self.agent, batch)
        
        # ... rest of the method ...

def save_batch(agent, memories):
    db = get_db(agent)
    ids = db.insert_documents(memories)
    return f"Saved {len(ids)} memories."
```

This batching approach reduces the number of database operations, improving performance for bulk memory insertions.

## 5. Strategies for Handling Long Conversations

Long conversations can lead to performance issues due to increasing context size. Agent Zero implements two main strategies to handle this:

### 5.1 Message Cleanup

Agent Zero uses a cleanup mechanism to summarize and reduce the size of the conversation history. This is implemented in the `Agent` class:

```python
class Agent:
    # ... other methods ...

    async def cleanup_history(self, max, keep_start, keep_end):
        if len(self.history) <= max:
            return self.history

        first_x = self.history[:keep_start]
        last_y = self.history[-keep_end:]
        middle_part = self.history[keep_start:-keep_end]

        new_middle_part = await self.replace_middle_messages(middle_part)

        self.history = first_x + new_middle_part + last_y

        return self.history

    async def replace_middle_messages(self, middle_messages):
        cleanup_prompt = self.read_prompt("fw.msg_cleanup.md")
        summary = await self.send_adhoc_message(
            system=cleanup_prompt,
            msg=self.concat_messages(middle_messages),
            output_label="Mid messages cleanup summary"
        )
        return [HumanMessage(content=summary)]
```

The cleanup process summarizes the middle part of the conversation, keeping the most relevant information while reducing the overall token count.

### 5.2 Memory Management

For very long conversations, it's often more efficient to store information in the agent's long-term memory rather than keeping it all in the conversation history. This is handled by the `memory_tool.py`:

```python
class Memory(Tool):
    async def execute(self, **kwargs):
        if "memorize" in kwargs:
            result = save(self.agent, kwargs["memorize"])
        elif "query" in kwargs:
            result = search(self.agent, kwargs["query"])
        # ... other operations ...

def save(agent, text):
    db = get_db(agent)
    id = db.insert_text(text)
    return agent.read_prompt("fw.memory_saved.md", memory_id=id)

def search(agent, query, count=5, threshold=0.1):
    db = get_db(agent)
    docs = db.search_similarity_threshold(query, count, threshold)
    if len(docs) == 0:
        return agent.read_prompt("fw.memories_not_found.md", query=query)
    else:
        return str(docs)
```

This approach allows the agent to store and retrieve information from its long-term memory, reducing the need to keep all information in the active conversation context.

## 6. Hands-on: Optimizing an Agent Zero Application

Now, let's apply these optimization techniques to an Agent Zero application. We'll create a simple agent that can handle long conversations efficiently.

### 6.1 Configuring the Agent

First, let's set up our `initialize.py` with optimized settings:

```python
from agent import AgentConfig
import models

def initialize():
    chat_llm = models.get_openai_chat(model_name="gpt-4-1106-preview", temperature=0)
    utility_llm = models.get_openai_chat(model_name="gpt-3.5-turbo-16k", temperature=0)
    embedding_llm = models.get_openai_embedding(model_name="text-embedding-ada-002")

    config = AgentConfig(
        chat_model = chat_llm,
        utility_model = utility_llm,
        embeddings_model = embedding_llm,
        auto_memory_count = 5,
        rate_limit_requests = 20,
        rate_limit_input_tokens = 40000,
        rate_limit_output_tokens = 10000,
        rate_limit_seconds = 60,
        msgs_keep_max = 30,
        msgs_keep_start = 5,
        msgs_keep_end = 15,
    )

    return config
```

This configuration sets up rate limiting and message cleanup parameters for efficient operation.

### 6.2 Implementing an Optimized Agent

Now, let's create a simple script that uses this optimized agent for a long conversation:

```python
import asyncio
from agent import AgentContext
from initialize import initialize

async def optimized_conversation():
    config = initialize()
    context = AgentContext(config)
    agent = context.agent0

    # Simulate a long conversation
    for i in range(50):
        user_message = f"This is message number {i+1}. Please remember this number and summarize our conversation so far."
        response = await agent.message_loop(user_message)
        print(f"User: {user_message}")
        print(f"Agent: {response}")

        # Every 10 messages, ask the agent to recall a previous number
        if (i + 1) % 10 == 0:
            recall_message = f"What was the number I mentioned 5 messages ago?"
            recall_response = await agent.message_loop(recall_message)
            print(f"User: {recall_message}")
            print(f"Agent: {recall_response}")

asyncio.run(optimized_conversation())
```

This script simulates a long conversation, regularly asking the agent to summarize and recall information. The optimized agent will use its memory tool to store and retrieve information efficiently, while the rate limiter ensures we don't exceed API limits.

## 7. Conclusion

In this lesson, we've explored various techniques for optimizing the performance and scalability of Agent Zero:

1. We implemented rate limiting to manage API usage efficiently.
2. We optimized the vector database operations for faster memory access.
3. We developed strategies for handling long conversations through message cleanup and efficient memory management.

By applying these techniques, you can significantly improve the performance of your Agent Zero applications, allowing them to handle longer conversations and more complex tasks without sacrificing efficiency or exceeding API limits.

Remember, optimization is an ongoing process. As you develop more complex agents, continually monitor their performance and apply these techniques as needed. Happy coding!
