# Lesson 14: Extending Agent Zero - Integration with External Services

## Table of Contents
1. [Introduction](#introduction)
2. [Adding Support for External APIs](#adding-support-for-external-apis)
3. [Implementing OAuth and Other Authentication Methods](#implementing-oauth-and-other-authentication-methods)
4. [Creating Tools for Specific Services](#creating-tools-for-specific-services)
5. [Hands-on: Integrating a Third-Party API](#hands-on-integrating-a-third-party-api)
6. [Conclusion](#conclusion)

## Introduction

Welcome to Lesson 14 of our Agent Zero series! In this lesson, we'll explore how to extend Agent Zero's capabilities by integrating external services. This is a crucial skill for creating more powerful and versatile AI agents that can interact with the wider digital ecosystem.

By the end of this lesson, you'll be able to:
- Add support for external APIs to Agent Zero
- Implement various authentication methods, including OAuth
- Create custom tools for specific third-party services
- Integrate a real-world API into Agent Zero

Let's start by looking at our current project structure:

```
agent-zero/
├── agent.py
├── initialize.py
├── models.py
├── requirements.txt
├── run_cli.py
├── run_ui.py
├── prompts/
│   └── default/
│       ├── agent.system.md
│       ├── agent.tools.md
│       └── ...
├── python/
│   ├── helpers/
│   │   ├── files.py
│   │   ├── print_style.py
│   │   └── ...
│   └── tools/
│       ├── code_execution_tool.py
│       ├── knowledge_tool.py
│       ├── memory_tool.py
│       └── ...
└── webui/
    ├── index.html
    ├── index.css
    └── index.js
```

As we progress through this lesson, we'll be adding new files and modifying existing ones to incorporate external service integration.

## Adding Support for External APIs

The first step in extending Agent Zero with external services is to create a flexible system for making API requests. We'll create a new helper module for this purpose.

Let's add a new file `api_client.py` in the `python/helpers/` directory:

```
agent-zero/
└── python/
    └── helpers/
        └── api_client.py
```

Here's the content for `api_client.py`:

```python
import requests
from typing import Dict, Any

class APIClient:
    def __init__(self, base_url: str):
        self.base_url = base_url
        self.session = requests.Session()

    def request(self, method: str, endpoint: str, **kwargs) -> Dict[str, Any]:
        url = f"{self.base_url}/{endpoint}"
        response = self.session.request(method, url, **kwargs)
        response.raise_for_status()
        return response.json()

    def get(self, endpoint: str, **kwargs) -> Dict[str, Any]:
        return self.request("GET", endpoint, **kwargs)

    def post(self, endpoint: str, **kwargs) -> Dict[str, Any]:
        return self.request("POST", endpoint, **kwargs)

    def put(self, endpoint: str, **kwargs) -> Dict[str, Any]:
        return self.request("PUT", endpoint, **kwargs)

    def delete(self, endpoint: str, **kwargs) -> Dict[str, Any]:
        return self.request("DELETE", endpoint, **kwargs)
```

This `APIClient` class provides a flexible foundation for making HTTP requests to external APIs. It uses the `requests` library and includes methods for common HTTP verbs (GET, POST, PUT, DELETE).

To use this client, you would typically instantiate it with a base URL and then make requests to specific endpoints. For example:

```python
client = APIClient("https://api.example.com/v1")
response = client.get("users", params={"limit": 10})
```

Next, let's modify the `initialize.py` file to include our new `APIClient` in the `AgentConfig`:

```python
from python.helpers.api_client import APIClient

def initialize():
    # ... (existing code)

    config = AgentConfig(
        # ... (existing configuration)
        api_client=APIClient("https://api.example.com/v1"),
        # ... (rest of the configuration)
    )

    return config
```

By adding the `APIClient` to the `AgentConfig`, we make it available throughout the agent system, allowing tools and other components to easily make API requests.

## Implementing OAuth and Other Authentication Methods

Many external APIs require authentication, with OAuth being a common standard. Let's extend our `APIClient` to support OAuth 2.0 authentication.

First, we'll add a new file `oauth_client.py` in the `python/helpers/` directory:

```
agent-zero/
└── python/
    └── helpers/
        └── oauth_client.py
```

Here's the content for `oauth_client.py`:

```python
from requests_oauthlib import OAuth2Session
from typing import Dict, Any

class OAuthClient:
    def __init__(self, client_id: str, client_secret: str, token_url: str, authorize_url: str, scope: list):
        self.client_id = client_id
        self.client_secret = client_secret
        self.token_url = token_url
        self.authorize_url = authorize_url
        self.scope = scope
        self.session = OAuth2Session(client_id, scope=scope)
        self.token = None

    def get_authorization_url(self) -> str:
        authorization_url, _ = self.session.authorization_url(self.authorize_url)
        return authorization_url

    def fetch_token(self, authorization_response: str) -> Dict[str, Any]:
        self.token = self.session.fetch_token(
            self.token_url,
            authorization_response=authorization_response,
            client_secret=self.client_secret
        )
        return self.token

    def request(self, method: str, url: str, **kwargs) -> Dict[str, Any]:
        response = self.session.request(method, url, **kwargs)
        response.raise_for_status()
        return response.json()

    def get(self, url: str, **kwargs) -> Dict[str, Any]:
        return self.request("GET", url, **kwargs)

    def post(self, url: str, **kwargs) -> Dict[str, Any]:
        return self.request("POST", url, **kwargs)

    def put(self, url: str, **kwargs) -> Dict[str, Any]:
        return self.request("PUT", url, **kwargs)

    def delete(self, url: str, **kwargs) -> Dict[str, Any]:
        return self.request("DELETE", url, **kwargs)
```

This `OAuthClient` class handles OAuth 2.0 authentication flow and provides methods for making authenticated requests.

To use this client, you would typically follow these steps:

1. Initialize the client with OAuth credentials and URLs.
2. Get the authorization URL and redirect the user to it.
3. Capture the authorization response and use it to fetch the token.
4. Make authenticated requests using the client.

Here's an example of how to use the `OAuthClient`:

```python
client = OAuthClient(
    client_id="your_client_id",
    client_secret="your_client_secret",
    token_url="https://api.example.com/oauth/token",
    authorize_url="https://api.example.com/oauth/authorize",
    scope=["read", "write"]
)

# Get the authorization URL
auth_url = client.get_authorization_url()
print(f"Please visit this URL to authorize the application: {auth_url}")

# After the user authorizes and is redirected, capture the full redirect URL
redirect_url = input("Enter the full redirect URL: ")

# Fetch the token
token = client.fetch_token(redirect_url)

# Now you can make authenticated requests
response = client.get("https://api.example.com/v1/user")
print(response)
```

## Creating Tools for Specific Services

Now that we have a flexible system for making API requests and handling authentication, let's create a tool for a specific service. We'll use GitHub as an example.

First, let's create a new file `github_tool.py` in the `python/tools/` directory:

```
agent-zero/
└── python/
    └── tools/
        └── github_tool.py
```

Here's the content for `github_tool.py`:

```python
from python.helpers.tool import Tool, Response
from python.helpers.oauth_client import OAuthClient

class GitHubTool(Tool):
    def __init__(self, agent, name, args, message):
        super().__init__(agent, name, args, message)
        self.client = OAuthClient(
            client_id=self.agent.config.github_client_id,
            client_secret=self.agent.config.github_client_secret,
            token_url="https://github.com/login/oauth/access_token",
            authorize_url="https://github.com/login/oauth/authorize",
            scope=["repo", "user"]
        )
        self.api_base_url = "https://api.github.com"

    async def execute(self, **kwargs):
        action = kwargs.get("action")
        if action == "list_repos":
            return await self.list_repos()
        elif action == "create_issue":
            return await self.create_issue(kwargs.get("repo"), kwargs.get("title"), kwargs.get("body"))
        else:
            return Response(message=f"Unknown action: {action}", break_loop=False)

    async def list_repos(self):
        response = self.client.get(f"{self.api_base_url}/user/repos")
        repo_names = [repo["name"] for repo in response]
        return Response(message=f"Your GitHub repositories: {', '.join(repo_names)}", break_loop=False)

    async def create_issue(self, repo, title, body):
        response = self.client.post(
            f"{self.api_base_url}/repos/{repo}/issues",
            json={"title": title, "body": body}
        )
        return Response(message=f"Issue created: {response['html_url']}", break_loop=False)
```

This `GitHubTool` allows the agent to interact with GitHub's API, specifically to list repositories and create issues.

To make this tool available to the agent, we need to add it to the `agent.tools.md` prompt file:

```markdown
## Tools available:

...

### github_tool:
Interact with GitHub. Allowed actions are "list_repos" and "create_issue".
**Example usage**:
```json
{
    "thoughts": [
        "The user wants to list their GitHub repositories.",
        "I can use the github_tool to fetch this information.",
    ],
    "tool_name": "github_tool",
    "tool_args": {
        "action": "list_repos"
    }
}
```

Or to create an issue:
```json
{
    "thoughts": [
        "The user wants to create a GitHub issue.",
        "I'll use the github_tool to create the issue.",
    ],
    "tool_name": "github_tool",
    "tool_args": {
        "action": "create_issue",
        "repo": "username/repo",
        "title": "Bug: Application crashes on startup",
        "body": "The application is crashing immediately after launching. Steps to reproduce: 1. ..."
    }
}
```
```

Finally, update the `initialize.py` file to include the GitHub credentials:

```python
def initialize():
    # ... (existing code)

    config = AgentConfig(
        # ... (existing configuration)
        github_client_id=os.getenv("GITHUB_CLIENT_ID"),
        github_client_secret=os.getenv("GITHUB_CLIENT_SECRET"),
        # ... (rest of the configuration)
    )

    return config
```

Remember to add these environment variables to your `.env` file:

```
GITHUB_CLIENT_ID=your_github_client_id
GITHUB_CLIENT_SECRET=your_github_client_secret
```

## Hands-on: Integrating a Third-Party API

For our hands-on exercise, let's integrate a weather API into Agent Zero. We'll use the OpenWeatherMap API as an example.

First, sign up for a free API key at [OpenWeatherMap](https://openweathermap.org/api).

Next, let's create a new file `weather_tool.py` in the `python/tools/` directory:

```
agent-zero/
└── python/
    └── tools/
        └── weather_tool.py
```

Here's the content for `weather_tool.py`:

```python
from python.helpers.tool import Tool, Response
from python.helpers.api_client import APIClient

class WeatherTool(Tool):
    def __init__(self, agent, name, args, message):
        super().__init__(agent, name, args, message)
        self.client = APIClient("http://api.openweathermap.org/data/2.5")
        self.api_key = self.agent.config.openweathermap_api_key

    async def execute(self, **kwargs):
        city = kwargs.get("city")
        if not city:
            return Response(message="Please provide a city name.", break_loop=False)

        try:
            response = self.client.get(
                "weather",
                params={
                    "q": city,
                    "appid": self.api_key,
                    "units": "metric"
                }
            )
            temp = response["main"]["temp"]
            description = response["weather"][0]["description"]
            return Response(
                message=f"The current weather in {city} is {description} with a temperature of {temp}°C.",
                break_loop=False
            )
        except Exception as e:
            return Response(message=f"Error fetching weather data: {str(e)}", break_loop=False)
```

Now, let's update the `agent.tools.md` prompt file to include our new weather tool:

```markdown
## Tools available:

...

### weather_tool:
Get current weather information for a specified city.
**Example usage**:
```json
{
    "thoughts": [
        "The user wants to know the weather in London.",
        "I can use the weather_tool to fetch this information.",
    ],
    "tool_name": "weather_tool",
    "tool_args": {
        "city": "London"
    }
}
```
```

Finally, update the `initialize.py` file to include the OpenWeatherMap API key:

```python
def initialize():
    # ... (existing code)

    config = AgentConfig(
        # ... (existing configuration)
        openweathermap_api_key=os.getenv("OPENWEATHERMAP_API_KEY"),
        # ... (rest of the configuration)
    )

    return config
```

Add the API key to your `.env` file:

```
OPENWEATHERMAP_API_KEY=your_openweathermap_api_key
```

Now you can use the weather tool in your Agent Zero conversations! Here's an example of how it might look:

User: What's the weather like in Tokyo right now?

Agent: Certainly! I'll use the weather tool to fetch the current weather information for Tokyo.

```json
{
    "thoughts": [
        "The user wants to know the current weather in Tokyo.",
        "I can use the weather_tool to get this information.",
        "I'll make a request with 'Tokyo' as the city parameter."
    ],
    "tool_name": "weather_tool",
    "tool_args": {
        "city": "Tokyo"
    }
}
```

Response from weather_tool: The current weather in Tokyo is clear sky with a temperature of 22.5°C.

Agent: Based on the information from the weather tool, I can tell you that the weather in Tokyo right now is quite pleasant. It's currently clear sky, which means you can expect sunny conditions with little to no cloud cover. The temperature is 22.5°C (about 72.5°F), which is generally considered comfortable - not too hot and not too cold.

This kind of weather is great for outdoor activities or sightseeing if you're in Tokyo. However, it's always a good idea to stay hydrated, especially on clear days, and consider sun protection like sunscreen or a hat if you're planning to be outside for extended periods.

Is there anything else you'd like to know about the weather in Tokyo or any other city?

## Best Practices for Integrating External Services

When integrating external services into Agent Zero, keep these best practices in mind:

1. **Error Handling**: Always implement robust error handling. APIs can fail for various reasons, and your tool should gracefully handle and report these errors.

2. **Rate Limiting**: Be aware of and respect the rate limits of the APIs you're using. Implement rate limiting in your tools to avoid exceeding these limits.

3. **Caching**: For data that doesn't change frequently, consider implementing caching to reduce the number of API calls and improve response times.

4. **Security**: Never expose API keys or secrets in your code. Always use environment variables or secure secret management systems.

5. **Modularity**: Design your tools to be modular and reusable. This will make it easier to maintain and extend your agent's capabilities.

6. **Documentation**: Clearly document how to use each tool, including required parameters and expected outputs.

7. **Testing**: Implement unit tests for your tools to ensure they behave correctly under various conditions.

## Exercise: Extending the Weather Tool

As an exercise, try extending the `WeatherTool` to include a forecast feature. You can use the OpenWeatherMap 5-day forecast API for this.

Here's a starter code to help you:

```python
async def execute(self, **kwargs):
    action = kwargs.get("action", "current")
    city = kwargs.get("city")
    if not city:
        return Response(message="Please provide a city name.", break_loop=False)

    try:
        if action == "current":
            return await self.get_current_weather(city)
        elif action == "forecast":
            return await self.get_forecast(city)
        else:
            return Response(message=f"Unknown action: {action}", break_loop=False)
    except Exception as e:
        return Response(message=f"Error fetching weather data: {str(e)}", break_loop=False)

async def get_forecast(self, city):
    response = self.client.get(
        "forecast",
        params={
            "q": city,
            "appid": self.api_key,
            "units": "metric"
        }
    )
    # Process the forecast data and return a formatted response
    # ...
```

Don't forget to update the `agent.tools.md` file to include the new forecast functionality.

## Conclusion

In this lesson, we've explored how to extend Agent Zero by integrating external services. We've covered:

1. Adding support for external APIs using a flexible `APIClient`.
2. Implementing OAuth authentication for secure API access.
3. Creating tools for specific services, using GitHub as an example.
4. Integrating a third-party API (OpenWeatherMap) into Agent Zero.

These skills will allow you to significantly expand the capabilities of your AI agents, enabling them to interact with a wide range of external services and APIs.

As you continue to develop with Agent Zero, consider what other external services could enhance your agent's capabilities. Could you integrate a translation API? A stock market data service? The possibilities are endless!

Remember, the key to successful integration is understanding the API you're working with, handling authentication and errors gracefully, and designing your tools to be modular and easy to use within the Agent Zero framework.

In the next lesson, we'll explore advanced natural language understanding and generation techniques to further enhance your agent's conversational abilities. Until then, happy coding!