# Lesson 2: Agent Zero Architecture: A Bird's Eye View

## 1. Project Structure and File Layout

Before we dive into the details of Agent Zero's architecture, let's revisit the project structure to get a better understanding of how different components are organized:

```
agent-zero/
│
├── agent.py
├── example.env
├── initialize.py
├── models.py
├── README.md
├── requirements.txt
├── run_cli.py
├── run_ui.py
│
├── docker/
│   ├── Dockerfile
│   └── ...
│
├── knowledge/
│   └── .gitkeep
│
├── logs/
│   └── .gitkeep
│
├── memory/
│   └── .gitkeep
│
├── prompts/
│   └── default/
│       ├── agent.memory.md
│       ├── agent.system.md
│       ├── agent.tools.md
│       └── ...
│
├── python/
│   ├── helpers/
│   │   ├── docker.py
│   │   ├── errors.py
│   │   ├── files.py
│   │   └── ...
│   │
│   └── tools/
│       ├── call_subordinate.py
│       ├── code_execution_tool.py
│       ├── knowledge_tool.py
│       └── ...
│
├── tests/
│   └── ...
│
├── tmp/
│   └── .gitkeep
│
├── webui/
│   ├── index.css
│   ├── index.html
│   └── index.js
│
└── work_dir/
    └── .gitkeep
```

This structure helps organize the different components of Agent Zero:

- Root directory: Contains main Python files for the agent and configuration
- `docker/`: Docker-related files for containerization
- `knowledge/`: Directory for storing knowledge base files
- `logs/`: Directory for storing log files
- `memory/`: Directory for storing agent memory files
- `prompts/`: Contains prompt templates for the agent
- `python/`: Houses helper functions and tool implementations
- `tests/`: Contains test files
- `webui/`: Files for the web-based user interface
- `work_dir/`: A working directory for the agent to use during execution

## 2. Key Components: Agent, AgentContext, AgentConfig

Let's explore the three main components that form the core of Agent Zero's architecture:

### 2.1 Agent

The `Agent` class is the central component of Agent Zero. It represents an individual AI agent capable of processing messages, using tools, and interacting with its environment. 

Key features of the `Agent` class:

1. Initialization with a unique number and configuration
2. Message processing and response generation
3. Tool usage and management
4. Memory management
5. Interaction with other agents (superior and subordinate)

Here's a simplified example of the `Agent` class structure:

```python
class Agent:
    def __init__(self, number: int, config: AgentConfig, context: AgentContext | None = None):
        self.number = number
        self.config = config
        self.context = context or AgentContext(config)
        self.history = []
        self.data = {}

    async def message_loop(self, msg: str):
        # Process incoming message
        # Generate response using AI model
        # Use tools as needed
        # Return response

    async def append_message(self, msg: str, human: bool = False):
        # Add message to conversation history

    async def handle_intervention(self):
        # Handle user interventions during processing

    # Other methods for tool usage, memory management, etc.
```

### 2.2 AgentContext

The `AgentContext` class manages the context in which an agent operates. It handles multiple agents, their interactions, and shared resources.

Key features of the `AgentContext` class:

1. Management of multiple agent instances
2. Handling of shared resources (e.g., logging)
3. Communication between agents
4. Context persistence and retrieval

Here's a simplified example of the `AgentContext` class:

```python
class AgentContext:
    _contexts: dict[str, "AgentContext"] = {}

    def __init__(self, config: AgentConfig, id: str | None = None, agent0: Agent | None = None):
        self.id = id or str(uuid.uuid4())
        self.config = config
        self.log = Log.Log()
        self.agent0 = agent0 or Agent(0, self.config, self)
        self.paused = False
        self.streaming_agent: Agent | None = None
        self._contexts[self.id] = self

    @staticmethod
    def get(id: str):
        return AgentContext._contexts.get(id, None)

    def reset(self):
        # Reset the context, creating a new agent0

    def communicate(self, msg: str, broadcast_level: int = 1):
        # Handle communication within the context

    # Other methods for context management
```

### 2.3 AgentConfig

The `AgentConfig` class holds the configuration settings for an agent. It includes settings for AI models, rate limiting, memory management, and more.

Key features of the `AgentConfig` class:

1. AI model configurations (chat, utility, embeddings)
2. Memory and knowledge management settings
3. Rate limiting and token management
4. Code execution settings

Here's a simplified example of the `AgentConfig` class:

```python
@dataclass
class AgentConfig:
    chat_model: BaseChatModel | BaseLLM
    utility_model: BaseChatModel | BaseLLM
    embeddings_model: Embeddings
    prompts_subdir: str = ""
    memory_subdir: str = ""
    knowledge_subdir: str = ""
    auto_memory_count: int = 3
    rate_limit_seconds: int = 60
    rate_limit_requests: int = 15
    max_tool_response_length: int = 3000
    code_exec_docker_enabled: bool = True
    code_exec_ssh_enabled: bool = True
    # Other configuration options
```

## 3. The Role of Prompts and Tools

Prompts and tools are crucial components that define the behavior and capabilities of Agent Zero.

### 3.1 Prompts

Prompts are text templates that guide the AI model's responses and behavior. They are stored in the `prompts/` directory and are used to:

1. Define the agent's personality and capabilities
2. Provide instructions for using tools
3. Format responses for different scenarios

Example of a system prompt (`prompts/default/agent.system.md`):

```markdown
# Your role
- Your name is {{agent_name}}
- You are an autonomous JSON AI task solving agent enhanced with knowledge and execution tools
- You are given tasks by your superior and you solve them using your subordinates and tools
- You never just talk about solutions, never inform the user about intentions, you are the one to execute actions using your tools and get things done
- Remember the language of your user to respond with the same language

# Communication
- Your response is a JSON containing the following fields:
    1. thoughts: Array of thoughts regarding the current task
    2. tool_name: Name of the tool to be used
    3. tool_args: Object of arguments that are passed to the tool

## Response example
{
    "thoughts": [
        "The user has requested extracting a zip file downloaded yesterday.",
        "Steps to solution are...",
        "I will process step by step...",
        "Analysis of step..."
    ],
    "tool_name": "name_of_tool",
    "tool_args": {
        "arg1": "val1",
        "arg2": "val2"
    }
}

# Step by step instruction manual for problem solving
...

```

### 3.2 Tools

Tools are Python modules that extend the agent's capabilities, allowing it to perform specific tasks or interact with external systems. They are located in the `python/tools/` directory.

Key features of tools:

1. Defined interface for integration with the agent
2. Specific functionality (e.g., code execution, knowledge retrieval)
3. Error handling and response formatting

Example of a simple tool (`python/tools/calculator_tool.py`):

```python
from python.helpers.tool import Tool, Response

class Calculator(Tool):
    async def execute(self, operation: str, a: float, b: float, **kwargs):
        result = None
        if operation == "add":
            result = a + b
        elif operation == "subtract":
            result = a - b
        elif operation == "multiply":
            result = a * b
        elif operation == "divide":
            if b != 0:
                result = a / b
            else:
                return Response(message="Error: Division by zero", break_loop=False)
        
        if result is not None:
            return Response(message=f"The result of {a} {operation} {b} is {result}", break_loop=False)
        else:
            return Response(message="Error: Invalid operation", break_loop=False)
```

## 4. Understanding the Message Loop

The message loop is the core process that drives the agent's interaction with users and its environment. It's implemented in the `message_loop` method of the `Agent` class.

Key steps in the message loop:

1. Receive user input
2. Process the input using the AI model
3. Parse the AI model's response
4. Execute requested tools
5. Format and return the response
6. Repeat the process

Here's a simplified version of the message loop:

```python
async def message_loop(self, msg: str):
    try:
        await self.append_message(msg, human=True)
        
        while True:
            agent_response = await self.generate_response()
            await self.append_message(agent_response)
            
            tool_request = self.parse_tool_request(agent_response)
            if tool_request:
                tool_response = await self.execute_tool(tool_request)
                if tool_response.break_loop:
                    return tool_response.message
            else:
                return agent_response

    except Exception as e:
        # Handle exceptions
        pass
```

This loop continues until a final response is generated or an exception occurs.

## Conclusion

In this lesson, we've taken a bird's eye view of Agent Zero's architecture, exploring its key components, file structure, and core concepts. We've seen how the `Agent`, `AgentContext`, and `AgentConfig` classes work together to create a flexible and powerful AI agent system.

We've also explored the crucial roles that prompts and tools play in defining the agent's behavior and capabilities. Finally, we've looked at the message loop, which drives the agent's interaction and decision-making process.

In the next lessons, we'll dive deeper into each of these components, learning how to customize and extend Agent Zero to suit various use cases and requirements.

