# Lesson 5: Understanding the Core Agent System

## Introduction

In this lesson, we'll dive deep into the core of Agent Zero's system by examining the `agent.py` file. We'll explore the `Agent` class, `AgentContext`, and how these components work together to manage conversations and agent interactions. By the end of this lesson, you'll have a thorough understanding of the agent system's architecture and be able to extend its functionality.

## Project Structure

Before we begin, let's look at the relevant files and directories for the core agent system:

```
agent-zero/
│
├── agent.py
├── models.py
├── initialize.py
├── prompts/
│   └── default/
│       ├── agent.system.md
│       ├── agent.tools.md
│       └── ... (other prompt files)
├── python/
│   ├── helpers/
│   │   ├── log.py
│   │   ├── print_style.py
│   │   └── ... (other helper files)
│   └── tools/
│       ├── response.py
│       ├── call_subordinate.py
│       ├── knowledge_tool.py
│       └── ... (other tool files)
```

This structure shows the main files we'll be working with in this lesson. The `agent.py` file is the core of the agent system, while the `prompts/` and `python/tools/` directories contain supporting files for agent behavior and capabilities.

## 1. Detailed Look at agent.py

The `agent.py` file defines the core classes and functionality of the Agent Zero system. Let's break down its main components:

### 1.1 AgentContext Class

The `AgentContext` class manages the context for each agent instance:

```python
class AgentContext:
    _contexts: dict[str, "AgentContext"] = {}
    _counter: int = 0

    def __init__(self, config: "AgentConfig", id: str | None = None, agent0: "Agent|None" = None):
        self.id = id or str(uuid.uuid4())
        self.config = config
        self.log = Log.Log()
        self.agent0 = agent0 or Agent(0, self.config, self)
        self.paused = False
        self.streaming_agent: Agent | None = None
        self.process: DeferredTask | None = None
        AgentContext._counter += 1
        self.no = AgentContext._counter

        self._contexts[self.id] = self

    @staticmethod
    def get(id: str):
        return AgentContext._contexts.get(id, None)

    @staticmethod
    def first():
        if not AgentContext._contexts:
            return None
        return list(AgentContext._contexts.values())[0]

    @staticmethod
    def remove(id: str):
        context = AgentContext._contexts.pop(id, None)
        if context and context.process:
            context.process.kill()
        return context

    def reset(self):
        if self.process:
            self.process.kill()
        self.log.reset()
        self.agent0 = Agent(0, self.config, self)
        self.streaming_agent = None
        self.paused = False

    def communicate(self, msg: str, broadcast_level: int = 1):
        # ... (implementation details)
```

The `AgentContext` class manages multiple agent contexts, allowing for parallel conversations and agent hierarchies. It provides methods for creating, retrieving, and removing contexts, as well as resetting and communicating with agents.

### 1.2 AgentConfig Class

The `AgentConfig` class holds the configuration for each agent:

```python
@dataclass
class AgentConfig:
    chat_model: BaseChatModel | BaseLLM
    utility_model: BaseChatModel | BaseLLM
    embeddings_model: Embeddings
    prompts_subdir: str = ""
    memory_subdir: str = ""
    knowledge_subdir: str = ""
    auto_memory_count: int = 3
    auto_memory_skip: int = 2
    rate_limit_seconds: int = 60
    rate_limit_requests: int = 15
    rate_limit_input_tokens: int = 0
    rate_limit_output_tokens: int = 0
    msgs_keep_max: int = 25
    msgs_keep_start: int = 5
    msgs_keep_end: int = 10
    response_timeout_seconds: int = 60
    max_tool_response_length: int = 3000
    code_exec_docker_enabled: bool = True
    code_exec_docker_name: str = "agent-zero-exe"
    code_exec_docker_image: str = "frdel/agent-zero-exe:latest"
    code_exec_docker_ports: dict[str, int] = field(
        default_factory=lambda: {"22/tcp": 50022}
    )
    code_exec_docker_volumes: dict[str, dict[str, str]] = field(
        default_factory=lambda: {
            files.get_abs_path("work_dir"): {"bind": "/root", "mode": "rw"}
        }
    )
    code_exec_ssh_enabled: bool = True
    code_exec_ssh_addr: str = "localhost"
    code_exec_ssh_port: int = 50022
    code_exec_ssh_user: str = "root"
    code_exec_ssh_pass: str = "toor"
    additional: Dict[str, Any] = field(default_factory=dict)
```

This class defines various configuration options for the agent, including model settings, memory management, rate limiting, and code execution settings.

### 1.3 Agent Class

The `Agent` class is the core of the agent system:

```python
class Agent:
    def __init__(self, number: int, config: AgentConfig, context: AgentContext | None = None):
        self.config = config
        self.context = context or AgentContext(config)
        self.number = number
        self.agent_name = f"Agent {self.number}"
        self.history = []
        self.last_message = ""
        self.intervention_message = ""
        self.rate_limiter = rate_limiter.RateLimiter(
            self.context.log,
            max_calls=self.config.rate_limit_requests,
            max_input_tokens=self.config.rate_limit_input_tokens,
            max_output_tokens=self.config.rate_limit_output_tokens,
            window_seconds=self.config.rate_limit_seconds,
        )
        self.data = {}

    async def message_loop(self, msg: str):
        # ... (implementation details)

    async def append_message(self, msg: str, human: bool = False):
        # ... (implementation details)

    async def send_adhoc_message(self, system: str, msg: str, output_label: str):
        # ... (implementation details)

    async def handle_intervention(self, progress: str = ""):
        # ... (implementation details)

    async def process_tools(self, msg: str):
        # ... (implementation details)

    def get_tool(self, name: str, args: dict, message: str, **kwargs):
        # ... (implementation details)

    async def fetch_memories(self, reset_skip=False):
        # ... (implementation details)

    def log_from_stream(self, stream: str, logItem: Log.LogItem):
        # ... (implementation details)

    def call_extension(self, name: str, **kwargs) -> Any:
        pass
```

The `Agent` class manages individual agent instances, handling message processing, tool execution, memory management, and interventions.

## 2. The Message Loop and Conversation Flow

The heart of the Agent class is the `message_loop` method, which processes incoming messages and generates responses:

```python
async def message_loop(self, msg: str):
    try:
        printer = PrintStyle(italic=True, font_color="#b3ffd9", padding=False)
        user_message = self.read_prompt("fw.user_message.md", message=msg)
        await self.append_message(user_message, human=True)
        memories = await self.fetch_memories(True)

        while True:
            self.context.streaming_agent = self
            agent_response = ""

            try:
                system = (
                    self.read_prompt("agent.system.md", agent_name=self.agent_name)
                    + "\n\n"
                    + self.read_prompt("agent.tools.md")
                )
                memories = await self.fetch_memories()
                if memories:
                    system += "\n\n" + memories

                prompt = ChatPromptTemplate.from_messages(
                    [
                        SystemMessage(content=system),
                        MessagesPlaceholder(variable_name="messages"),
                    ]
                )

                inputs = {"messages": self.history}
                chain = prompt | self.config.chat_model

                async for chunk in chain.astream(inputs):
                    await self.handle_intervention(agent_response)
                    content = str(chunk.content) if hasattr(chunk, "content") else str(chunk)
                    if content:
                        printer.stream(content)
                        agent_response += content
                        self.log_from_stream(agent_response, log)

                await self.handle_intervention(agent_response)

                if self.last_message == agent_response:
                    await self.append_message(agent_response)
                    warning_msg = self.read_prompt("fw.msg_repeat.md")
                    await self.append_message(warning_msg, human=True)
                    PrintStyle(font_color="orange", padding=True).print(warning_msg)
                    self.context.log.log(type="warning", content=warning_msg)
                else:
                    await self.append_message(agent_response)
                    tools_result = await self.process_tools(agent_response)
                    if tools_result:
                        return tools_result

            except InterventionException:
                pass
            except asyncio.CancelledError as e:
                PrintStyle(
                    font_color="white", background_color="red", padding=True
                ).print(f"Context {self.context.id} terminated during message loop")
                raise e
            except RepairableException as e:
                error_message = errors.format_error(e)
                msg_response = self.read_prompt("fw.error.md", error=error_message)
                await self.append_message(msg_response, human=True)
                PrintStyle(font_color="red", padding=True).print(msg_response)
                self.context.log.log(type="error", content=msg_response)
            except Exception as e:
                error_message = errors.format_error(e)
                PrintStyle(font_color="red", padding=True).print(error_message)
                self.context.log.log(type="error", content=error_message)
                raise e

    finally:
        self.context.streaming_agent = None
```

This method handles the main conversation flow, including:

1. Processing user input
2. Fetching relevant memories
3. Generating agent responses
4. Handling interventions
5. Processing tools based on agent responses
6. Error handling and logging

## 3. Hands-on: Extending the Agent Class

Let's extend the `Agent` class to add a new capability: sentiment analysis of user messages. We'll create a new method that uses a hypothetical sentiment analysis tool and integrates it into the message loop.

### Step 1: Add a new tool for sentiment analysis

Create a new file `python/tools/sentiment_tool.py`:

```python
from python.helpers.tool import Tool, Response

class SentimentTool(Tool):
    async def execute(self, text="", **kwargs):
        # This is a simplified example. In a real-world scenario,
        # you would use a proper sentiment analysis library or API.
        positive_words = ["happy", "good", "great", "excellent"]
        negative_words = ["sad", "bad", "terrible", "awful"]
        
        words = text.lower().split()
        positive_count = sum(word in positive_words for word in words)
        negative_count = sum(word in negative_words for word in words)
        
        if positive_count > negative_count:
            sentiment = "positive"
        elif negative_count > positive_count:
            sentiment = "negative"
        else:
            sentiment = "neutral"
        
        return Response(message=f"The sentiment of the text is {sentiment}.", break_loop=False)
```

### Step 2: Update the Agent class

Modify the `agent.py` file to include the new sentiment analysis capability:

```python
class Agent:
    # ... (existing code)

    async def analyze_sentiment(self, text: str):
        sentiment_tool = self.get_tool("sentiment_tool", {"text": text}, "Analyzing sentiment")
        response = await sentiment_tool.execute(text=text)
        return response.message

    async def message_loop(self, msg: str):
        try:
            # ... (existing code)

            sentiment = await self.analyze_sentiment(msg)
            await self.append_message(f"Sentiment analysis: {sentiment}", human=True)

            while True:
                # ... (existing code)

        finally:
            self.context.streaming_agent = None
```

### Step 3: Update the system prompt

Modify the `prompts/default/agent.system.md` file to include instructions for using sentiment information:

```markdown
# Your role
- Your name is {{agent_name}}
- You are an autonomous JSON AI task solving agent enhanced with knowledge and execution tools
- You have access to sentiment analysis of user messages and should use this information to tailor your responses appropriately

# Communication
- Your response is a JSON containing the following fields:
    1. thoughts: Array of thoughts regarding the current task and user sentiment
    2. tool_name: Name of the tool to be used
    3. tool_args: Object of arguments that are passed to the tool

# ... (rest of the existing prompt)
```

With these changes, the Agent will now perform sentiment analysis on user messages and incorporate this information into its decision-making process.

## Conclusion

In this lesson, we've explored the core of the Agent Zero system by examining the `agent.py` file in detail. We've looked at the `AgentContext` class for managing multiple agent instances, the `AgentConfig` class for configuring agent behavior, and the `Agent` class itself, which handles the main conversation loop and tool execution.

We've also extended the `Agent` class with a new sentiment analysis capability, demonstrating how to add new functionalities to the system. This extensibility allows you to customize and enhance Agent Zero to suit your specific needs and use cases.

Key takeaways from this lesson include:

1. Understanding the structure and relationships between `AgentContext`, `AgentConfig`, and `Agent` classes
2. The importance of the message loop in managing conversations and agent responses
3. How tools are integrated and executed within the agent system
4. The role of prompts in guiding agent behavior
5. The extensibility of the Agent Zero system, allowing for new capabilities to be added easily

In the next lesson, we'll dive deeper into the tool system, exploring how to create and customize tools to expand the agent's capabilities further.
