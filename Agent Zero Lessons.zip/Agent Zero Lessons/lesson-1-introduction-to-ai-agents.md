# Lesson 1: Introduction to AI Agents: Understanding Agent Zero

## 1. What are AI agents and their applications

AI agents are autonomous or semi-autonomous software entities that can perceive their environment, make decisions, and take actions to achieve specific goals. These agents utilize artificial intelligence techniques, such as machine learning and natural language processing, to interact with users, systems, or other agents.

Applications of AI agents include:

1. Virtual assistants (e.g., Siri, Alexa)
2. Customer service chatbots
3. Automated trading systems
4. Game AI opponents
5. Autonomous vehicles
6. Smart home automation systems

AI agents can be classified based on their level of intelligence and autonomy:

- Simple reflex agents
- Model-based reflex agents
- Goal-based agents
- Utility-based agents
- Learning agents

Agent Zero falls into the category of learning agents, as it can adapt and improve its performance over time through interaction and feedback.

## 2. Overview of Agent Zero: capabilities and use cases

Agent Zero is an advanced AI agent framework designed to be dynamic, organic, and highly customizable. Its key features include:

1. General-purpose assistance
2. Computer as a tool approach
3. Multi-agent cooperation
4. Customizability and extensibility
5. Effective communication

### Capabilities:

- Natural language understanding and generation
- Task decomposition and problem-solving
- Code execution and environment interaction
- Memory management and knowledge retrieval
- Multi-agent collaboration
- Web search and information gathering

### Use cases:

1. Personal assistant for developers
2. Automated code generation and debugging
3. Research and information synthesis
4. Task automation and workflow optimization
5. Interactive learning and tutoring
6. Prototyping AI-powered applications

## 3. Setting up Agent Zero: installation and basic configuration

To get started with Agent Zero, follow these steps:

1. Clone the Agent Zero repository:
```bash
git clone https://github.com/frdel/agent-zero.git
cd agent-zero
```

2. Create a virtual environment and activate it:
```bash
python -m venv venv
source venv/bin/activate  # On Windows, use: venv\Scripts\activate
```

3. Install the required dependencies:
```bash
pip install -r requirements.txt
```

4. Create a `.env` file in the project root directory and add your API keys:
```
API_KEY_OPENAI=your_openai_api_key_here
API_KEY_ANTHROPIC=your_anthropic_api_key_here
# Add other API keys as needed
```

5. Configure the `initialize.py` file to set up your preferred models and settings:

```python
def initialize():
    # Main chat model used by agents (smarter, more accurate)
    chat_llm = models.get_openai_chat(model_name="gpt-4", temperature=0)
    
    # Utility model used for helper functions (cheaper, faster)
    utility_llm = models.get_openai_chat(model_name="gpt-3.5-turbo", temperature=0)

    # Embedding model used for memory
    embedding_llm = models.get_openai_embedding(model_name="text-embedding-ada-002")

    # Agent configuration
    config = AgentConfig(
        chat_model = chat_llm,
        utility_model = utility_llm,
        embeddings_model = embedding_llm,
        auto_memory_count = 3,
        rate_limit_requests = 15,
        max_tool_response_length = 3000,
        code_exec_docker_enabled = True,
        code_exec_ssh_enabled = True,
    )

    return config
```

This configuration sets up Agent Zero to use OpenAI's GPT-4 for the main chat model, GPT-3.5-Turbo for utility functions, and the Ada embedding model for memory management.

## 4. Running your first conversation with Agent Zero (using run_cli.py)

To start a conversation with Agent Zero using the command-line interface, run the following command:

```bash
python run_cli.py
```

This will initialize the agent and present you with a prompt to start interacting. Here's an example conversation:

```
User message ('e' to leave):
> Hello, Agent Zero! Can you introduce yourself and explain what you can do?

Agent 0: Response from tool 'response':
Hello! I'm Agent Zero, an advanced AI assistant designed to help with a wide variety of tasks. I'm a general-purpose AI that can assist you with:

1. Information gathering and research
2. Problem-solving and task decomposition
3. Code generation and debugging
4. Data analysis and interpretation
5. Creative writing and brainstorming
6. Task automation and workflow optimization

I have access to various tools that allow me to interact with your computer, search the web, and even execute code in a safe environment. I can also remember important information from our conversations and use it in future interactions.

Is there a specific task or area you'd like assistance with? I'm here to help!

User message ('e' to leave):
> Can you write a simple Python function to calculate the factorial of a number?

Agent 0: Certainly! I'll write a Python function to calculate the factorial of a number using recursion. Here's the implementation:

Agent 0: Using tool 'code_execution_tool':
Runtime: python
Code: 
def factorial(n):
    if n == 0 or n == 1:
        return 1
    else:
        return n * factorial(n - 1)

# Test the function
for i in range(6):
    print(f"Factorial of {i} is: {factorial(i)}")

Agent 0: Response from tool 'code_execution_tool':
Factorial of 0 is: 1
Factorial of 1 is: 1
Factorial of 2 is: 2
Factorial of 3 is: 6
Factorial of 4 is: 24
Factorial of 5 is: 120

Agent 0: Response from tool 'response':
I've written a Python function to calculate the factorial of a number using recursion. Let me explain the code:

1. The `factorial(n)` function takes an integer `n` as input.
2. It has two base cases:
   - If `n` is 0 or 1, it returns 1 (since 0! and 1! are both defined as 1).
3. For any other number, it recursively calls itself with `n-1` and multiplies the result by `n`.

I've also included a test loop that calculates and prints the factorial of numbers from 0 to 5.

The output shows that the function is working correctly:
- 0! = 1
- 1! = 1
- 2! = 2
- 3! = 6
- 4! = 24
- 5! = 120

You can use this function in your Python code by calling `factorial(n)` with any non-negative integer `n`. Keep in mind that for very large numbers, you might run into recursion depth limits or integer overflow issues. For those cases, you might want to consider using an iterative approach or Python's built-in `math.factorial()` function.

Is there anything else you'd like me to explain or modify in this factorial function?

User message ('e' to leave):
> e

```

In this conversation, we've seen Agent Zero introduce itself and demonstrate its ability to write and execute Python code. The agent used the `code_execution_tool` to run the factorial function and display the results.

## Project Layout

To help visualize the structure of the Agent Zero project, here's the basic layout of the main directories and files:

```
agent-zero/
│
├── agent.py
├── example.env
├── initialize.py
├── models.py
├── README.md
├── requirements.txt
├── run_cli.py
├── run_ui.py
│
├── docker/
│   ├── Dockerfile
│   └── ...
│
├── knowledge/
│   └── .gitkeep
│
├── logs/
│   └── .gitkeep
│
├── memory/
│   └── .gitkeep
│
├── prompts/
│   └── default/
│       ├── agent.memory.md
│       ├── agent.system.md
│       ├── agent.tools.md
│       └── ...
│
├── python/
│   ├── helpers/
│   │   ├── docker.py
│   │   ├── errors.py
│   │   ├── files.py
│   │   └── ...
│   │
│   └── tools/
│       ├── call_subordinate.py
│       ├── code_execution_tool.py
│       ├── knowledge_tool.py
│       └── ...
│
├── tests/
│   └── ...
│
├── tmp/
│   └── .gitkeep
│
├── webui/
│   ├── index.css
│   ├── index.html
│   └── index.js
│
└── work_dir/
    └── .gitkeep
```

This layout shows the main components of Agent Zero:

- `agent.py`: Contains the core Agent class implementation
- `initialize.py`: Configuration file for setting up the agent
- `run_cli.py` and `run_ui.py`: Entry points for CLI and web interface
- `prompts/`: Directory containing system prompts and tool instructions
- `python/helpers/`: Utility functions and classes
- `python/tools/`: Implementation of various tools used by the agent
- `webui/`: Files for the web-based user interface

Understanding this structure will be helpful as we dive deeper into Agent Zero's architecture and customization in future lessons.

## Conclusion

In this lesson, we've introduced the concept of AI agents and explored Agent Zero, a powerful and flexible AI agent framework. We've covered its capabilities, use cases, and walked through the process of setting up and running your first conversation with Agent Zero.

As you continue to work with Agent Zero, you'll discover its full potential in solving complex problems, automating tasks, and assisting with a wide range of activities. In the upcoming lessons, we'll delve deeper into Agent Zero's architecture, customization options, and advanced features.

