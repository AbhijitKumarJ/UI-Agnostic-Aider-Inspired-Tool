# Lesson 4: The Agent Zero Web Interface

## Introduction

In this lesson, we'll explore the web-based user interface of Agent Zero. We'll dive into the structure and functionality of `run_ui.py`, examine the web files that make up the interface, and learn about real-time updates and websocket communication. By the end of this lesson, you'll have a comprehensive understanding of how the Agent Zero web interface works and be able to customize it to your needs.

## Project Structure

Before we begin, let's take a look at the relevant files and directories for the web interface:

```
agent-zero/
│
├── run_ui.py
├── webui/
│   ├── index.html
│   ├── index.css
│   └── index.js
├── python/
│   └── helpers/
│       ├── log.py
│       └── print_style.py
└── initialize.py
```

This structure shows the main files we'll be working with in this lesson. The `run_ui.py` file is the entry point for the web interface, while the `webui/` directory contains the frontend files.

## 1. Introduction to run_ui.py

The `run_ui.py` file is the backbone of Agent Zero's web interface. It sets up a Flask server that handles communication between the frontend and the Agent Zero backend.

Let's break down the key components of `run_ui.py`:

```python
import asyncio
from flask import Flask, request, jsonify, Response
from flask_basicauth import BasicAuth
from agent import AgentContext
from initialize import initialize
from python.helpers.log import Log

app = Flask("app", static_folder="./webui", static_url_path="/")
basic_auth = BasicAuth(app)

# ... (other imports and setup code)

@app.route('/', methods=['GET'])
async def test_form():
    return Path(get_abs_path("./webui/index.html")).read_text()

@app.route('/msg', methods=['POST'])
async def handle_message_async():
    return await handle_message(False)

@app.route('/msg_sync', methods=['POST'])
async def handle_msg_sync():
    return await handle_message(True)

# ... (other route handlers)

if __name__ == "__main__":
    load_dotenv()
    port = int(os.environ.get("WEB_UI_PORT", 0)) or None
    app.run(request_handler=NoRequestLoggingWSGIRequestHandler, port=port)
```

This script sets up a Flask server with routes for handling various requests from the frontend. The main routes include:

- `/`: Serves the main HTML page
- `/msg`: Handles asynchronous message sending
- `/msg_sync`: Handles synchronous message sending
- `/poll`: Manages real-time updates

## 2. File Structure: webui/index.html, index.css, index.js

The web interface is built using HTML, CSS, and JavaScript. Let's examine each file:

### 2.1 index.html

The `index.html` file defines the structure of the web interface:

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agent Zero</title>
    <link rel="stylesheet" href="index.css">
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <script type="module" src="index.js"></script>
</head>
<body>
    <div class="container">
        <div id="left-panel" class="panel">
            <!-- Configuration and status sections -->
        </div>
        <div class="splitter" id="splitter"></div>
        <div id="right-panel" class="panel">
            <div id="chat-history"></div>
            <div id="input-section">
                <textarea id="chat-input" placeholder="Type your message here..." rows="1"></textarea>
                <button class="chat-button" id="send-button">&#10148;</button>
                <button class="chat-button pause-button" id="pause-button">&#10074;&#10074;</button>
                <button class="chat-button pause-button" id="unpause-button">&#9654;</button>
            </div>
        </div>
    </div>
</body>
</html>
```

This HTML structure creates a two-panel layout with a chat history, input section, and various configuration options.

### 2.2 index.css

The `index.css` file styles the web interface:

```css
body, html {
    margin: 0;
    padding: 0;
    height: 100%;
    font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
    background-color: #1e1e1e;
    color: #e0e0e0;
}

.container {
    display: flex;
    height: 100%;
}

.panel {
    height: 100%;
    overflow: auto;
}

#left-panel {
    width: 300px;
    background-color: #2d2d2d;
    border-right: 1px solid #444;
    padding: 20px;
    box-sizing: border-box;
}

#right-panel {
    flex-grow: 1;
    display: flex;
    flex-direction: column;
}

/* ... (more CSS rules for various components) */
```

This CSS file defines the layout, colors, and styles for the web interface, creating a dark-themed, modern look.

### 2.3 index.js

The `index.js` file handles the dynamic behavior of the web interface:

```javascript
import * as msgs from "./messages.js"

const chatInput = document.getElementById('chat-input');
const chatHistory = document.getElementById('chat-history');
const sendButton = document.getElementById('send-button');

let context = "";

async function sendMessage() {
    const message = chatInput.value.trim();
    if (message) {
        const response = await sendJsonData("/msg", { text: message, context });
        chatInput.value = '';
        adjustTextareaHeight();
    }
}

async function poll() {
    try {
        const response = await sendJsonData("/poll", { log_from: lastLogVersion, context });
        if (response.ok) {
            setContext(response.context);
            updateChatHistory(response.logs);
            updateUIState(response);
        }
    } catch (error) {
        console.error('Error:', error);
        updateConnectionStatus(false);
    }
}

// ... (other functions for UI interactions and updates)

setInterval(poll, 250);
```

This JavaScript file manages user interactions, sends messages to the server, and handles real-time updates through polling.

## 3. Real-time Updates and Websocket Communication

Agent Zero uses a polling mechanism for real-time updates instead of websockets. The `poll()` function in `index.js` sends requests to the server every 250 milliseconds to check for new messages or state changes:

```javascript
async function poll() {
    try {
        const response = await sendJsonData("/poll", { log_from: lastLogVersion, context });
        if (response.ok) {
            setContext(response.context);
            updateChatHistory(response.logs);
            updateUIState(response);
        }
    } catch (error) {
        console.error('Error:', error);
        updateConnectionStatus(false);
    }
}

setInterval(poll, 250);
```

On the server side, the `/poll` route in `run_ui.py` handles these requests:

```python
@app.route('/poll', methods=['POST'])
async def poll():
    try:
        input = request.get_json()
        ctxid = input.get("context", uuid.uuid4())
        from_no = input.get("log_from", 0)

        context = get_context(ctxid)
        logs = context.log.output(start=from_no)

        response = {
            "ok": True,
            "context": context.id,
            "contexts": get_contexts_info(),
            "logs": logs,
            "log_guid": context.log.guid,
            "log_version": len(context.log.updates),
            "paused": context.paused
        }
    except Exception as e:
        response = {
            "ok": False,
            "message": str(e),
        }

    return jsonify(response)
```

This polling mechanism allows for real-time updates without the need for a persistent websocket connection.

## 4. Hands-on: Customizing the Web Interface

Now that we understand the structure of the Agent Zero web interface, let's customize it by adding a new feature: a word count display for the chat input.

### Step 1: Update index.html

Add a new element to display the word count:

```html
<div id="input-section">
    <textarea id="chat-input" placeholder="Type your message here..." rows="1"></textarea>
    <div id="word-count">Words: 0</div>
    <button class="chat-button" id="send-button">&#10148;</button>
    <!-- ... other buttons ... -->
</div>
```

### Step 2: Update index.css

Style the new word count element:

```css
#word-count {
    font-size: 0.8em;
    color: #888;
    margin-top: 5px;
}
```

### Step 3: Update index.js

Add functionality to update the word count:

```javascript
const chatInput = document.getElementById('chat-input');
const wordCount = document.getElementById('word-count');

function updateWordCount() {
    const words = chatInput.value.trim().split(/\s+/).length;
    wordCount.textContent = `Words: ${words}`;
}

chatInput.addEventListener('input', () => {
    adjustTextareaHeight();
    updateWordCount();
});

// ... (rest of the existing code)
```

With these changes, you've added a new feature to the Agent Zero web interface that displays the word count of the user's input in real-time.

## Conclusion

In this lesson, we've explored the structure and functionality of Agent Zero's web interface. We've examined the `run_ui.py` file, which serves as the backend for the web interface, and the frontend files (`index.html`, `index.css`, and `index.js`) that create the user interface. We've also looked at how real-time updates are handled through polling.

By understanding these components, you can now customize and extend the Agent Zero web interface to suit your specific needs. Whether you want to add new features, change the layout, or modify the communication between the frontend and backend, you have the knowledge to do so.

In the next lesson, we'll dive deeper into the core agent system, exploring the `agent.py` file and how it manages conversations and agent contexts.
