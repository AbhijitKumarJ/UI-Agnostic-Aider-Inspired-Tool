# Lesson 11: Error Handling and System Resilience

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Error Handling in Agent Zero](#error-handling-in-agent-zero)
   3.1. [The errors.py Module](#the-errorspy-module)
   3.2. [Handling Errors in the Agent Class](#handling-errors-in-the-agent-class)
4. [Implementing Robust Conversation Loops](#implementing-robust-conversation-loops)
5. [Strategies for Handling AI Model Failures](#strategies-for-handling-ai-model-failures)
6. [Hands-on: Enhancing System Stability](#hands-on-enhancing-system-stability)
7. [Conclusion](#conclusion)

## 1. Introduction

In this lesson, we'll dive deep into error handling and system resilience in the Agent Zero framework. Robust error handling is crucial for building reliable AI systems that can gracefully handle unexpected situations, recover from failures, and provide a smooth user experience. We'll explore various techniques to make your Agent Zero applications more stable and resilient.

## 2. Project Structure

Before we delve into the details, let's review the relevant parts of the Agent Zero project structure that we'll be working with in this lesson:

```
agent-zero/
│
├── agent.py
├── initialize.py
│
├── prompts/
│   └── default/
│       ├── fw.error.md
│       └── fw.code_runtime_wrong.md
│
└── python/
    ├── helpers/
    │   ├── errors.py
    │   ├── print_style.py
    │   └── log.py
    │
    └── tools/
        └── code_execution_tool.py
```

This structure highlights the key files we'll be examining and modifying in this lesson. The `agent.py` file contains the core `Agent` class, `errors.py` handles error formatting and management, and various prompt files in the `prompts/` directory are used for error messaging.

## 3. Error Handling in Agent Zero

### 3.1. The errors.py Module

The `errors.py` module in Agent Zero provides utility functions for handling and formatting errors. Let's examine its contents:

```python
import re
import traceback
import asyncio

def handle_error(e: Exception):
    # if asyncio.CancelledError, re-raise
    if isinstance(e, asyncio.CancelledError):
        raise e
    
def format_error(e: Exception, max_entries=2):
    traceback_text = traceback.format_exc()
    # Split the traceback into lines
    lines = traceback_text.split('\n')
    
    # Find all "File" lines
    file_indices = [i for i, line in enumerate(lines) if line.strip().startswith("File ")]
    
    # If we found at least one "File" line, keep up to max_entries
    if file_indices:
        start_index = max(0, len(file_indices) - max_entries)
        trimmed_lines = lines[file_indices[start_index]:]
    else:
        # If no "File" lines found, just return the original traceback
        return traceback_text
    
    # Find the error message at the end
    error_message = ""
    for line in reversed(trimmed_lines):
        if re.match(r'\w+Error:', line):
            error_message = line
            break
    
    # Combine the trimmed traceback with the error message
    result = "Traceback (most recent call last):\n" + '\n'.join(trimmed_lines)
    if error_message:
        result += f"\n\n{error_message}"
    
    return result
```

Key points to understand:

1. The `handle_error` function is designed to re-raise `asyncio.CancelledError`, which is important for proper asyncio operation.
2. The `format_error` function trims the traceback to a specified number of entries (default 2) to keep error messages concise yet informative.
3. It extracts the most relevant parts of the traceback, focusing on the file lines and the final error message.

### 3.2. Handling Errors in the Agent Class

Now, let's look at how errors are handled in the `Agent` class. Open the `agent.py` file and locate the `message_loop` method:

```python
async def message_loop(self, msg: str):
    try:
        # ... (existing code)

        while True:
            try:
                # ... (message processing code)

            except InterventionException as e:
                pass  # intervention message has been handled in handle_intervention(), proceed with conversation loop
            except asyncio.CancelledError as e:
                PrintStyle(
                    font_color="white", background_color="red", padding=True
                ).print(f"Context {self.context.id} terminated during message loop")
                raise e  # process cancelled from outside, kill the loop
            except RepairableException as e:  # Forward repairable errors to the LLM, maybe it can fix them
                error_message = errors.format_error(e)
                msg_response = self.read_prompt(
                    "fw.error.md", error=error_message
                )  # error message template
                await self.append_message(msg_response, human=True)
                PrintStyle(font_color="red", padding=True).print(msg_response)
                self.context.log.log(type="error", content=msg_response)
            except Exception as e:  # Other exception kill the loop
                error_message = errors.format_error(e)
                PrintStyle(font_color="red", padding=True).print(error_message)
                self.context.log.log(type="error", content=error_message)
                raise e  # kill the loop

    finally:
        self.context.streaming_agent = None  # unset current streamer
```

This error handling structure provides several key benefits:

1. It distinguishes between different types of errors (InterventionException, CancelledError, RepairableException, and general Exceptions).
2. It allows for graceful handling of user interventions and cancellations.
3. It attempts to repair certain errors by forwarding them to the language model.
4. It logs all errors for debugging and monitoring purposes.

## 4. Implementing Robust Conversation Loops

To make conversation loops more robust, we can implement additional error recovery mechanisms. Here's an enhanced version of the `message_loop` method:

```python
async def message_loop(self, msg: str):
    max_retries = 3
    retry_count = 0

    while retry_count < max_retries:
        try:
            # ... (existing code)

            while True:
                try:
                    # ... (message processing code)

                except InterventionException as e:
                    pass  # intervention message has been handled in handle_intervention(), proceed with conversation loop
                except asyncio.CancelledError as e:
                    PrintStyle(
                        font_color="white", background_color="red", padding=True
                    ).print(f"Context {self.context.id} terminated during message loop")
                    raise e  # process cancelled from outside, kill the loop
                except RepairableException as e:
                    error_message = errors.format_error(e)
                    msg_response = self.read_prompt(
                        "fw.error.md", error=error_message
                    )  # error message template
                    await self.append_message(msg_response, human=True)
                    PrintStyle(font_color="red", padding=True).print(msg_response)
                    self.context.log.log(type="error", content=msg_response)
                except Exception as e:
                    error_message = errors.format_error(e)
                    PrintStyle(font_color="red", padding=True).print(error_message)
                    self.context.log.log(type="error", content=error_message)
                    raise e  # propagate the exception to outer try-except block

        except Exception as e:
            retry_count += 1
            if retry_count >= max_retries:
                PrintStyle(font_color="red", padding=True).print(f"Max retries reached. Terminating conversation loop.")
                self.context.log.log(type="error", content=f"Max retries reached. Terminating conversation loop.")
                raise e
            else:
                PrintStyle(font_color="yellow", padding=True).print(f"Error occurred. Retrying conversation loop (Attempt {retry_count}/{max_retries})...")
                self.context.log.log(type="warning", content=f"Error occurred. Retrying conversation loop (Attempt {retry_count}/{max_retries})...")
                await asyncio.sleep(1)  # Wait for a second before retrying

    self.context.streaming_agent = None  # unset current streamer
```

This implementation adds a retry mechanism for the entire conversation loop, allowing the system to recover from unexpected errors and continue operation.

## 5. Strategies for Handling AI Model Failures

AI model failures can occur due to various reasons such as network issues, rate limiting, or unexpected model responses. Here are some strategies to handle these failures:

1. **Implement exponential backoff**: When encountering rate limit errors or temporary network issues, use an exponential backoff strategy to retry the request.

2. **Use fallback models**: If a primary model fails, have a backup model ready to take over.

3. **Implement model response validation**: Check if the model's response adheres to expected formats and constraints.

4. **Handle timeout errors**: Set appropriate timeouts for model calls and handle timeout exceptions gracefully.

Let's implement these strategies in a new `ai_model_handler.py` file:

```python
import asyncio
import random
from tenacity import retry, stop_after_attempt, wait_exponential

class AIModelHandler:
    def __init__(self, primary_model, fallback_model, timeout=30):
        self.primary_model = primary_model
        self.fallback_model = fallback_model
        self.timeout = timeout

    @retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=4, max=10))
    async def call_model_with_retry(self, model, *args, **kwargs):
        try:
            return await asyncio.wait_for(model(*args, **kwargs), timeout=self.timeout)
        except asyncio.TimeoutError:
            raise Exception("Model call timed out")

    async def call_model(self, *args, **kwargs):
        try:
            return await self.call_model_with_retry(self.primary_model, *args, **kwargs)
        except Exception as e:
            print(f"Primary model failed: {str(e)}. Trying fallback model.")
            return await self.call_model_with_retry(self.fallback_model, *args, **kwargs)

    def validate_response(self, response):
        # Implement your validation logic here
        # For example, check if the response is a valid JSON, has expected fields, etc.
        pass
```

To use this handler, you would initialize it with your primary and fallback models, and then use it in your agent's code:

```python
from ai_model_handler import AIModelHandler

# In your initialize.py or agent setup
primary_model = models.get_openai_chat(model_name="gpt-4", temperature=0)
fallback_model = models.get_openai_chat(model_name="gpt-3.5-turbo", temperature=0)
ai_handler = AIModelHandler(primary_model, fallback_model)

# In your agent's code
response = await ai_handler.call_model(prompt, max_tokens=100)
if ai_handler.validate_response(response):
    # Process the response
else:
    # Handle invalid response
```

## 6. Hands-on: Enhancing System Stability

Let's put our knowledge into practice by enhancing the stability of the code execution tool. We'll modify the `code_execution_tool.py` file to include better error handling and recovery mechanisms:

```python
import asyncio
from python.helpers.tool import Tool, Response
from python.helpers.print_style import PrintStyle
from python.helpers.errors import format_error

class CodeExecution(Tool):

    async def execute(self, **kwargs):
        max_retries = 3
        retry_count = 0

        while retry_count < max_retries:
            try:
                await self.prepare_state()

                runtime = self.args["runtime"].lower().strip()
                if runtime == "python":
                    response = await self.execute_python_code(self.args["code"])
                elif runtime == "nodejs":
                    response = await self.execute_nodejs_code(self.args["code"])
                elif runtime == "terminal":
                    response = await self.execute_terminal_command(self.args["code"])
                elif runtime == "output":
                    response = await self.get_terminal_output(wait_with_output=5, wait_without_output=20)
                elif runtime == "reset":
                    response = await self.reset_terminal()
                else:
                    response = self.agent.read_prompt("fw.code_runtime_wrong.md", runtime=runtime)

                if not response:
                    response = self.agent.read_prompt("fw.code_no_output.md")

                return Response(message=response, break_loop=False)

            except asyncio.TimeoutError:
                retry_count += 1
                if retry_count >= max_retries:
                    return Response(message="Code execution timed out after multiple attempts", break_loop=False)
                PrintStyle(font_color="yellow", padding=True).print(f"Code execution timed out. Retrying (Attempt {retry_count}/{max_retries})...")
                await asyncio.sleep(2)  # Wait before retrying

            except Exception as e:
                error_message = format_error(e)
                PrintStyle(font_color="red", padding=True).print(f"Error during code execution: {error_message}")
                return Response(message=f"Error during code execution: {error_message}", break_loop=False)

    async def execute_python_code(self, code):
        try:
            # Execute Python code
            # ... (existing code)
        except Exception as e:
            return f"Error executing Python code: {str(e)}"

    # Similar error handling for execute_nodejs_code and execute_terminal_command
```

This enhanced version of the code execution tool includes:

1. A retry mechanism for handling timeouts.
2. Proper error catching and formatting for all code execution methods.
3. Informative error messages returned to the agent for further processing.

## 7. Conclusion

In this lesson, we've explored various aspects of error handling and system resilience in Agent Zero. We've covered:

1. The error handling infrastructure in `errors.py`
2. Implementing robust conversation loops with retry mechanisms
3. Strategies for handling AI model failures, including exponential backoff and fallback models
4. Enhancing the stability of specific tools, such as the code execution tool

By implementing these techniques, you can significantly improve the reliability and user experience of your Agent Zero applications. Remember that error handling is an ongoing process, and you should continuously monitor and refine your error handling strategies based on real-world usage and feedback.

As you continue to develop with Agent Zero, consider implementing additional error handling techniques such as:

1. Comprehensive logging and monitoring solutions
2. User-friendly error messages and recovery suggestions
3. Automated error reporting and analysis tools
4. Periodic health checks and self-healing mechanisms

By prioritizing error handling and system resilience, you'll be able to build robust, production-ready AI systems that can handle a wide range of scenarios and provide a smooth experience for your users.

