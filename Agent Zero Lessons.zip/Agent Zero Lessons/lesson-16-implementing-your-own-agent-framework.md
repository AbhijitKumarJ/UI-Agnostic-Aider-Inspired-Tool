# Lesson 16: Implementing Your Own Agent Framework

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Designing the Core Architecture](#designing-the-core-architecture)
   - [3.1 The Agent Class](#31-the-agent-class)
   - [3.2 The Context Class](#32-the-context-class)
   - [3.3 The Config Class](#33-the-config-class)
4. [Building a Modular Tool System](#building-a-modular-tool-system)
   - [4.1 The Base Tool Class](#41-the-base-tool-class)
   - [4.2 Implementing Specific Tools](#42-implementing-specific-tools)
5. [Implementing a Flexible Prompt Management System](#implementing-a-flexible-prompt-management-system)
6. [Putting It All Together](#putting-it-all-together)
7. [Hands-on: Creating a Minimalist Agent Framework](#hands-on-creating-a-minimalist-agent-framework)
8. [Conclusion](#conclusion)

## 1. Introduction

In this lesson, we'll dive deep into creating your own agent framework. By the end of this tutorial, you'll have a solid understanding of how to design and implement a flexible, modular AI agent system. We'll cover the core architecture, a tool system, and a prompt management system, all while keeping our code clean, extensible, and easy to understand.

## 2. Project Structure

Before we begin coding, let's outline our project structure. This will help us visualize how different components of our framework will interact.

```
minimalist_agent_framework/
├── agent/
│   ├── __init__.py
│   ├── agent.py
│   ├── context.py
│   └── config.py
├── tools/
│   ├── __init__.py
│   ├── base_tool.py
│   ├── response_tool.py
│   └── search_tool.py
├── prompts/
│   ├── system_prompt.txt
│   └── user_prompt.txt
├── utils/
│   ├── __init__.py
│   └── prompt_manager.py
├── main.py
└── requirements.txt
```

This structure separates our concerns nicely: the core agent logic, the tools, the prompts, and utility functions are all in their respective directories.

## 3. Designing the Core Architecture

The core of our agent framework will consist of three main classes: Agent, Context, and Config. Let's implement each of these.

### 3.1 The Agent Class

The Agent class will be responsible for managing the conversation flow and decision-making process. Here's a basic implementation:

```python
# agent/agent.py

import json
from typing import List, Dict, Any
from .context import Context
from .config import Config

class Agent:
    def __init__(self, config: Config):
        self.config = config
        self.context = Context()

    async def process_message(self, message: str) -> str:
        # Add user message to context
        self.context.add_message("user", message)

        # Generate AI response
        response = await self.generate_response()

        # Add AI response to context
        self.context.add_message("ai", response)

        return response

    async def generate_response(self) -> str:
        # Implement your AI model call here
        # For now, we'll use a dummy response
        return "This is a dummy AI response."

    def get_context(self) -> List[Dict[str, Any]]:
        return self.context.get_messages()

    def to_json(self) -> str:
        return json.dumps({
            "config": self.config.to_dict(),
            "context": self.get_context()
        })

    @classmethod
    def from_json(cls, json_str: str) -> 'Agent':
        data = json.loads(json_str)
        agent = cls(Config.from_dict(data['config']))
        agent.context = Context.from_list(data['context'])
        return agent
```

### 3.2 The Context Class

The Context class will manage the conversation history:

```python
# agent/context.py

from typing import List, Dict, Any

class Context:
    def __init__(self):
        self.messages: List[Dict[str, Any]] = []

    def add_message(self, role: str, content: str):
        self.messages.append({"role": role, "content": content})

    def get_messages(self) -> List[Dict[str, Any]]:
        return self.messages

    @classmethod
    def from_list(cls, messages: List[Dict[str, Any]]) -> 'Context':
        context = cls()
        context.messages = messages
        return context
```

### 3.3 The Config Class

The Config class will hold all configuration parameters for our agent:

```python
# agent/config.py

from typing import Dict, Any

class Config:
    def __init__(self, model: str, max_tokens: int, temperature: float):
        self.model = model
        self.max_tokens = max_tokens
        self.temperature = temperature

    def to_dict(self) -> Dict[str, Any]:
        return {
            "model": self.model,
            "max_tokens": self.max_tokens,
            "temperature": self.temperature
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Config':
        return cls(
            model=data['model'],
            max_tokens=data['max_tokens'],
            temperature=data['temperature']
        )
```

## 4. Building a Modular Tool System

A modular tool system allows us to easily add, remove, or modify agent capabilities. Let's create a base Tool class and then implement some specific tools.

### 4.1 The Base Tool Class

```python
# tools/base_tool.py

from abc import ABC, abstractmethod
from typing import Any, Dict

class BaseTool(ABC):
    def __init__(self, name: str):
        self.name = name

    @abstractmethod
    async def execute(self, **kwargs: Any) -> Dict[str, Any]:
        pass
```

### 4.2 Implementing Specific Tools

Let's implement two simple tools: a response tool and a search tool.

Response Tool:

```python
# tools/response_tool.py

from .base_tool import BaseTool
from typing import Dict, Any

class ResponseTool(BaseTool):
    def __init__(self):
        super().__init__("response")

    async def execute(self, text: str, **kwargs: Any) -> Dict[str, Any]:
        return {"response": text}
```

Search Tool (simulated):

```python
# tools/search_tool.py

from .base_tool import BaseTool
from typing import Dict, Any

class SearchTool(BaseTool):
    def __init__(self):
        super().__init__("search")

    async def execute(self, query: str, **kwargs: Any) -> Dict[str, Any]:
        # Simulate a search operation
        return {"results": f"Simulated search results for: {query}"}
```

## 5. Implementing a Flexible Prompt Management System

A flexible prompt management system allows us to easily update and manage various prompts used by our agent. Let's create a simple PromptManager:

```python
# utils/prompt_manager.py

import os
from typing import Dict

class PromptManager:
    def __init__(self, prompts_dir: str):
        self.prompts_dir = prompts_dir
        self.prompts: Dict[str, str] = {}
        self._load_prompts()

    def _load_prompts(self):
        for filename in os.listdir(self.prompts_dir):
            if filename.endswith(".txt"):
                prompt_name = os.path.splitext(filename)[0]
                with open(os.path.join(self.prompts_dir, filename), "r") as f:
                    self.prompts[prompt_name] = f.read().strip()

    def get_prompt(self, prompt_name: str) -> str:
        return self.prompts.get(prompt_name, "")

    def update_prompt(self, prompt_name: str, new_content: str):
        self.prompts[prompt_name] = new_content
        with open(os.path.join(self.prompts_dir, f"{prompt_name}.txt"), "w") as f:
            f.write(new_content)
```

## 6. Putting It All Together

Now that we have our core components, let's update our Agent class to use the tool system and prompt manager:

```python
# agent/agent.py

import json
from typing import List, Dict, Any
from .context import Context
from .config import Config
from utils.prompt_manager import PromptManager
from tools.base_tool import BaseTool

class Agent:
    def __init__(self, config: Config, prompt_manager: PromptManager, tools: List[BaseTool]):
        self.config = config
        self.context = Context()
        self.prompt_manager = prompt_manager
        self.tools = {tool.name: tool for tool in tools}

    async def process_message(self, message: str) -> str:
        self.context.add_message("user", message)
        response = await self.generate_response()
        self.context.add_message("ai", response)
        return response

    async def generate_response(self) -> str:
        system_prompt = self.prompt_manager.get_prompt("system_prompt")
        user_prompt = self.prompt_manager.get_prompt("user_prompt")
        
        # Here, you would typically call your AI model with the prompts and context
        # For this example, we'll use a dummy response
        ai_response = f"Dummy AI response based on:\nSystem: {system_prompt}\nUser: {user_prompt}"
        
        # Parse the AI response to extract tool calls
        tool_calls = self._parse_tool_calls(ai_response)
        
        # Execute tool calls
        for tool_call in tool_calls:
            tool_name = tool_call['name']
            tool_args = tool_call['arguments']
            if tool_name in self.tools:
                tool_result = await self.tools[tool_name].execute(**tool_args)
                ai_response += f"\nTool '{tool_name}' result: {json.dumps(tool_result)}"
        
        return ai_response

    def _parse_tool_calls(self, ai_response: str) -> List[Dict[str, Any]]:
        # In a real implementation, you would parse the AI response to extract tool calls
        # For this example, we'll return a dummy tool call
        return [{"name": "search", "arguments": {"query": "example search"}}]

    # ... (rest of the methods remain the same)
```

## 7. Hands-on: Creating a Minimalist Agent Framework

Now that we have all the components, let's create a minimalist agent framework in our `main.py` file:

```python
# main.py

import asyncio
from agent.agent import Agent
from agent.config import Config
from utils.prompt_manager import PromptManager
from tools.response_tool import ResponseTool
from tools.search_tool import SearchTool

async def main():
    # Initialize configuration
    config = Config(model="gpt-3.5-turbo", max_tokens=150, temperature=0.7)

    # Initialize prompt manager
    prompt_manager = PromptManager("prompts")

    # Initialize tools
    tools = [ResponseTool(), SearchTool()]

    # Create agent
    agent = Agent(config, prompt_manager, tools)

    # Simulate a conversation
    user_messages = [
        "Hello, who are you?",
        "Can you search for information about Python?",
        "Thank you, goodbye!"
    ]

    for message in user_messages:
        print(f"User: {message}")
        response = await agent.process_message(message)
        print(f"AI: {response}\n")

    # Demonstrate serialization and deserialization
    serialized_agent = agent.to_json()
    print("Serialized agent:", serialized_agent)

    new_agent = Agent.from_json(serialized_agent)
    print("Deserialized agent context:", new_agent.get_context())

if __name__ == "__main__":
    asyncio.run(main())
```

To run this minimalist agent framework, make sure you have the following files in your `prompts` directory:

`prompts/system_prompt.txt`:
```
You are a helpful AI assistant. Your role is to assist users with their questions and tasks.
```

`prompts/user_prompt.txt`:
```
Please provide a helpful and informative response to the user's message.
```

## 8. Conclusion

In this lesson, we've created a minimalist agent framework that demonstrates the key components of an AI agent system:

1. A core Agent class that manages the conversation flow and decision-making process.
2. A Context class for maintaining conversation history.
3. A Config class for managing agent parameters.
4. A modular Tool system for extending agent capabilities.
5. A PromptManager for flexible prompt management.

This framework provides a solid foundation that you can build upon to create more complex and capable AI agents. Some areas for further development include:

- Implementing a real AI model integration (e.g., with OpenAI's GPT or other language models).
- Expanding the tool system with more sophisticated tools.
- Enhancing the prompt management system to support dynamic prompt generation.
- Implementing better parsing of AI responses to extract tool calls and other structured data.
- Adding support for long-term memory and learning capabilities.

By understanding and implementing these core concepts, you're well on your way to creating advanced AI agent systems tailored to your specific needs.
