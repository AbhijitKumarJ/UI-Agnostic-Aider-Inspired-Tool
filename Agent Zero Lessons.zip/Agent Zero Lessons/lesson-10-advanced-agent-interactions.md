# Lesson 10: Advanced Agent Interactions: Multi-Agent Systems

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Understanding the call_subordinate Tool](#understanding-the-call_subordinate-tool)
4. [Implementing Agent Hierarchies and Cooperation](#implementing-agent-hierarchies-and-cooperation)
5. [Strategies for Task Decomposition and Delegation](#strategies-for-task-decomposition-and-delegation)
6. [Hands-on: Building a Multi-Agent System](#hands-on-building-a-multi-agent-system)
7. [Conclusion](#conclusion)

## 1. Introduction

In this lesson, we'll explore advanced agent interactions in the Agent Zero framework, focusing on multi-agent systems. We'll learn how to create hierarchies of agents, implement cooperation between them, and effectively decompose and delegate tasks. This knowledge will enable you to build more complex and efficient AI systems capable of handling intricate, multi-step problems.

## 2. Project Structure

Before we dive into the details, let's review the relevant parts of the Agent Zero project structure:

```
agent-zero/
│
├── agent.py
├── initialize.py
│
├── prompts/
│   └── default/
│       ├── agent.system.md
│       └── agent.tools.md
│
└── python/
    ├── helpers/
    │   └── tool.py
    │
    └── tools/
        └── call_subordinate.py
```

This structure highlights the key files we'll be working with in this lesson. The `agent.py` file contains the core `Agent` class, `initialize.py` is used for configuration, the `prompts/` directory contains system prompts, and the `python/tools/` directory houses our tools, including the `call_subordinate.py` tool we'll be focusing on.

## 3. Understanding the call_subordinate Tool

The `call_subordinate` tool is the cornerstone of multi-agent interactions in Agent Zero. It allows an agent to create and communicate with subordinate agents, effectively building a hierarchy of agents that can work together to solve complex problems.

Let's examine the `call_subordinate.py` file:

```python
from agent import Agent
from python.helpers.tool import Tool, Response

class Delegation(Tool):

    async def execute(self, message="", reset="", **kwargs):
        # create subordinate agent using the data object on this agent and set superior agent to his data object
        if self.agent.get_data("subordinate") is None or str(reset).lower().strip() == "true":
            subordinate = Agent(self.agent.number+1, self.agent.config, self.agent.context)
            subordinate.set_data("superior", self.agent)
            self.agent.set_data("subordinate", subordinate) 
        # run subordinate agent message loop
        return Response(message=await self.agent.get_data("subordinate").message_loop(message), break_loop=False)
```

Key points to understand:

1. The tool creates a new `Agent` instance with an incremented number when called for the first time or when reset is requested.
2. The new agent is stored in the current agent's data as "subordinate", and the current agent is set as the "superior" of the new agent.
3. The tool runs the subordinate agent's message loop with the provided message and returns the response.

## 4. Implementing Agent Hierarchies and Cooperation

To implement agent hierarchies and cooperation, we need to modify the system prompt in `prompts/default/agent.system.md` to include instructions for multi-agent behavior. Here's an example of how we might update this file:

```markdown
# Your role
- Your name is {{agent_name}}
- You are an autonomous JSON AI task solving agent enhanced with knowledge and execution tools
- You are given tasks by your superior and you solve them using your subordinates and tools
- You never just talk about solutions, never inform users about intentions, you are the one to execute actions using your tools and get things done

# Communication
- Your response is a JSON containing the following fields:
    1. thoughts: Array of thoughts regarding the current task
    2. tool_name: Name of the tool to be used
    3. tool_args: Object of arguments that are passed to the tool

# Cooperation and delegation
- If a subtask requires a different role or expertise, use the call_subordinate tool to create a subordinate agent
- Instruct your subordinate about their role and task in detail
- Communicate back and forth with your subordinate and superior using call_subordinate and response tools
- NEVER delegate your whole task, only parts of it
```

This prompt instructs the agent on how to use subordinates and when to delegate tasks, promoting cooperation between agents.

## 5. Strategies for Task Decomposition and Delegation

Effective multi-agent systems rely on smart task decomposition and delegation. Here are some strategies to implement in your system:

1. **Expertise-based delegation**: Assign tasks to subordinates based on their specific roles or expertise.
2. **Divide and conquer**: Break complex tasks into smaller, manageable subtasks that can be handled by different agents.
3. **Parallel processing**: Delegate independent subtasks to multiple subordinates to be processed simultaneously.
4. **Hierarchical problem-solving**: Use a tree-like structure where each level of agents handles a different level of abstraction in the problem.

To implement these strategies, we need to update the `agent.tools.md` file to include more detailed instructions on when and how to use the `call_subordinate` tool:

```markdown
### call_subordinate:
Use subordinate agents to solve subtasks.
Use "message" argument to send message. Instruct your subordinate about the role they will play (scientist, coder, writer...) and their task in detail.
Use "reset" argument with "true" to start with a new subordinate or "false" to continue with existing. For brand new tasks use "true", for followup conversation use "false". 
Explain to your subordinate what is the higher level goal and what is their part.
Give them detailed instructions as well as a good overview to understand what to do.

**When to use**:
1. The subtask requires a different area of expertise
2. The problem can be broken down into independent parts
3. Parallel processing of subtasks would be beneficial
4. A different level of abstraction is needed for part of the problem

**Example usage**:
~~~json
{
    "thoughts": [
        "This task involves both data analysis and report writing.",
        "I'll delegate the data analysis to a subordinate with statistical expertise.",
    ],
    "tool_name": "call_subordinate",
    "tool_args": {
        "message": "You are a data analyst. Your task is to analyze the following dataset and provide key insights: [dataset details]. Focus on trends, correlations, and anomalies.",
        "reset": "true"
    }
}
~~~
```

## 6. Hands-on: Building a Multi-Agent System

Now, let's build a multi-agent system to solve a complex task. We'll create a system to analyze a company's financial data, generate visualizations, and write a report.

First, update the `initialize.py` file to ensure we have the necessary configuration:

```python
def initialize():
    config = AgentConfig(
        chat_model = models.get_openai_chat(model_name="gpt-4", temperature=0),
        utility_model = models.get_openai_chat(model_name="gpt-3.5-turbo", temperature=0),
        embeddings_model = models.get_openai_embedding(model_name="text-embedding-ada-002"),
        auto_memory_count = 3,
        code_exec_docker_enabled = True,
        additional = {
            "company_name": "TechCorp Inc.",
            "financial_data_file": "financial_data_2023.csv"
        }
    )
    return config
```

Now, let's run a multi-agent analysis using `run_cli.py`:

```python
import asyncio
from agent import AgentContext
from initialize import initialize

async def main():
    config = initialize()
    context = AgentContext(config)
    
    task = """Analyze TechCorp Inc.'s financial data for 2023. 
    1. Perform a detailed financial analysis
    2. Create visualizations of key metrics
    3. Write a comprehensive report of the findings
    Use multiple agents to complete this task efficiently."""

    result = await context.communicate(task)
    print(result)

asyncio.run(main())
```

When you run this script, you'll see the main agent delegating tasks to subordinates, each specializing in a different aspect of the analysis. The agents will work together, sharing information and combining their outputs to produce a comprehensive financial analysis report.

## 7. Conclusion

In this lesson, we've explored advanced agent interactions and multi-agent systems in Agent Zero. We've learned how to use the `call_subordinate` tool, implement agent hierarchies, and apply strategies for task decomposition and delegation. By leveraging these techniques, you can build sophisticated AI systems capable of handling complex, multi-faceted problems.

Remember, the key to effective multi-agent systems lies in:
1. Clear communication between agents
2. Smart task decomposition
3. Appropriate delegation based on expertise
4. Effective coordination and information sharing

As you continue to work with Agent Zero, experiment with different hierarchies and delegation strategies to find what works best for your specific use cases. The flexibility of this system allows for a wide range of applications, from data analysis and report generation to complex problem-solving and decision-making tasks.

