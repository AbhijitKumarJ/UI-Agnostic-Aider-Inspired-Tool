# Lesson 7: Memory and Knowledge Management in AI Agents

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Vector Databases for Long-term Memory](#vector-databases-for-long-term-memory)
   3.1. [Understanding Vector Databases](#understanding-vector-databases)
   3.2. [The VectorDB Class](#the-vectordb-class)
4. [Knowledge Import System](#knowledge-import-system)
   4.1. [The KnowledgeImport Class](#the-knowledgeimport-class)
   4.2. [Importing Different File Types](#importing-different-file-types)
5. [Using the Memory Tool](#using-the-memory-tool)
   5.1. [Memory Tool Implementation](#memory-tool-implementation)
   5.2. [Interacting with Memory](#interacting-with-memory)
6. [Hands-on: Implementing a Custom Memory System](#hands-on-implementing-a-custom-memory-system)
7. [Conclusion](#conclusion)

## 1. Introduction

In this lesson, we'll explore memory and knowledge management in AI agents, focusing on Agent Zero's implementation. Effective memory and knowledge management are crucial for creating intelligent agents that can learn from past interactions and apply accumulated knowledge to new situations. We'll cover vector databases for long-term memory, the knowledge import system, and how to use and extend the memory tool.

## 2. Project Structure

Before we dive in, let's review the relevant parts of the Agent Zero project structure:

```
agent-zero/
│
├── agent.py
├── python/
│   ├── helpers/
│   │   ├── vector_db.py
│   │   └── knowledge_import.py
│   └── tools/
│       └── memory_tool.py
├── memory/
│   ├── database/
│   └── embeddings/
└── knowledge/
    └── ... (knowledge files)
```

This structure highlights the key components we'll be focusing on in this lesson.

## 3. Vector Databases for Long-term Memory

### 3.1. Understanding Vector Databases

Vector databases are specialized databases designed to store and efficiently query high-dimensional vectors. In the context of AI agents, these vectors typically represent embeddings of text or other data. The key advantage of vector databases is their ability to perform similarity searches, which is crucial for implementing semantic memory in AI agents.

### 3.2. The VectorDB Class

Agent Zero uses a custom `VectorDB` class to manage its vector database. Let's examine the key parts of this class:

```python
# python/helpers/vector_db.py

from langchain.storage import InMemoryByteStore, LocalFileStore
from langchain.embeddings import CacheBackedEmbeddings
from langchain_community.vectorstores import FAISS
import faiss
from langchain_community.docstore.in_memory import InMemoryDocstore
import os, json
from . import files
from langchain_core.documents import Document
import uuid
from python.helpers import knowledge_import
from python.helpers.log import Log

class VectorDB:
    def __init__(self, logger: Log, embeddings_model, in_memory=False, memory_dir="./memory", knowledge_dir="./knowledge"):
        self.logger = logger
        self.embeddings_model = embeddings_model
        self.em_dir = files.get_abs_path(memory_dir, "embeddings")
        self.db_dir = files.get_abs_path(memory_dir, "database")
        self.kn_dir = files.get_abs_path(knowledge_dir) if knowledge_dir else ""
        
        # Initialize storage and embeddings
        self.store = InMemoryByteStore() if in_memory else LocalFileStore(self.em_dir)
        self.embedder = CacheBackedEmbeddings.from_bytes_store(
            embeddings_model, 
            self.store, 
            namespace=getattr(embeddings_model, 'model', getattr(embeddings_model, 'model_name', "default"))
        )
        
        # Initialize or load FAISS index
        if os.path.exists(self.db_dir) and files.exists(self.db_dir, "index.faiss"):
            self.db = FAISS.load_local(
                folder_path=self.db_dir,
                embeddings=self.embedder,
                allow_dangerous_deserialization=True
            )
        else:
            index = faiss.IndexFlatL2(len(self.embedder.embed_query("example text")))
            self.db = FAISS(
                embedding_function=self.embedder,
                index=index,
                docstore=InMemoryDocstore(),
                index_to_docstore_id={}
            )
        
        # Preload knowledge files
        if self.kn_dir:
            self.preload_knowledge(self.kn_dir, self.db_dir)

    # ... (other methods)
```

Key points about the `VectorDB` class:

- It uses FAISS (Facebook AI Similarity Search) as the underlying vector database.
- Embeddings are cached using `CacheBackedEmbeddings` for efficiency.
- The class supports both in-memory and on-disk storage.
- It automatically loads existing indexes or creates new ones as needed.
- Knowledge files are preloaded during initialization.

## 4. Knowledge Import System

### 4.1. The KnowledgeImport Class

The knowledge import system in Agent Zero is responsible for loading various types of files into the agent's knowledge base. Let's examine the `KnowledgeImport` class:

```python
# python/helpers/knowledge_import.py

import glob
import os
import hashlib
import json
from typing import Any, Dict, Literal, TypedDict
from langchain_community.document_loaders import (
    CSVLoader, JSONLoader, PyPDFLoader, TextLoader, UnstructuredHTMLLoader, 
    UnstructuredMarkdownLoader
)
from python.helpers import files
from python.helpers.log import Log

class KnowledgeImport(TypedDict):
    file: str
    checksum: str
    ids: list[str]
    state: Literal["changed", "original", "removed"]
    documents: list[Any]

def load_knowledge(logger: Log, knowledge_dir: str, index: Dict[str, KnowledgeImport]) -> Dict[str, KnowledgeImport]:
    knowledge_dir = files.get_abs_path(knowledge_dir)
    
    file_types_loaders = {
        'txt': TextLoader,
        'pdf': PyPDFLoader,
        'csv': CSVLoader,
        'html': UnstructuredHTMLLoader,
        'json': JSONLoader,
        'md': UnstructuredMarkdownLoader
    }

    # ... (implementation details)

    return index
```

### 4.2. Importing Different File Types

The `load_knowledge` function supports various file types, including:

- Text files (.txt)
- PDF documents (.pdf)
- CSV files (.csv)
- HTML files (.html)
- JSON files (.json)
- Markdown files (.md)

For each file type, an appropriate loader is used to extract the content and convert it into a format suitable for the vector database.

## 5. Using the Memory Tool

### 5.1. Memory Tool Implementation

The Memory Tool in Agent Zero provides an interface for the agent to interact with its long-term memory. Let's examine its implementation:

```python
# python/tools/memory_tool.py

from agent import Agent
from python.helpers.vector_db import VectorDB, Document
import os
from python.helpers.tool import Tool, Response
from python.helpers.print_style import PrintStyle
from python.helpers.errors import handle_error

class Memory(Tool):
    async def execute(self, **kwargs):
        result = ""
        try:
            if "query" in kwargs:
                threshold = float(kwargs.get("threshold", 0.1))
                count = int(kwargs.get("count", 5))
                result = search(self.agent, kwargs["query"], count, threshold)
            elif "memorize" in kwargs:
                result = save(self.agent, kwargs["memorize"])
            elif "forget" in kwargs:
                result = forget(self.agent, kwargs["forget"])
            elif "delete" in kwargs:
                result = delete(self.agent, kwargs["delete"])
        except Exception as e:
            handle_error(e)
            PrintStyle.hint("If you changed your embedding model, you will need to remove contents of /memory directory.")
            self.agent.context.log.log(type="hint", content="If you changed your embedding model, you will need to remove contents of /memory directory.")
            raise   
        
        return Response(message=result, break_loop=False)

# ... (helper functions: search, save, delete, forget)
```

### 5.2. Interacting with Memory

The Memory Tool supports four main operations:

1. **Query**: Search for relevant information in the memory.
2. **Memorize**: Save new information to the memory.
3. **Forget**: Remove information related to a specific query from the memory.
4. **Delete**: Remove specific memory entries by their IDs.

Here's an example of how an agent might use the Memory Tool to query its memory:

```json
{
    "thoughts": [
        "I need to recall information about climate change",
        "I'll use the memory tool to search for relevant data"
    ],
    "tool_name": "memory_tool",
    "tool_args": {
        "query": "effects of climate change",
        "threshold": 0.2,
        "count": 3
    }
}
```

## 6. Hands-on: Implementing a Custom Memory System

Now, let's create a simple custom memory system that focuses on categorizing memories. We'll call it the "Categorical Memory System."

First, create a new file `categorical_memory.py` in the `python/helpers/` directory:

```python
# python/helpers/categorical_memory.py

import json
from typing import Dict, List, Optional
from python.helpers.files import get_abs_path

class CategoricalMemory:
    def __init__(self, file_path: str = "memory/categorical_memory.json"):
        self.file_path = get_abs_path(file_path)
        self.categories: Dict[str, List[str]] = self._load_memory()

    def _load_memory(self) -> Dict[str, List[str]]:
        try:
            with open(self.file_path, 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            return {}

    def _save_memory(self):
        with open(self.file_path, 'w') as f:
            json.dump(self.categories, f, indent=2)

    def add_memory(self, category: str, memory: str):
        if category not in self.categories:
            self.categories[category] = []
        self.categories[category].append(memory)
        self._save_memory()

    def get_memories(self, category: str) -> List[str]:
        return self.categories.get(category, [])

    def search_memories(self, query: str) -> Dict[str, List[str]]:
        results = {}
        for category, memories in self.categories.items():
            matching_memories = [m for m in memories if query.lower() in m.lower()]
            if matching_memories:
                results[category] = matching_memories
        return results

    def delete_memory(self, category: str, memory: str) -> bool:
        if category in self.categories and memory in self.categories[category]:
            self.categories[category].remove(memory)
            self._save_memory()
            return True
        return False

    def get_categories(self) -> List[str]:
        return list(self.categories.keys())
```

Now, let's create a new tool to use this Categorical Memory System. Create a file `categorical_memory_tool.py` in the `python/tools/` directory:

```python
# python/tools/categorical_memory_tool.py

from python.helpers.tool import Tool, Response
from python.helpers.categorical_memory import CategoricalMemory

class CategoricalMemoryTool(Tool):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.memory = CategoricalMemory()

    async def execute(self, action="", category="", memory="", query="", **kwargs):
        if action == "add":
            self.memory.add_memory(category, memory)
            return Response(message=f"Added memory to category '{category}'", break_loop=False)
        elif action == "get":
            memories = self.memory.get_memories(category)
            return Response(message=f"Memories in category '{category}': {memories}", break_loop=False)
        elif action == "search":
            results = self.memory.search_memories(query)
            return Response(message=f"Search results for '{query}': {results}", break_loop=False)
        elif action == "delete":
            success = self.memory.delete_memory(category, memory)
            return Response(message=f"Memory {'deleted' if success else 'not found'}", break_loop=False)
        elif action == "categories":
            categories = self.memory.get_categories()
            return Response(message=f"Available categories: {categories}", break_loop=False)
        else:
            return Response(message="Invalid action for Categorical Memory Tool", break_loop=False)
```

Finally, update the `agent.tools.md` file in the `prompts/default/` directory to include the new Categorical Memory Tool:

```markdown
# prompts/default/agent.tools.md

...

### categorical_memory_tool:
Manages a categorical memory system.
Provide the "action" argument with one of: "add", "get", "search", "delete", or "categories".
For "add" and "delete" actions, provide "category" and "memory" arguments.
For "get" action, provide "category" argument.
For "search" action, provide "query" argument.
**Example usage**:
~~~json
{
    "thoughts": [
        "I need to add a new memory about climate change",
    ],
    "tool_name": "categorical_memory_tool",
    "tool_args": {
        "action": "add",
        "category": "Environmental Issues",
        "memory": "Global temperatures have risen by 1°C since the pre-industrial era."
    }
}
~~~

...
```

This custom Categorical Memory System allows the agent to organize and retrieve memories by categories, providing a different approach to memory management compared to the vector database method.

## 7. Conclusion

In this lesson, we've explored memory and knowledge management in AI agents, focusing on Agent Zero's implementation. We covered:

1. Vector databases for long-term memory, using the FAISS library.
2. The knowledge import system for loading various file types into the agent's knowledge base.
3. The Memory Tool for interacting with the agent's long-term memory.
4. A hands-on example of implementing a custom Categorical Memory System.

Key takeaways:
- Effective memory and knowledge management are crucial for creating intelligent and adaptable AI agents.
- Vector databases allow for semantic similarity searches, which is essential for implementing human-like memory recall.
- The knowledge import system enables agents to learn from various file types and formats.
- Custom memory systems can be implemented to suit specific needs, such as categorical organization.

By mastering these concepts, you can create AI agents with sophisticated memory capabilities, enabling them to learn, recall, and apply knowledge more effectively. In the next lesson, we'll explore code execution and environment interaction, further expanding the capabilities of our AI agents.
